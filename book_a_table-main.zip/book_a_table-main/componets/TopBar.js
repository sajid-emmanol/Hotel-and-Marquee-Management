import { Box, Flex, Text, useColorModeValue, Icon } from '@chakra-ui/react'
import React from 'react'
import { useSelector } from 'react-redux';
import styles from '../styles/Home.module.css'
/// Icons
import { HiEnvelope } from 'react-icons/hi2'
import { ImPhone } from 'react-icons/im'
import { FaFacebookF } from 'react-icons/fa'
import { BsTwitter } from 'react-icons/bs'
import { FaLinkedinIn } from 'react-icons/fa'
import { BsInstagram } from 'react-icons/bs'

export default function TopBar() {

  const { colors } = useSelector(state => state?.color);

  const socialIcons = [
    {
      name: FaFacebookF
    },
    {
      name: BsTwitter,
    },
    {
      name: FaLinkedinIn,
    },
    {
      name: BsInstagram,
    },
  ]

  return (
    <Box className={styles?.container} display={'flex'} bg={useColorModeValue(colors?.secondary, 'gray.700')} justifyContent={{ base: 'center', md: 'none', lg: 'space-between' }} alignItems={{ base: 'center' }} >
      <Flex display={{ base: 'none', md: 'flex' }} className={styles?.parallelogram} bg={useColorModeValue(colors?.primary, 'gray.700')} justifyContent={'space-between'} px={{ md: '10', lg: '14' }} >
        <Box className={styles?.iconBox} _hover={{
        }}>
          <Icon as={HiEnvelope} color={useColorModeValue(colors?.white, 'gray.700')} boxSize={'5'} me={2} />
          <Text  color={useColorModeValue(colors?.white, 'gray.700')} >
            businesseswithar@gmail.com
          </Text>
        </Box>
        <Box className={styles?.iconBox} ms={4}>
          <Icon as={ImPhone} color={useColorModeValue(colors?.white, 'gray.700')} boxSize={'5'} me={2} />
          <Text color={useColorModeValue(colors?.white, 'gray.700')}>
            +923065000589
          </Text>
        </Box>
      </Flex>
      <Flex ms={{ base: 'none', md: 10 }} h={{ base: '50', md: 'none' }} alignItems={{ base: 'center', md: 'none' }}>
        {socialIcons?.map((socialIcon, i) => {
          return (
            <Box key={i} color={'white'} className={styles?.socialIconBox} mx={'1.5'} bg={useColorModeValue(colors?.primary, 'gray.700')} _hover={{
              bg: useColorModeValue(colors?.white, 'gray.700'),
              color: useColorModeValue(colors?.primary, 'gray.700')
            }}>
              <Icon as={socialIcon.name} boxSize={'3.5'} />
            </Box>
          )
        })}

      </Flex>
    </Box>
  )
}
