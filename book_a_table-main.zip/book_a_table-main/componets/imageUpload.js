const crypto = require('crypto');

export const imageUpload = async (image) => {
  const data = new FormData();
  data.append("file", image);
  data.append("upload_preset", "myPreset");
  data.append("cloud_name", "dznyc2nj5");
  const res = await fetch(
    "https://api.cloudinary.com/v1_1/dznyc2nj5/image/upload",
    { method: "post", body: data }
  );
  return res.json();
};


const generateSignature = (publicId, apiKey, apiSecret, timestamp) => {
  const signatureString = `public_id=${publicId}&timestamp=${timestamp}${apiSecret}`;
  const signature = crypto.createHash('md5').update(signatureString).digest('hex');
  return signature;
};

export const deleteImage = async (publicId) => {
  const cloudName = 'dznyc2nj5';
  const apiKey = '287814736924736';
  const apiSecret = '0VJH0y6tNTinEQC6ehbYWipSFQI'; // Replace with your Cloudinary API secret

  const timestamp = new Date().getTime();
  const signature = generateSignature(publicId, apiKey, apiSecret, timestamp);

  try {
    const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/destroy`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        public_id: publicId,
        api_key: apiKey,
        timestamp: timestamp,
        signature: signature
      })
    });

    if (response.ok) {
      console.log('Image deleted successfully.');
    } else {
      console.log(response);
    }
  } catch (error) {
    console.log('Error:', error);
  }
};
