import {
  Box,
  Flex,
  Text,
  IconButton,
  Button,
  Stack,
  Collapse,
  Icon,
  Link,
  Popover,
  PopoverTrigger,
  PopoverContent,
  useColorModeValue,
  useBreakpointValue,
  useDisclosure,
  HStack,
  Menu,
  MenuButton,
  Avatar,
  MenuList,
  MenuItem,
  Image,
} from "@chakra-ui/react";
import {
  HamburgerIcon,
  CloseIcon,
  ChevronDownIcon,
  ChevronRightIcon,
} from "@chakra-ui/icons";
import { useDispatch, useSelector } from "react-redux";
import { useRouter } from "next/router";
import { FaShoppingBasket } from "react-icons/fa";
import { setIsLoggedIn, setUser } from "@/redux/features/user/userSlice";

import userImage from '../public/assets/images/user.png';
import logoImage from  "../public/assets/images/logo.png";



export default function Navbar() {
  const { isOpen, onToggle } = useDisclosure();
  const { colors } = useSelector((state) => state.color);
  const { isLoggedIn, user } = useSelector((state) => state.user);

  const router = useRouter();
  const dispatch = useDispatch()

  const logout = () => {
    dispatch(setIsLoggedIn(false));
    dispatch(setUser({}));
    
  }

  return (
    <Box
      position={{ base: "sticky" }}
      top={0}
      zIndex={10}
      borderBottom={`1px solid ${colors?.lightRed}`}
    >
      <Flex
        ps={{ base: "10vw", md: "3vw", lg: "10vw" }}
        pe={{ base: "10vw", md: "3vw", lg: "10vw" }}
        bg={useColorModeValue(colors.white, "gray.800")}
        color={useColorModeValue("gray.600", "white")}
        minH={"60px"}
        py={{ base: 2 }}
        px={{ base: 4 }}
        borderBottom={1}
        borderColor={useColorModeValue("gray.200", "gray.900")}
        align={"center"}
        paddingInlineStart={0}
      >
        <Flex
          flex={{ base: 1, md: "auto" }}
          ml={{ base: 2 }}
          display={{ base: "flex", md: "none" }}
        >
          <IconButton
            onClick={onToggle}
            icon={
              isOpen ? <CloseIcon w={3} h={3} /> : <HamburgerIcon w={5} h={5} />
            }
            bg={
              isOpen
                ? useColorModeValue(colors.red, "gray.200")
                : useColorModeValue(colors.primary, "gray.200")
            }
            color={useColorModeValue(colors.white, "gray.200")}
            aria-label={"Toggle Navigation"}
            _hover={
              {
                // isOpen? useColorModeValue(colors.red, 'gray.200') : useColorModeValue(colors.primary, 'gray.200')
              }
            }
          />
        </Flex>
        <Flex
          textAlign={useBreakpointValue({ base: "center", md: "left" })}
          fontFamily={"heading"}
          display={useBreakpointValue({ base: "none", md: "flex" })}
          color={useColorModeValue("gray.800", "white")}
          onClick={() => router.push("/")}
          cursor={'pointer'}
          width={'70px'}
          height={'70px'}
          alignItems={'center'}
          mt={2}
          >
          
          <Image src={logoImage.src} width={'100%'} height={'100%'}/>
        </Flex>
        <Flex flex={{ base: 1 }} justify={{ base: "center", md: "center" }}>
          <Text
            textAlign={useBreakpointValue({ base: "center", md: "left" })}
            fontFamily={"heading"}
            display={useBreakpointValue({ base: "flex", md: "none" })}
            color={useColorModeValue("gray.800", "white")}
            onClick={() => router.push("/")}
            cursor={'pointer'}
            mt={2}
          >
          <Image src={logoImage.src} width={'80px'} />
            
          </Text>

          <Flex display={{ base: "none", md: "flex" }} ml={10}>
            <DesktopNav colors={colors} router={router} />
          </Flex>
        </Flex>
        <Stack
          flex={{ base: 1, md: 0 }}
          justify={"flex-end"}
          direction={"row"}
          spacing={6}
        >
          {!isLoggedIn ? (
            <Button
              // as={'a'}
              display={{ base: "none", md: "inline-flex" }}
              fontSize={"sm"}
              fontWeight={600}
              color={useColorModeValue(colors?.white, "gray.700")}
              bg={useColorModeValue(colors?.primary, "gray.700")}
              _hover={{
                opacity: 0.8,
              }}
              onClick={() => router.push("/auth/login")}
            >
              LogIn
            </Button>
          ) : (
            <Flex alignItems={'center'}>
              <Box
                width={"40px"}
                height={"40px"}
                rounded={"full"}
                bg={colors?.lightRed}
                color={colors?.secondary}
                display={"flex"}
                justifyContent={"center"}
                alignItems={"center"}
                _hover={{ bg: colors?.primary, color: colors?.white }}
                onClick={() => router.push("/cart")}
              >
                <Icon as={FaShoppingBasket} boxSize={5} />
              </Box>
              <HStack spacing={{ base: '0', md: '6' }} ms={3}>
                <Menu >
                  <MenuButton
                    py={2}
                    transition="all 0.3s"
                    _focus={{ boxShadow: 'none' }}>
                    <HStack >
                      <Avatar
                        height={'37px'} width={'37px'}
                        src={
                          userImage.src
                        }
                      />
                    </HStack>
                  </MenuButton>
                  <MenuList
                    bg={colors?.white}
                    borderColor={'gray.200'}
                  >
                    <MenuItem onClick={()=>router.push(`/orders/${user?.id}`)}>My Orders</MenuItem>
                    <MenuItem onClick={logout}>Sign out</MenuItem>
                  </MenuList>
                </Menu>
              </HStack>
            </Flex>
          )}
        </Stack>

      </Flex>

      <Collapse in={isOpen} animateOpacity>
        <MobileNav router={router} colors={colors} />
      </Collapse>
    </Box>
  );
}

const DesktopNav = ({ colors, router }) => {
  const linkColor = useColorModeValue(colors.secondary, "gray.200");
  const linkHoverColor = useColorModeValue(colors.primary, "white");
  const popoverContentBgColor = useColorModeValue(colors.white, "gray.800");

  return (
    <Stack direction={"row"} spacing={4}>
      {NAV_ITEMS.map((navItem, i) => (
        <Box key={i}>
          <Popover trigger={"hover"} placement={"bottom-start"}>
            <PopoverTrigger>
              <Link
                p={1}
                onClick={() => router.push(navItem.routePath)}
                fontSize={"md"}
                fontWeight={"medium"}
                color={linkColor}
                _hover={{
                  textDecoration: "none",
                  borderBottom: "1px solid",
                  borderBottomColor: linkHoverColor,
                  color: linkHoverColor,
                  transition: "borderBottom 2s ease-out",
                }}
              >
                {navItem.label}
              </Link>
            </PopoverTrigger>

            {navItem.children && (
              <PopoverContent
                border={0}
                boxShadow={"xl"}
                bg={popoverContentBgColor}
                p={4}
                rounded={"xl"}
                minW={"sm"}
              >
                <Stack>
                  {navItem.children.map((child, i) => (
                    <DesktopSubNav
                      key={i}
                      {...child}
                      colors={colors}
                      router={router}
                    />
                  ))}
                </Stack>
              </PopoverContent>
            )}
          </Popover>
        </Box>
      ))}
    </Stack>
  );
};

const DesktopSubNav = ({ label, href, subLabel, colors }) => {
  return (
    <Link
      href={href}
      role={"group"}
      display={"block"}
      p={2}
      rounded={"md"}
      _hover={{ bg: useColorModeValue(colors.primary, "gray.900") }}
    >
      <Stack direction={"row"} align={"center"}>
        <Box>
          <Text
            transition={"all .3s ease"}
            _groupHover={{ color: "pink.400" }}
            fontWeight={500}
          >
            {label}
          </Text>
          <Text fontSize={"sm"}>{subLabel}</Text>
        </Box>
        <Flex
          transition={"all .3s ease"}
          transform={"translateX(-10px)"}
          opacity={0}
          _groupHover={{ opacity: "100%", transform: "translateX(0)" }}
          justify={"flex-end"}
          align={"center"}
          flex={1}
        >
          <Icon color={"pink.400"} w={5} h={5} as={ChevronRightIcon} />
        </Flex>
      </Stack>
    </Link>
  );
};

const MobileNav = ({ colors, router }) => {
  return (
    <Stack
      bg={useColorModeValue(colors.white, "gray.800")}
      p={4}
      display={{ md: "none" }}
    >
      {NAV_ITEMS.map((navItem, i) => (
        <MobileNavItem key={i} {...navItem} router={router} colors={colors} />
      ))}
      <Stack
        flex={{ base: 1, md: 0 }}
        justify={"flex-end"}
        direction={"row"}
        spacing={6}
        mt={3}
      >
        <Button
          as={"a"}
          display={{ base: "flex", md: "inline-flex" }}
          fontSize={"sm"}
          fontWeight={600}
          color={"white"}
          bg={useColorModeValue(colors?.primary, "gray.700")}
          _hover={{
            opacity: 0.8,
          }}
          width={"100%"}
          onClick={()=>router.push('/auth/login')}
        >
          LogIn
        </Button>
      </Stack>
    </Stack>
  );
};

const MobileNavItem = ({ label, children, router, routePath, colors }) => {
  const { isOpen, onToggle } = useDisclosure();

  return (
    <Stack spacing={4} onClick={children && onToggle}>
      <Flex
        py={2}
        as={Link}
        onClick={() => router.push(routePath)}
        justify={"space-between"}
        align={"center"}
        _hover={{
          textDecoration: "none",
        }}
      >
        <Text
          fontWeight={600}
          color={useColorModeValue(colors.secondary, "gray.200")}
          _hover={{
            color: colors.primary,
          }}
        >
          {label}
        </Text>
        {children && (
          <Icon
            as={ChevronDownIcon}
            transition={"all .25s ease-in-out"}
            transform={isOpen ? "rotate(180deg)" : ""}
            w={6}
            h={6}
            _hover={{
              color: useColorModeValue(colors.primary, "gray.200"),
            }}
          />
        )}
      </Flex>

      <Collapse in={isOpen} animateOpacity style={{ marginTop: "0!important" }}>
        <Stack
          mt={2}
          pl={4}
          borderLeft={1}
          borderStyle={"solid"}
          borderColor={useColorModeValue(colors.primary, "gray.700")}
          align={"start"}
        >
          {children &&
            children.map((child, i) => (
              <Link
                key={i}
                py={2}
                href={child.href}
                _hover={{
                  borderBottom: "1px solid",
                  borderBottomColor: useColorModeValue(
                    colors.primary,
                    "gray.700"
                  ),
                  color: useColorModeValue(colors.primary, "gray.700"),
                }}
              >
                {child.label}
              </Link>
            ))}
        </Stack>
      </Collapse>
    </Stack>
  );
};

const NAV_ITEMS = [
  {
    label: "Home",
    routePath: "/",
  },
  {
    label: "About",
    routePath: "/about",
  },
  {
    label: "Menu",
    routePath: "/menu",
  },
  {
    label: "Chefs",
    routePath: "/chefs",
  },
  {
    label: "Marquees",
    routePath: "/marquee",
  },
  {
    label: "Deals",
    routePath: "/deals",
  },
  {
    label: "Contact",
    routePath: "/contact",
  },
];
