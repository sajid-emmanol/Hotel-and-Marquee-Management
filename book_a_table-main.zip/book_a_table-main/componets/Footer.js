import {
  Box,
  Container,
  SimpleGrid,
  Stack,
  Text,
  useColorModeValue,
  ListItem,
  UnorderedList,
  Flex,
  Icon,
  Image,
} from "@chakra-ui/react";
import { useSelector } from "react-redux";

/// Icons
import { HiOutlinePhone, HiOutlineLocationMarker } from "react-icons/hi";
import { HiEnvelope } from "react-icons/hi2";

/// Styles
import styles from "../styles/Home.module.css";

/// Footer Background
import footerBg from "../public/assets/images/footer_bg.jpg";
import SocialIcons from "@/common/SocialIcons";
import { useRouter } from "next/router";

import logoImage from '../public/assets/images/logo.png'

const Logo = (props) => {
  return (
    <Flex alignItems={'center'}>

      <Image src={logoImage.src} width={'80px'} height={'80px'} mt={3} />
      <Text>Marquee Hub</Text>
    </Flex>

  );
};

export default function Footer() {
  const { colors } = useSelector((state) => state?.color);
  const router = useRouter();

  return (
    <>
      <Box
        bg={useColorModeValue(colors?.secondary, "gray.900")}
        color={useColorModeValue(colors?.white, "gray.200")}
        className={styles?.bg_img_container}
        _before={{
          backgroundImage: `url(${footerBg.src})`,
          opacity: 0.1,
        }}
        p={{ base: "5vw 5vw", md: "5vw 10vw" }}
      >
        <Container
          as={Stack}
          maxW={"6xl"}
          py={10}
          className={styles?.overlay_text}
        >
          <SimpleGrid
            templateColumns={{
              sm: "1fr 1fr",
              md: "2fr 1fr 1fr",
              lg: "2fr 1fr 1fr 1fr",
            }}
            spacing={10}
          >
            <Stack spacing={6}>
              <Text fontSize={'2xl'} fontWeight={'bold'}>
                Marquee Hub
              </Text>
              <Text fontSize={"sm"}>
                Our platform offers seamless interaction among admin, privileged users, and visitors.
                From reserving exquisite marquees for your special occasions to selecting
                delectable food items and exclusive deals,
                we make event planning a breeze
              </Text>
              <Stack direction={"row"} spacing={1}>
                <SocialIcons
                  iconColor={colors?.white}
                  iconBgColor={colors?.primary}
                  hoverBgColor={colors?.white}
                  hoverIconColor={colors?.primary}
                />
              </Stack>
            </Stack>
            <Stack align={"flex-start"}>
              <Text
                borderBottom={`1px solid ${colors?.primary}`}
                fontSize={{ base: "2xl" }}
                fontWeight={{ base: "bold" }}
                pb={"3px"}
              >
                Short Link
              </Text>
              <UnorderedList
                listStyleType={"square"}
                spacing={3}
                color={colors?.lightGrey}
                mt={3}
                fontSize={"16px"}
                fontWeight={"semibold"}
                cursor={'pointer'}
              >
                <ListItem _hover={{ color: colors?.primary }} onClick={() => router.push('/')}>Home</ListItem>
                <ListItem _hover={{ color: colors?.primary }} onClick={() => router.push('/about')}>
                  About Us
                </ListItem>
                <ListItem _hover={{ color: colors?.primary }} onClick={() => router.push('/contact')}>
                  Contact Us
                </ListItem>

              </UnorderedList>
            </Stack>
            <Stack align={"flex-start"}>
              <Text
                borderBottom={`1px solid ${colors?.primary}`}
                fontSize={{ base: "2xl" }}
                fontWeight={{ base: "bold" }}
                pb={"3px"}
              >
                Help Link
              </Text>
              <UnorderedList
                listStyleType={"square"}
                spacing={3}
                color={colors?.lightGrey}
                mt={3}
                fontSize={"16px"}
                fontWeight={"semibold"}
              >
                <ListItem _hover={{ color: colors?.primary }}>
                  Terms & Conditions
                </ListItem>
                <ListItem _hover={{ color: colors?.primary }}>
                  Privacy Policy
                </ListItem>
                <ListItem _hover={{ color: colors?.primary }}>
                  Refund Policy
                </ListItem>
                <ListItem _hover={{ color: colors?.primary }}>Contact</ListItem>
              </UnorderedList>
            </Stack>
            <Stack align={"flex-start"}>
              <Text
                borderBottom={`1px solid ${colors?.primary}`}
                fontSize={{ base: "2xl" }}
                fontWeight={{ base: "bold" }}
                pb={"3px"}
              >
                Contact Us
              </Text>
              <Flex direction={{ base: "column" }}>
                <Stack
                  direction={{ base: "row" }}
                  alignItems={{ base: "center" }}
                  borderBottom={`1px solid ${colors?.primary}`}
                  py={3}
                >
                  <Icon
                    as={HiOutlinePhone}
                    boxSize={"6"}
                    color={colors?.primary}
                  />
                  <Text color={colors?.lightGrey}>+923065000589</Text>
                </Stack>
                <Stack
                  direction={{ base: "row" }}
                  alignItems={{ base: "center" }}
                  borderBottom={`1px solid ${colors?.primary}`}
                  py={3}
                >
                  <Icon as={HiEnvelope} boxSize={"6"} color={colors?.primary} />
                  <Text color={colors?.lightGrey}>businesseswithar@gmail.com</Text>
                </Stack>
                <Stack
                  direction={{ base: "row" }}
                  alignItems={{ base: "center" }}
                  borderBottom={`1px solid ${colors?.primary}`}
                  py={3}
                >
                  <Icon
                    as={HiOutlineLocationMarker}
                    boxSize={"6"}
                    color={colors?.primary}
                  />
                  <Text color={colors?.lightGrey}>
                    Faisalabad,Pakistan
                  </Text>
                </Stack>
              </Flex>
            </Stack>
          </SimpleGrid>
        </Container>
      </Box>
      <Flex
        bg={colors?.primary}
        justifyContent={{ base: "center" }}
        alignItems={{ base: "center" }}
        py={{ base: 5 }}
        px={{ base: "5vw" }}
      >
        <Text
          fontSize={{ base: "17px" }}
          fontWeight={{ base: "semibold" }}
          color={colors?.white}
          textAlign={{ base: "center" }}
        >
          Copyright © Marquee Hub 2023. All Rights Reserved
        </Text>
      </Flex>
    </>
  );
}
