import React, { useEffect, useState } from "react";
import Router from "next/router";
import { useSelector } from "react-redux";

const login = "/auth/login"; // Define your login route address.

/**
 * Check user authentication and authorization
 * It depends on you and your auth service provider.
 * @returns {{auth: null}}
*/
const checkUserAuthentication = async (context) => {



  // // const data = localStorage.getItem('root');

  return { auth: isLoggedIn }; // change null to { isAdmin: true } for test it.
};

export default (WrappedComponent) => {
  // const [first, setfirst] = useState('');
  const hocComponent = ({ ...props }) => <WrappedComponent {...props} />;



  hocComponent.getInitialProps = async (context) => {
    const userAuth = await checkUserAuthentication(context);

    // Are you an authorized user or not?
    if (!userAuth?.auth) {
      // Handle server-side and client-side rendering.
      if (context.res) {
        context.res?.writeHead(302, {
          Location: login,
        });
        context.res?.end();
      } else {
        Router.replace(login);
      }
    } else if (WrappedComponent.getInitialProps) {
      const wrappedProps = await WrappedComponent.getInitialProps({
        ...context,
        auth: userAuth,
      });
      return { ...wrappedProps, userAuth };
    }

    return { userAuth };
  };

  return hocComponent;
};
