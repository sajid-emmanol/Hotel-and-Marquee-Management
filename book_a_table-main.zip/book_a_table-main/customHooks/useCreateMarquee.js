import { imageUpload } from '@/componets/imageUpload';
import { apitypes } from '@/helper/apitypes';
import { useRouter } from 'next/router';
import { useRef, useState } from 'react'
import { toast } from 'react-hot-toast';
import { useSelector } from 'react-redux';

const initialState = {
  name: '',
  location: '',
  city: '',
  desc : '',
  ownerId: '',
  image: '',
}
export default function useCreateMarquee() {

  const { colors } = useSelector(state => state.color);
  const inputRef = useRef();


  const [state, setState] = useState(initialState);
  const [fileName, setFileName] = useState('');
  const [isLoading, setisLoading] = useState(false);
  const router = useRouter();

  const handleChange = e => {
    const name = e?.target?.name;
    const value = e?.target?.value;

    setState((state) => ({ ...state, [name]: value }));
  }

  const handleFile = e => {

    const name = e.target.name;
    const file = e.target.files[0];
    setState((state) => ({ ...state, [name]: file }))
    setFileName(file.name);

  }

  const handleSubmit = async (e) => {

    e.preventDefault();
    setisLoading(true);
    const isValid = checkValidations()
    if (isValid) {

      await uploadImage();
      setState(initialState);
      setFileName('');
    }
    setisLoading(false);
  };

  const checkValidations = () => {
    if (state.name === '') {
      toast.error("Please enter Marquee name", { duration: 3000 });
      return false;
    }
    if (state.location === '') {
      toast.error("Please enter Marquee location", { duration: 3000 });
      return false;
    }
    if (state.city === '') {
      toast.error("Please enter City name", { duration: 3000 });
      return false;
    }
    if (state.desc === '') {
      toast.error("Please enter Marquee description", { duration: 3000 });
      return false;
    }
    if (state.image === '') {
      toast.error("Please select an image", { duration: 3000 });
      return false;
    }

    return true;
  };


  const uploadImage = async () => {

    const result = await imageUpload(state?.image)
    const createdMarquee = await createMarquee(state, result?.url, result?.public_id, );
    if (createdMarquee !== null && createdMarquee?.id) {
      router.push('/admin/marquee')
    }
  }


  const createMarquee = async (obj, imageUrl, publicId) => {
    try {
      const response = await fetch("/api/operation", {
        method: 'POST',
        body: JSON.stringify({
          type: apitypes.CREATEMARQUEE,
          payload: {
            name: obj?.name,
            location: obj?.location,
            city: obj?.city,
            desc : obj?.desc,
            image: imageUrl,
            publicId: String(publicId),
            ownerId: obj?.ownerId
          }
        })
      })


      const newItem = await response.json();
      if (response.status !== 201) {
        toast.error(newItem?.message, {
          duration: 3000,
        });
        setisLoading(false);
        return

      } else {
        toast.success('Marquee Created Successfully', {
          duration: 3000,
        });
      }
      setisLoading(false);
      return newItem
    } catch (error) {
      console.error("Error creating Marquee:", error);
      setisLoading(false)
    }
  };
  
  return (
    {
      handleChange,
      handleFile,
      handleSubmit,
      fileName,
      colors,
      inputRef,
      isLoading,
      state,
    }
  )
}
