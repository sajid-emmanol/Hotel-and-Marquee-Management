import { apitypes } from '@/helper/apitypes';
import { setIsLoggedIn, setUser } from '@/redux/features/user/userSlice';
import { useRouter } from 'next/router';
import React, { useState } from 'react'
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux'

const initialState = {
    password1: '',
    password2: '',
}

export default function useAuthUpdate(userId) {

    const [state, setState] = useState(initialState);
    const [isLoading, setisLoading] = useState(false);

    const { colors } = useSelector(state => state?.color);

    const dispatch = useDispatch();
    const router = useRouter();

    const handleChange = e => {

        const name = e.target.name;
        const value = e.target.value;
        setState(state => ({ ...state, [name]: value }))

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setisLoading(true);

        const isValid = checkValidations();
        if (isValid) {
            const existingUser = await updatePassword(state);
            if (existingUser != null && existingUser.id) {
                router.push('/auth/login')
            } else {
                dispatch(setIsLoggedIn(false));
            }
        }
        setisLoading(false);
    };

    const checkValidations = () => {
        if (state.password1 === '') {
            toast.error("Please enter password", { duration: 3000 });
            return false;
        }
        if (state.password2 === '') {
            toast.error("Please enter a Password", { duration: 3000 });
            return false;
        }
        if (state.password1 !== state?.password2) {
            toast.error("Your Password don't match", { duration: 3000 });
            return false;
        }
        return true;
    };

    const updatePassword = async (obj) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.UPDATEPASS,
                    payload: {
                        id: userId,
                        password: obj?.password1,
                    }
                })
            })
            const existingUser = await response.json();

            if (response.status !== 201 || existingUser === null) {
                toast.error(existingUser?.message, {
                    duration: 3000,
                });
                setisLoading(false);
                return

            } else {
                toast.success('Password Updated Successfully', {
                    duration: 3000,
                });
            }
            setisLoading(false);
            return existingUser;
        } catch (error) {
            console.error("Error Logging In:", error);
        }
    };

    return (
        {
            handleChange,
            handleSubmit,
            colors,
            isLoading,
        }
    )
}
