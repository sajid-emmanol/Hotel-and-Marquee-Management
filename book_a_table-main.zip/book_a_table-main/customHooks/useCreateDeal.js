import { imageUpload } from '@/componets/imageUpload';
import { apitypes } from '@/helper/apitypes';
import { addDiscount,  setDiscountPrice } from '@/redux/features/deals/dealsSlice';
import { useRouter } from 'next/router';
import React, { useEffect, useRef, useState } from 'react'
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux';

export default function useCreateDeal(marquees) {

    const [isLoading, setIsLoading] = useState(true);
    const [allMarquees, setallMarquees] = useState([]);
    const [state, setState] = useState({ marqueeId: '', discount: '', dealName: '', image: '' });

    const { colors } = useSelector(state => state.color);
    const router = useRouter();

    const inputRef = useRef();
    const dispatch = useDispatch()

    useEffect(() => {
        setIsLoading(false);
        if (state.marqueeId.length > 0) {
            const filteredMarquee = marquees.filter(marquee => {
                return marquee.id == state.marqueeId;
            });
            setallMarquees(filteredMarquee);
        };
    }, [state]);

    const handleChange = e => {
        const name = e.target.name;
        const value = e.target.value;

        setState(s => ({ ...s, [name]: value }));
    };

    const handleFile = (e) => {
        const name = e.target.name;
        const file = e.target.files[0];

        setState(s => ({ ...s, [name]: file }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        dispatch(setDiscountPrice(state?.discount))
        dispatch(addDiscount(state?.discount))
    }




    const createDeal = async (selectedProducts, totalPrice, discountPrice, subTotalPrice) => {

        setIsLoading(true);
        await uploadImage(selectedProducts, totalPrice, discountPrice, subTotalPrice)
        setIsLoading(false)


    };

    const uploadImage = async (selectedProducts, totalPrice, discountPrice, subTotalPrice) => {

        const result = await imageUpload(state?.image)
        const createdDeal = await addDeal(selectedProducts, totalPrice, discountPrice, subTotalPrice, result?.url, result?.public_id);
        if (createdDeal != null) {
            router.push('/admin/deals')
        }
    };


    const addDeal = async (selectedProducts, totalPrice, discountPrice, subTotalPrice, imageUrl, publicId) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.CREATEDEAL,
                    payload: {
                        price: Number(subTotalPrice),
                        actualPrice: Number(totalPrice),
                        discount: Number(discountPrice),
                        name: state?.dealName,
                        items: selectedProducts,
                        marqueeId: state?.marqueeId,
                        image: imageUrl,
                        publicId: publicId
                    }
                })
            })
            const newItem = await response.json();
            if (response.status !== 201) {
                toast.error(newItem?.message, {
                    duration: 3000,
                });
                setIsLoading(false);
                return
            } else {
                toast.success('Deal Created Successfully', {
                    duration: 3000,
                });
            }
            return newItem;
        } catch (error) {
            console.error("Error creating deal:", error);
            setIsLoading(false);
        }
    }


    const columns = [
        {
            name: 'Sr#',
            selector: (row, i) => i + 1,
        },
        {
            name: 'Product Name',
            selector: row => row.name,
        },
        {
            name: 'Price',
            selector: row => row.price,
        },
        {
            name: 'Description',
            selector: row => row.desc,
            // grow : 10
        },
        {
            name: 'Image',
            selector: row => row.image,
        },
        {
            name: 'Product_ID',
            selector: (row) => row.id,
        },
    ];

    return (
        {
            columns,
            colors,
            isLoading,
            handleChange,
            handleFile,
            handleSubmit,
            createDeal,
            allMarquees,
            state,
            inputRef,
        }
    )
}
