import { apitypes } from '@/helper/apitypes';
import { setIsLoggedIn, setUser } from '@/redux/features/user/userSlice';
import { useRouter } from 'next/router';
import React, { useState } from 'react'
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux'



export default function useAuthOtp(isForgotPassword, userId) {

    const [isLoading, setisLoading] = useState(false);

    const { colors } = useSelector(state => state?.color);
    const router = useRouter();
    const dispatch = useDispatch();



    const handleSubmit = async (otp) => {
        setisLoading(true);

        const isValid = checkValidations(otp);
        if (isValid) {
            const verifiedUser = await verifyOtp(otp);
            if (isForgotPassword == "false") {
                if (verifiedUser?.id && verifiedUser!== null) {
                    dispatch(setIsLoggedIn(true));
                    dispatch(setUser(verifiedUser));
                    if (verifiedUser.userType == 'User') {
                        router.push('/')
                    } else {
                        router.push('/admin')
                    }
                } else {

                    dispatch(setIsLoggedIn(false));
                }

            } else {
                router.push({
                    pathname: '/auth/updatePassword',
                    query: { userId: verifiedUser?.id }
                })
            }
        }
        setisLoading(false);
    };

    const checkValidations = (otp) => {
        if (otp.length < 6) {
            toast.error("Enter a 6 digit otp code", { duration: 3000 });
            return false;
        }
        return true;
    };

    const verifyOtp = async (otp) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.VERIFYOTP,
                    payload: {
                        id: userId,
                        otp: otp,
                    }
                })
            })
            const verifiedUser = await response.json();

            if (response.status !== 201 || verifiedUser === null) {
                toast.error("Error verifying otp", {
                    duration: 3000,
                });
                setisLoading(false);
                return 

            } else {
                toast.success('OTP verified ', {
                    duration: 3000,
                });
            }
            setisLoading(false);
            return verifiedUser;
        } catch (error) {
            console.error("Error verifying otp:", error);
        }
    };

    return (
        {
            handleSubmit,
            colors,
            isLoading,
        }
    )
}
