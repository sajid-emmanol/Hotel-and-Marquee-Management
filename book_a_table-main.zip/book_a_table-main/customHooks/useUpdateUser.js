import { imageUpload } from '@/componets/imageUpload';
import { apitypes } from '@/helper/apitypes';
import { setUser } from '@/redux/features/user/userSlice';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react'
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux';

const initialState = {
    id: '',
    name: '',
    email: '',
    password: '',
}
export default function useUpdateUser() {

    const { colors } = useSelector(state => state.color);
    const { user } = useSelector(state => state.user);


    const [state, setState] = useState(initialState);
    const [isLoading, setisLoading] = useState(false);

    const router = useRouter();
    const dispatch = useDispatch();

    useEffect(() => {
        setState(user)
    }, []);

    const handleChange = e => {
        const name = e?.target?.name;
        const value = e?.target?.value;

        setState((state) => ({ ...state, [name]: value }));
    }


    const handleSubmit = async (e) => {

        e.preventDefault();
        setisLoading(true);
        const isValid = checkValidations()
        if (isValid) {

            const updatedUser = await updateUser(state)
            if (updatedUser !== null) {
                dispatch(setUser(updatedUser));
                router.push('/admin/userProfile')
            }
        }
        setisLoading(false);
    };

    const checkValidations = () => {
        if (state.name === '') {
            toast.error("Please enter Name", { duration: 3000 });
            return false;
        }
        if (state.email === '') {
            toast.error("Please enter Email", { duration: 3000 });
            return false;
        }
        if (state.password === '') {
            toast.error("Please enter Password", { duration: 3000 });
            return false;
        }


        return true;
    };



    const updateUser = async (obj) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.UPDATEUSER,
                    payload: {
                        id: obj?.id,
                        name: obj?.name,
                        email: obj?.email,
                        password: obj?.password,
                    }
                })
            })


            const updatedItem = await response.json();
            if (response.status !== 201) {
                toast.error(updatedItem?.message, {
                    duration: 3000,
                });
                setisLoading(false);
                return

            } else {
                toast.success('User Updated Successfully', {
                    duration: 3000,
                });
            }
            setisLoading(false);
            return updatedItem
        } catch (error) {
            console.error("Error updating user:", error);
            setisLoading(false)
        }
    };


    return (
        {
            handleChange,
            handleSubmit,
            colors,
            isLoading,
            state,
        }
    )
}
