import { apitypes } from '@/helper/apitypes';
import { setIsLoggedIn } from '@/redux/features/user/userSlice';
import { useRouter } from 'next/router';
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

const initialState = {
    marqueeId: '',
    sittingPlan: '',
}

export default function useBookTable() {

    const [state, setState] = useState(initialState);
    const [isLoading, setisLoading] = useState(false);

    const { colors } = useSelector(state => state?.color);
    const dispatch = useDispatch();
    const router = useRouter();

    const handleChange = e => {

        const name = e.target.name;
        const value = e.target.value;
        setState(state => ({ ...state, [name]: value }))

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(state);
        router.push(`/marquee/${state.marqueeId}`)
    };

    return (
        {
            handleChange,
            handleSubmit,
            colors,
            isLoading,
        }
    )
}
