import { apitypes } from "@/helper/apitypes";
import { useRouter } from "next/router";
import React, { useState } from "react";
import { toast } from "react-hot-toast";
import { useSelector } from "react-redux";

export default function useOrderDetails() {

    const [isLoading, setisLoading] = useState(false);
    const { colors } = useSelector(state => state?.color);


    const fetchOrderDetails = async (
        id
    ) => {
        try {
            const response = await fetch("/api/operation", {
                method: "POST",
                body: JSON.stringify({
                    type: apitypes.GETORDER,
                    payload: {
                         id,
                    },
                }),
            });


            const OrderDetails = await response.json();
            if (response.status != 201) {
                toast.error(OrderDetails?.message, {
                    duration: 3000,
                });
                setisLoading(false);
                return;
            } else {
                setisLoading(false);
            }

            return OrderDetails;
        } catch (error) {
            console.error("Error Fetching Order:", error);
            setisLoading(false)
        }
    };

    return {
        fetchOrderDetails,
        isLoading,
        colors
    };
}
