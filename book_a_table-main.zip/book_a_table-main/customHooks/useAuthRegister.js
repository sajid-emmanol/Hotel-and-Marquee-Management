import { apitypes } from '@/helper/apitypes';
import { setIsLoggedIn, setUser } from '@/redux/features/user/userSlice';
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useRouter } from 'next/router';
import { toast } from 'react-hot-toast';

const initialState = {
    fName: '',
    lName: '',
    email: '',
    password: '',
}

export default function useAuthRegister() {

    const [state, setState] = useState(initialState);
    const { colors } = useSelector(state => state?.color);
    const [isLoading, setisLoading] = useState(false);


    const dispatch = useDispatch();
    const router = useRouter()

    const handleChange = e => {

        const name = e.target.name;
        const value = e.target.value;

        setState(state => ({ ...state, [name]: value }))

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setisLoading(true);
        const isValid = checkValidations();

        if (isValid) {
            const user = await registerUser(state);
            if (user != null && user.id) {
                if (user){
                    router.push({
                        pathname: '/auth/otp',
                        query: { isForgotPassword: false,userId : user?.id }
                    })
                }
            } else {
                dispatch(setIsLoggedIn(false));
            }
        }

        setisLoading(false);
    };


    const checkValidations = () => {
        if (state.fName === '') {
            toast.error("Please enter First name", { duration: 3000 });
            return false;
        }
        if (state.lName === '') {
            toast.error("Please enter Last name", { duration: 3000 });
            return false;
        }
        if (state.email === '') {
            toast.error("Please enter an Email", { duration: 3000 });
            return false;
        }
        if (state.password === '') {
            toast.error("Please enter a Password", { duration: 3000 });
            return false;
        }

        return true;
    };

    const registerUser = async (obj) => {

        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.CREATEUSER,
                    payload: {
                        name: obj?.fName + " " + obj?.lName,
                        email: obj?.email,
                        password: obj?.password,

                    }
                })
            })

            const newUser = await response.json();
            if (response.status !== 201 || newUser?.message) {
                toast.error(newUser?.message, {
                    duration: 3000,
                });
                setisLoading(false);
                return
            } else {
                toast.success('OTP sent successfully', {
                    duration: 3000,
                });
            }
            setisLoading(false)
            return newUser;
        } catch (error) {
            console.error("Error Sending OTP:", error);
        }
    };



    return (
        {
            handleChange,
            handleSubmit,
            colors,
            isLoading
        }
    )
}
