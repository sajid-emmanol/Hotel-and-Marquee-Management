import { apitypes } from '@/helper/apitypes';
import { setIsLoggedIn, setUser } from '@/redux/features/user/userSlice';
import { useRouter } from 'next/router';
import React, { useState } from 'react'
import { toast } from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux'

const initialState = {
    email: '',
    password: '',
}

export default function useAuthLogIn() {

    const [state, setState] = useState(initialState);
    const [isLoading, setisLoading] = useState(false);

    const { colors } = useSelector(state => state?.color);
    const dispatch = useDispatch();
    const router = useRouter();

    const handleChange = e => {

        const name = e.target.name;
        const value = e.target.value;
        setState(state => ({ ...state, [name]: value }))

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setisLoading(true);
        const isValid = checkValidations();
        if (isValid) {
            const existingUser = await logInUser(state);
            if (existingUser != null && existingUser.id) {
                dispatch(setIsLoggedIn(true));
                dispatch(setUser(existingUser));
                if (existingUser.userType == 'User') {
                    router.push('/')
                } else {
                    router.push('/admin')
                }
            } else {
                dispatch(setIsLoggedIn(false));
            }
        }
        setisLoading(false);
    };

    const checkValidations = () => {
        if (state.email === '') {
            toast.error("Please enter an Email", { duration: 3000 });
            return false;
        }
        if (state.password === '') {
            toast.error("Please enter a Password", { duration: 3000 });
            return false;
        }
        return true;
    };

    const logInUser = async (obj) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.LOGINUSER,
                    payload: {
                        email: obj?.email,
                        password: obj?.password,
                    }
                })
            })
            const existingUser = await response.json();

            if (response.status !== 201 || existingUser === null) {
                toast.error("Failed to LogIn", {
                    duration: 3000,
                });
                setisLoading(false);
                return

            } else {
                toast.success('User LoggedIn Successfully', {
                    duration: 3000,
                });
            }
            setisLoading(false);
            return existingUser;
        } catch (error) {
            console.error("Error Logging In:", error);
        }
    };

    return (
        {
            handleChange,
            handleSubmit,
            colors,
            isLoading,
        }
    )
}
