import { apitypes } from "@/helper/apitypes";
import { setProducts } from "@/redux/features/cart/cartSlice";
import { useRouter } from "next/router";
import React, { useState } from "react";
import { toast } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";

export default function useCreateOrder() {
  const [isLoading, setisLoading] = useState(false);

  const router = useRouter();
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state?.user);
  const refactorItesm = (list) => {
    const itemList = list?.filter((item) => item?.type === "menuItem")?.map((i) => {
      return {
        id: i?.id,
        type: "menuItem",
        item: i?.quantity

      };
    })
    const dealList = list?.filter((item) => item?.type === "deal");
    const dealListItem = dealList?.reduce((acc, item) => {
      return item?.dealItems?.map((i) => {
        return {
          id: i?.itemId,
          type: "deal",
          item: i?.quantity
        };
      });
    }, []);

    const result = itemList.concat(dealListItem)?.reduce((acc, curr) => {
      const existingItem = acc.find(item => item.id === curr.id);

      if (existingItem) {
        existingItem.item += curr.item;
      } else {
        acc.push(curr);
      }

      return acc;
    }, []);
    return result;

  };
  const addOrder = async (price, items) => {
    const isPaymentSuccess = false;
    const status = "INPROGRESS";
    const marqueeId = items[0]?.marqueeId;
    const userId = user?.id;

    const listItem = await refactorItesm(items);

    setisLoading(true);
    const createdOrder = await createOrder(
      price,
      isPaymentSuccess,
      status,
      listItem,
      marqueeId,
      userId
    );
    if (createdOrder != null && createdOrder.id) {
      dispatch(setProducts([]));
      router.push(`/orders/orderDetails/${createdOrder.id}`);
    }
    setisLoading(false);
  };

  const createOrder = async (
    price,
    isPaymentSuccess = false,
    status = "INPROGRESS",
    items,
    marqueeId,
    userId
  ) => {
    try {
      const response = await fetch("/api/operation", {
        method: "POST",
        body: JSON.stringify({
          type: apitypes.CREATEORDER,
          payload: {
            price: price,
            isPaymentSuccess: isPaymentSuccess,
            status: status,
            items: items,
            marqueeId: marqueeId,
            userId: userId,
          },
        }),
      });


      const newItem = await response.json();
      if (response.status != 201) {
        toast.error(newItem?.message, {
          duration: 3000,
        });
        setisLoading(false);
        return;
      } else {
        toast.success("Order Placed Sucessfully", {
          duration: 3000,
        });
        setisLoading(false);
      }

      return newItem;
    } catch (error) {
      console.error("Error creating Order:", error);
      setisLoading(false)
    }
  };

  return {
    addOrder,
    isLoading,
  };
}
