import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { Box, Button, Icon, Image } from '@chakra-ui/react';
import { apitypes } from '@/helper/apitypes';
import { BiPlus } from 'react-icons/bi';
import { useRouter } from 'next/router';

export default function useMarqueeList(marquees) {

    const [isLoading, setIsLoading] = useState(true)
    const [allMarquees, setallMarquees] = useState([])

    const { colors } = useSelector(state => state.color);
    const router = useRouter()

    useEffect(() => {
        setIsLoading(false);
        setallMarquees(marquees);
    }, [])

    const handleDelete = async (id) => {
        const deletedMarquee = await deleteMarquee(id);
        const filteredMarquees = allMarquees.filter((marquee) => {
            return marquee?.id != deletedMarquee?.id
        });
        setallMarquees(filteredMarquees)
    }

    const deleteMarquee = async (id) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.DELETEMARQUEE,
                    payload: {
                        id,
                    }
                })
            })

            const deletedMarquee = await response.json();
            return deletedMarquee;
        } catch (error) {
            console.error("Error Deleting Marquee:", error);
        }
    };



    const columns = [
        {
            name: 'Sr#',
            selector: (row, i) => i + 1,
        },
        {
            name: 'Name',
            selector: row => row.name,
        },
        {
            name: 'Image',
            selector: row => <Box my={3}>
                <Image height={`50px`} width={`50px`} src={row.image} alt={row.name} />
            </Box>,
        },
        {
            name: 'Location',
            selector: row => row.location,
        },
        {
            name: 'City',
            selector: (row) => row.city,
        },
        {
            name: (
                <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, color: colors?.white, opacity: .8 }} onClick={() => router.push('/admin/marquee/create')}>
                    Add
                    <Icon as={BiPlus} />
                </Button>
            )
        }
    ];

    return (
        {
            columns,
            colors,
            isLoading,
            allMarquees
        }
    )
}
