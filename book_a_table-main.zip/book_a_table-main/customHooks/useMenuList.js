import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { Box, Button, Icon, Image } from '@chakra-ui/react';
import { DeleteIcon } from '@chakra-ui/icons';
import { apitypes } from '@/helper/apitypes';
import { BiPlus } from 'react-icons/bi';
import { useRouter } from 'next/router';
import { toast } from 'react-hot-toast';

export default function useMenuList() {



    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingDelete, setIsLoadingDelete] = useState(false);
    const [currentLoaderId, setcurrentLoaderId] = useState(null);
    const [menuItems, setMenuItems] = useState([]);


    const { colors } = useSelector(state => state.color);
    const router = useRouter();
    const {user} = useSelector(state => state.user);

    useEffect(() => {
        setIsLoading(false);
        fetchItems()
    }, []);

    const handleDelete = async (id) => {
        setcurrentLoaderId(id);
        setIsLoadingDelete(true);
        const deletedItem = await deleteItem(id);

        const filteredItems = menuItems.filter((item) => {
            return item?.id != deletedItem?.id
        });
        setMenuItems(filteredItems);
        setIsLoadingDelete(false)
    }

    const deleteItem = async (id) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.DELETEITEM,
                    payload: {
                        id,
                    }
                })
            })
            const deletedItem = await response.json();
            if (response.status != 201) {
                toast.error(deletedItem?.message, {
                    duration: 3000,
                })
                setcurrentLoaderId(null);
                setIsLoadingDelete(false)
                return
            } else {
                toast.success("Item deleted successfully", {
                    duration: 3000
                })
            }
            setcurrentLoaderId(null);
            setIsLoadingDelete(false)
            return deletedItem;
        } catch (error) {
            console.error("Error Deleting item:", error);
        }
    };
    const fetchItems = async () => {
        setIsLoading(true);
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.ALLITEMS,
                    payload: {
                        id : user?.marquee?.id
                    }
                })
            })
            const items = await response.json();

            if (items !== null && items.length > 0) {
                setMenuItems(items);                
            }
            setIsLoading(false)
        } catch (error) {
            console.error("Error Deleting item:", error);
        }
    };




    const columns = [
        {
            name: 'Sr#',
            selector: (row, i) => i + 1,
        },
        {
            name: 'Name',
            selector: row => row.name,
        },
        {
            name: 'Image',
            selector: row => <Box my={3}>
                <Image height={`50px`} width={`50px`} src={row.image} alt={row.name} />
            </Box>,
        },
        {
            name: 'Price',
            selector: row => row.price,
        },
        {
            name: 'Stock',
            selector: (row) => row.stock,
        },
        {
            name: 'Description',
            selector: row => row.desc,
        },

        {
            name: 'Action',
            cell: (row) => <Button bg={'transparent'} _hover={{ bg: 'transparent' }} isLoading={isLoadingDelete && currentLoaderId === row?.id ? true : false} _disabled={{ bg: 'transparent' }}>

                <Icon as={DeleteIcon} color={colors?.primary} boxSize={5} onClick={() => handleDelete(row.id)} />
            </Button>
        },
        {
            name: (
                <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, color: colors?.white, opacity: .8 }} onClick={() => router.push('/admin/menu/create')} >
                    Add
                    <Icon as={BiPlus} />
                </Button>
            )
        }
    ];

    return (
        {
            columns,
            colors,
            isLoading,
            menuItems,
            colors,
        }
    )
}
