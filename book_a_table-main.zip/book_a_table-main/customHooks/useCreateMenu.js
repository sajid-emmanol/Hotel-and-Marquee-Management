import { imageUpload } from '@/componets/imageUpload';
import { apitypes } from '@/helper/apitypes';
import { useRef, useState } from 'react'
import { toast } from 'react-hot-toast';
import { useSelector } from 'react-redux';

const initialState = {
  productName: '',
  price: '',
  stock: '',
  isPopular: '',
  marqueeId: '',
  description: '',
  image: '',
}
export default function useCreateMenu() {

  const { colors } = useSelector(state => state.color);
  const inputRef = useRef();

  const [state, setState] = useState(initialState);
  const [fileName, setFileName] = useState('');
  const [isLoading, setisLoading] = useState(false);
  const { user } = useSelector(state => state?.user)


  const handleChange = e => {
    const name = e?.target?.name;
    const value = e?.target?.value;
    setState((state) => ({ ...state, [name]: value }));
  }


  const handleFile = e => {
    const name = e.target.name;
    const file = e.target.files[0];

    setState((state) => ({ ...state, [name]: file }))
    setFileName(file.name);
  }

  const handleSubmit = async (e) => {

    e.preventDefault();
    setisLoading(true)
    const isValid = checkValidations();
    if (isValid) {
      await uploadImage();
      setState(initialState);
      setFileName('')
    };
    setisLoading(false)
  };

  const checkValidations = () => {
    if (state.productName === '') {
      toast.error("Please enter Product name", { duration: 3000 });
      return false;
    }
    if (state.price === '') {
      toast.error("Please enter Product price", { duration: 3000 });
      return false;
    }
    if (state.stock === '') {
      toast.error("Please enter Product Stock", { duration: 3000 });
      return false;
    }
    if (state.isPopular === '') {
      toast.error("Please select popularity", { duration: 3000 });
      return false;
    }
    // if (state.marqueeId === '') {
    //   toast.error("Please select a Marquee", { duration: 3000 });
    //   return false;
    // }
    if (state.description === '') {
      toast.error("Please enter Product description", { duration: 3000 });
      return false;
    }
    if (state.image === '') {
      toast.error("Please select an image", { duration: 3000 });
      return false;
    }

    return true;
  };

  const uploadImage = async () => {
    const result = await imageUpload(state?.image)
    const createdItem = await createItem(state, result?.url, result?.public_id)

  }

  const createItem = async (obj, imageUrl, publicId) => {

    try {
      const response = await fetch("/api/operation", {
        method: 'POST',
        body: JSON.stringify({
          type: apitypes.CREATEITEM,
          payload: {
            name: obj?.productName,
            price: Number(obj?.price),
            stock: 10,
            isPopular: Boolean(obj?.isPopular),
            marqueeId: user?.userType === "MARQUEE" ? user?.marquee?.id : obj?.marqueeId,
            image: imageUrl,
            desc: obj?.description,
            publicId: String(publicId)
          }
        })
      })

      const newItem = await response.json();
      if (response.status !== 201) {
        toast.error(newItem?.message, {
          duration: 3000,
        });
        setisLoading(false);
        return
      } else {
        toast.success('Item Created Successfully', {
          duration: 3000,
        });
      }
      setisLoading(false);
      return newItem;
    } catch (error) {
      console.error("Error creating item:", error);
      setisLoading(false)
    }
  };


  return (
    {
      handleChange,
      handleFile,
      handleSubmit,
      createItem,
      fileName,
      colors,
      inputRef,
      isLoading,
      state
    }
  )
}
