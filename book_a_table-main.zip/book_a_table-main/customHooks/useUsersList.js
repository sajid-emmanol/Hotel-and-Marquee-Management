import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Icon, Button } from '@chakra-ui/react';
import { DeleteIcon } from '@chakra-ui/icons';
import { apitypes } from '@/helper/apitypes';
import { toast } from 'react-hot-toast';

export default function useUsersList(users) {

    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingDelete, setIsLoadingDelete] = useState(false);
    const [currentLoaderId, setcurrentLoaderId] = useState(null);
    const [allUsers, setallUsers] = useState([])

    const { colors } = useSelector(state => state.color);
    const dispatch = useDispatch();

    useEffect(() => {
        setIsLoading(false);
        setallUsers(users);
    }, []);

    const handleDelete = async (id) => {
        setcurrentLoaderId(id);
        setIsLoadingDelete(true);

        const deletedUser = await deleteUser(id);
        if (deletedUser !== undefined) {
            const filteredUsers = allUsers.filter((user) => {
                return user.id != deletedUser.id;
            });
            setallUsers(filteredUsers);
        }
        setIsLoadingDelete(false);
    };

    const deleteUser = async (id) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.DELETEUSER,
                    payload: {
                        id,
                    }
                })
            })

            const deletedUser = await response.json();
            if (response.status != 201) {
                toast.error(deletedUser?.message, {
                    duration: 3000,
                });
                setcurrentLoaderId(null);
                setIsLoadingDelete(false)
                return
            } else {
                toast.success("User deleted successfully", {
                    duration: 3000
                })
            }
            setcurrentLoaderId(null);
            setIsLoadingDelete(false)
            return deletedUser;
        } catch (error) {
            console.error("Error Deleting User:", error);
        }
    };
    const columns = [
        {
            name: 'Sr#',
            selector: (row, i) => i + 1,
        },
        {
            name: 'Name',
            selector: row => row.name,
        },
        {
            name: 'Email',
            selector: (row) => row.email,
        },
        {
            name: 'Action',
            cell: (row) => <Button bg={'transparent'} _hover={{ bg: 'trasnparent' }} isLoading={isLoadingDelete && currentLoaderId === row?.id ? true : false} _disabled={{ bg: 'transparent' }}>
                <Icon as={DeleteIcon} color={colors?.primary} boxSize={5} onClick={() => handleDelete(row.id)} />
            </Button>
        },
    ];

    return (
        {
            columns,
            colors,
            isLoading,
            allUsers
        }
    )
}
