import { apitypes } from "@/helper/apitypes";
import { Button, Stack } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function useOrdersList() {
    const [isLoading, setIsLoading] = useState(true);
    const [loading, setloading] = useState(false);
    const [currentLoaderId, setcurrentLoaderId] = useState(null);
    const [currentLoaderStatus, setCurrentLoaderStatus] = useState('');
    const [orders, setorders] = useState([]);
    const { colors } = useSelector((state) => state.color);
    const dispatch = useDispatch();

    const { user } = useSelector((state) => state.user);

    let fechOederStatus;
    useEffect(() => {
        fetchOrderData();
        fechOederStatus = setInterval(() => {
            fetchOrderData();
        }, 10000);
    }, []);
    const fetchOrderData = async () => {
        try {
            const response = await fetch("/api/operation", {
                method: "POST",
                body: JSON.stringify({
                    type: apitypes?.ALLORDERS,
                    payload: {
                        id: user?.marquee?.id,
                    },
                }),
            });
            const newItem = await response.json();
            setIsLoading(false);
            setorders(newItem);
        } catch (error) {
            console.error("Error creating deal:", error);
            setIsLoading(false);
        }
    };
    const updateOrderStatus = async (id, status) => {
        setcurrentLoaderId(id);
        setCurrentLoaderStatus(status?.status)
        setloading(true);

        try {
            const response = await fetch("/api/operation", {
                method: "POST",
                body: JSON.stringify({
                    type: apitypes?.UPDATEORDERSTATUS,
                    payload: {
                        id: id,
                        status: status,
                    },
                }),
            });
            const newItem = await response.json();
            setloading(false);
            setcurrentLoaderId(null);
            setCurrentLoaderStatus('')

        } catch (error) {
            console.error("Error creating deal:", error);
            setloading(false);
            setcurrentLoaderId(null);
            setCurrentLoaderStatus('')

        }
    };
    const columns = [
        {
            name: "Sr#",
            selector: (row, i) => i + 1,
        },
        {
            name: "Price",
            selector: (row) => row.price,
        },

        {
            name: "Payment Success",
            selector: (row) => (row.isPaymentSuccess ? "Paid" : "To Be Paid"),
        },
        {
            name: "Status",
            selector: (row) => row.status,
        },
        {
            name: "User Name",
            selector: (row) => row?.user?.name,
        },
        {
            name: "Action",
            cell: (row) => (
                <Stack my={3}>
                    {row?.status === "INPROGRESS" && <>
                        <Button
                            bg={colors?.primary}
                            color={colors?.white}
                            _hover={{ bg: colors?.primary, opacity: 0.8 }}
                            isLoading={loading && currentLoaderStatus === 'COMPLETED' && currentLoaderId === row?.id ? true : false}
                            onClick={() => updateOrderStatus(row?.id, { status: "COMPLETED" })}
                        >
                            Complete
                        </Button>
                        <Button
                            bg={colors?.primary}
                            color={colors?.white}
                            _hover={{ bg: colors?.primary, opacity: 0.8 }}
                            isLoading={loading && currentLoaderStatus === 'CANCELED' && currentLoaderId === row?.id ? true : false}
                            onClick={() => updateOrderStatus(row?.id, { status: "CANCELED" })}
                        >
                            Cancel
                        </Button>
                    </>
                    }

                </Stack>
            ),
        },
    ];

    return {
        columns,
        colors,
        isLoading,
        orders,
    };
}
