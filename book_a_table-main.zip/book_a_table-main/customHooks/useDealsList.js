import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Box, Button, Icon, Image } from '@chakra-ui/react';
import { DeleteIcon } from '@chakra-ui/icons';
import { apitypes } from '@/helper/apitypes';
import { BiPlus } from 'react-icons/bi';
import { useRouter } from 'next/router';
import { toast } from 'react-hot-toast';

export default function useDealsList() {

    const [isLoading, setIsLoading] = useState(true)
    const [isLoadingDelete, setIsLoadingDelete] = useState(false);
    const [currentLoaderId, setcurrentLoaderId] = useState(null);
    const [allDeals, setallDeals] = useState([]);

    const { colors } = useSelector(state => state?.color);
    const { user } = useSelector(state => state?.user);
    const router = useRouter()

    useEffect(() => {
        setIsLoading(false);
        fetchDeals()
    }, []);

    const handleDelete = async (id) => {
        setcurrentLoaderId(id);
        setIsLoadingDelete(true);
        const deletedDeal = await deleteDeal(id);
        const filteredDeals = allDeals.filter(deal => {
            return deal.id != deletedDeal.id;
        });
        setallDeals(filteredDeals);
        setIsLoadingDelete(false);

    };

    const deleteDeal = async (id) => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.DELETEDEAL,
                    payload: {
                        id,
                    }
                })
            })

            const deletedDeal = await response.json();

            if (response.status != 201) {
                toast.error(deletedDeal?.message, {
                    duration: 3000,
                })
                setcurrentLoaderId(null);
                
                setIsLoadingDelete(false)
                return
            } else {
                toast.success("Deal deleted successfully", {
                    duration: 3000
                })
            }
            
            setcurrentLoaderId(null);
            setIsLoadingDelete(false)
            return deletedDeal;
        } catch (error) {
            console.error("Error Deleting Deal:", error);
        }
    };

    const fetchDeals = async () => {
        setIsLoading(true);
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes.ALLDEALS,
                    payload: {
                        id : user?.marquee?.id
                    }
                })
            })
            const items = await response.json();

            if (items !== null && items.length > 0) {
                setallDeals(items);                
            }
            setIsLoading(false)
        } catch (error) {
            console.error("Error Deleting item:", error);
        }
    };

    const columns = [
        {
            name: 'Sr#',
            selector: (row, i) => i + 1,
        },
        {
            name: 'Name',
            selector: row => row.name,
        },
        {
            name: 'Image',
            selector: row => <Box my={3}>
                <Image height={`50px`} width={`50px`} src={row.image} alt={row.name} />
            </Box>
        },
        {
            name: 'Price',
            selector: row => row.price,
        },
        {
            name: 'Actual Price',
            selector: row => row.actualPrice,
        },
        {
            name: 'Discount',
            selector: row => row.discount,
        },
        {
            name: 'Action',
            cell: (row) => <Button bg={'transparent'} _hover={{ bg: 'trasnparent' }} isLoading={isLoadingDelete && currentLoaderId === row?.id ? true : false} _disabled={{ bg: 'transparent' }}>
                <Icon as={DeleteIcon} color={colors?.primary} boxSize={5} onClick={() => handleDelete(row.id)} />
            </Button>
        },
        {
            name: (
                <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, color: colors?.white, opacity: .8 }} onClick={() => router.push('/admin/deals/create')}>
                    Add
                    <Icon as={BiPlus} />
                </Button>
            )
        }

    ];

    return (
        {
            columns,
            colors,
            isLoading,
            allDeals,
            colors,
            setIsLoading,
        }
    )
}
