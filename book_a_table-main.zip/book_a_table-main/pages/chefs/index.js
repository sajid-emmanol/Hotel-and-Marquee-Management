import React from 'react'
import {
    Center,
    Heading,
    Stack,
    Text,
    Box,
    Flex,
    Avatar,
    Grid,
    GridItem
} from '@chakra-ui/react'
import { useSelector } from 'react-redux'
///  Images
import chefImage from '../../public/assets/images/chef_1.jpg'

/// Wrappers
import SocialIcons from '@/common/SocialIcons'
import HeroSection from '@/common/HeroSection'

const cardsData = [
    {
        cardHeading: 'Safdar',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
    {
        cardHeading: 'Ismail',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
    {
        cardHeading: 'Ali',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
    {
        cardHeading: 'Ahmad',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
    {
        cardHeading: 'Subhan',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
    {
        cardHeading: 'Nazeer',
        cardText: `Senior Chef`,
        imagePath: chefImage.src,
    },
]


export default function Chefs() {

    const { colors } = useSelector(state => state?.color);


    return (
        <>
            <HeroSection pageName={'Meet Our Expert Chefs'} />
            <Box bg={colors?.grey}
                p={{ base: '5vw 5vw', md: '5vw 10vw' }}
            >
                <Grid templateColumns={'repeat(3,1fr)'} gap={5}>

                    {cardsData.map((card, i) => {
                        return (
                            <GridItem key={i} colSpan={{ base: 3, md: 1 }}>
                                <Center
                                    pt={6}
                                >
                                    <Box
                                        w={'full'}
                                        bg={colors?.white}
                                        boxShadow={'1xl'}
                                        rounded={'2xl'}
                                        overflow={'hidden'}>
                                        <Flex justify={'center'} mt={10} >
                                            <Avatar
                                                size={'2xl'}
                                                src={
                                                    card.imagePath
                                                }
                                                alt={'Author'}
                                                css={{
                                                    border: `10px solid ${colors?.primary}`,
                                                }}
                                            />
                                        </Flex>

                                        <Box p={6}>
                                            <Stack spacing={0} align={'center'} mb={5}>
                                                <Heading fontSize={'2xl'} fontWeight={'bold'} fontFamily={'body'} _hover={{ color: colors?.primary }}>
                                                    {card?.cardHeading}
                                                </Heading>
                                                <Text color={colors?.secondary}>{card?.cardText}</Text>
                                            </Stack>
                                            <Flex h={{ base: '50', md: 'none' }} alignItems={{ base: 'center', md: 'center' }} justifyContent={{ base: 'center' }}>
                                                <SocialIcons
                                                    iconColor={colors?.primary}
                                                    iconBgColor={colors?.lightRed}
                                                    hoverBgColor={colors?.primary}
                                                    hoverIconColor={colors?.white}
                                                />

                                            </Flex>
                                        </Box>
                                    </Box>
                                </Center>
                            </GridItem>
                        )
                    })}
                </Grid>
            </Box>
        </>
    )
}
