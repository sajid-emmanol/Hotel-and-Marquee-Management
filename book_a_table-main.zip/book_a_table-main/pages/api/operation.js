import { createItem, deleteItem, getAllItems } from "@/prisma/item";
import { createDeal, deleteDeal, getAllDeals } from "@/prisma/deal";
import {
  createOrder,
  getAllOrders,
  getOrder,
  updateOrderStatus,
} from "@/prisma/order";
import { apitypes } from "@/helper/apitypes";
import { createUser, deleteUser, logIn, updatePassword, updateUser } from "@/prisma/user";
import { createMarquee, deleteMarquee } from "@/prisma/marquee";
import prisma from "@/prisma/prisma";
import { generateOTP } from "@/helper/commonFunction";
import { sendBirdEmail } from "@/sendBirdEmail";

export default async function handler(req, res) {
  const { type, payload } = JSON.parse(req.body);
  switch (type) {
    case apitypes.CREATEMARQUEE:
      try {
        const { name, location, city,desc, image, publicId, ownerId } = payload;
        const newMarquee = await createMarquee(
          name,
          location,
          city,
          desc,
          image,
          publicId,
          ownerId
        );
        const user = await prisma.user.update({
          where: {
            id: ownerId,
          },
          data: {
            userType: "MARQUEE",
          },
        });
        res.status(201).json(newMarquee);
      } catch (error) {
        console.error("Error creating Marquee:", error);
        res.status(500).json({ messageerror: "Failed to create Marquee" });
      }
      break;
    case apitypes.DELETEMARQUEE:
      try {
        const { id } = payload;
        const deletedMarquee = await deleteMarquee(id);
        res.status(201).json(deletedMarquee);
      } catch (error) {
        console.error("Error deleting Marquee:", error);
        res.status(500).json({ message: "Failed to delete Marquee" });
      }
      break;
    case apitypes.CREATEITEM:
      try {
        const {
          name,
          price,
          stock,
          isPopular,
          image,
          marqueeId,
          desc,
          size = "NORMAL",
          publicId,
        } = payload;
        const newItem = await createItem(
          name,
          price,
          stock,
          isPopular,
          image,
          marqueeId,
          desc,
          size,
          publicId
        );

        res.status(201).json(newItem);
      } catch (error) {
        console.error("Error creating item:", error);
        res.status(500).json({ message: "Failed to create item" });
      }
      break;

    case apitypes.ALLITEMS:
      try {
        const { id } = payload;
        const items = await getAllItems(id);
        res.status(201).json(items);
      } catch (error) {
        console.error("Error Fetching item:", error);
        res.status(500).json({ message: "Failed to fetch items" });
      }
      break;
    case apitypes.DELETEITEM:
      try {
        const { id } = payload;
        const deletedItem = await deleteItem(id);
        res.status(201).json(deletedItem);
      } catch (error) {
        console.error("Error deleting item:", error);
        res.status(500).json({ message: "Failed to delete item" });
      }
      break;
    case apitypes.CREATEDEAL:
      try {
        const {
          price,
          actualPrice,
          discount,
          name,
          items,
          marqueeId,
          image,
          publicId,
        } = payload;
        const dealItems = items.map((item) => {
          return {
            itemId: item.id,
          };
        });
        const newDeal = await createDeal(
          price,
          actualPrice,
          discount,
          name,
          marqueeId,
          dealItems,
          image,
          publicId
        );
        res.status(201).json(newDeal);
      } catch (error) {
        console.error("Error creating deal:", error);
        res.status(500).json({ message: "Failed to create deal" });
      }
      break;
    case apitypes.DELETEDEAL:
      try {
        const { id } = payload;
        const deletedDeal = await deleteDeal(id);
        res.status(201).json(deletedDeal);
      } catch (error) {
        console.error("Error Deleting Deal:", error);
        res.status(500).json({ message: "Failed to Delete Deal" });
      }
      break;
    case apitypes.ALLDEALS:
      try {
        const { id } = payload;
        const items = await getAllDeals(id);
        res.status(201).json(items);
      } catch (error) {
        console.error("Error Fetching deals:", error);
        res.status(500).json({ message: "Failed to fetch deals" });
      }
      break;
    case apitypes.CREATEORDER:
      try {
        const { price, isPaymentSuccess, status, items, marqueeId, userId } =
          payload;
        const newOrder = await createOrder(
          price,
          isPaymentSuccess,
          status,
          items,
          marqueeId,
          userId
        );
        res.status(201).json(newOrder);
      } catch (error) {
        console.error("Error creating order:", error);
        res.status(500).json({ message: "Failed to create order" });
      }
      break;
    case apitypes.GETORDER:
      try {
        const { id } = payload;
        const orderDetails = await getOrder(id);
        console.log(orderDetails);
        res.status(201).json(orderDetails);
      } catch (error) {
        console.error("Error Fetching  order details:", error);
        res.status(500).json({ message: "Error Fetching  order details" });
      }
      break;
    case apitypes.CREATEUSER:
      try {
        const { name, email, password } = payload;
        const newUser = await createUser(name, email, password);
        const code = generateOTP();
        sendBirdEmail({
          email: newUser.email,
          userName: newUser?.name,
          code: code,
        });
        const user = await prisma.user.update({
          where: {
            id: newUser?.id,
          },
          data: {
            otp: code,
          },
        });
        res.status(201).json(user);
      } catch (error) {
        console.error("Error creating User:", error);
        res.status(500).json({ message: "Failed to create User" });
      }
      break;
    case apitypes.LOGINUSER:
      try {
        const { email, password } = payload;
        const existingUser = await logIn(email, password);
        res.status(201).json(existingUser);
      } catch (error) {
        console.error("Error Logging In:", error);
        res.status(500).json({ message: "Failed to Log In" });
      }
      break;
    case apitypes.DELETEUSER:
      try {
        const { id } = payload;
        const deletedUser = await deleteUser(id);
        res.status(201).json(deletedUser);
      } catch (error) {
        console.error("Error Deleting User:", error);
        res.status(500).json({ message: "Failed to Delete User" });
      }
      break;
    case apitypes.VERIFYOTP:
      try {
        const { id, otp } = payload;
        const user = await prisma.user.findUnique({
          where: { id },
          include: {
            marquee: true,
          },
        });
        if (user?.otp === otp) {
          res.status(201).json(user);
        } else {
          res.status(500).json(null);
        }
      } catch (error) {
        console.error("Error while verifying OTP:", error);
        res.status(500).json({ message: "OTP does not match" });
      }
      break;
    case apitypes.FORGETPASS:
      try {
        const { email } = payload;
        const newUser = await prisma.user.findUnique({
          where: { email: email },
          include: {
            marquee: true,
          },
        });
        const code = generateOTP();
        sendBirdEmail({
          email: newUser.email,
          userName: newUser?.name,
          code: code,
        });
        const user = await prisma.user.update({
          where: {
            id: newUser?.id,
          },
          data: {
            otp: code,
          },
        });
        res.status(201).json(user);
      } catch (error) {
        console.error("Error Sending OTP:", error);
        res.status(500).json({ message: "Failed to Send OTP" });
      }
      break;
    case apitypes.UPDATEUSER:
      try {
        const { id, name, email, password } = payload;
        const updatedUser = await updateUser(id, name, email, password);
        res.status(201).json(updatedUser);
      } catch (error) {
        console.error("Error Updating User:", error);
        res.status(500).json({ message: "Failed to Update User" });
      }
      break;
    case apitypes.UPDATEPASS:
      try {
        const { id, password } = payload;
        const updatedUser = await updatePassword(id, password);
        res.status(201).json(updatedUser);
      } catch (error) {
        console.error("Error Updating User Password:", error);
        res.status(500).json({ message: "Error Updating User Password" });
      }
      break;
    case apitypes.ALLORDERS:
      try {
        const orders = await getAllOrders(payload?.id);

        res.status(201).json(orders);
      } catch (error) {
        console.error("Error Updating User:", error);
        res.status(500).json({ message: "Failed to Update User" });
      }
      break;
    case apitypes.UPDATEORDERSTATUS:
      try {
        const { id, status } = payload;
        const orders = await updateOrderStatus(id, status);
        res.status(201).json(orders);
      } catch (error) {
        console.error("Error Updating User:", error);
        res.status(500).json({ message: "Failed to Update User" });
      }
      break;
    default:
      res.setHeader("Allow", [
        apitypes.CREATEMARQUEE,
        apitypes.DELETEMARQUEE,
        apitypes.CREATEITEM,
        apitypes.CREATEDEAL,
        apitypes.CREATEORDER,
        apitypes.DELETEITEM,
        apitypes.CREATEUSER,
        apitypes.LOGINUSER,
        apitypes.DELETEUSER,
        apitypes.ALLITEMS,
        apitypes.ALLORDERS,
        apitypes.ALLDEALS,
        apitypes.VERIFYOTP,
        apitypes.FORGETPASS,
        apitypes.UPDATEPASS,
      ]);
      res.status(405).end(`type ${type} Not Allowed`);
      break;
  }
}
