// import BillTemplate from '@/utils/BillTemplate'
import { Box, Button, Flex } from '@chakra-ui/react'
import React, { useRef } from 'react'
// import HTML2PDF from 'html2pdf.js';
import ReactToPrint from 'react-to-print';
import dynamic from 'next/dynamic';
import { useSelector } from 'react-redux';
const BillTemplate = dynamic(() => import('../utils/BillTemplate'), { ssr: false });

export default function GeneratePdf({order}) {

  const fileref = useRef(null);
  const { colors } = useSelector(state => state?.color)

  const handlePrint = async () => {

    const { default: HTML2PDF } = await import('html2pdf.js');

    const opt = {
      margin: 10,
      filename: 'Bill.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
    };

    const element = fileref.current;
    HTML2PDF(element, opt)
  };

  return (
    <>
      <Box ref={fileref}>
        <BillTemplate
          order={order}
        />
      </Box>
        <ReactToPrint
          trigger={() => <Flex justifyContent={'flex-end'} px={"10vw"}>
            <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} onClick={handlePrint}>Generate PDF</Button>
          </Flex>
          }
          content={() => fileref.current}
        />

    </>
  )
}
