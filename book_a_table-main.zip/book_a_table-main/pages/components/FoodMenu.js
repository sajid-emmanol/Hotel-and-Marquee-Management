import React from 'react'
import {
    Flex,
    Box,
    Image,
    Icon,
    Stack,
    Grid,
    GridItem,
} from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
/// styles
import styles from '../../styles/Home.module.css'
/// Icons
import { AiOutlineEye } from 'react-icons/ai'
/// Wrapper
import CarouselContainer from '@/common/CarouselContainer'
import { useRouter } from 'next/router';


export default function FoodMenu({ useColorModeValue, cardsData }) {

    const { colors } = useSelector(state => state.color);
    const router = useRouter();

    return (
        <CarouselContainer
            headingText={'Food Menu'}
            subHeadingText={'Popular Delicious Foods'}
            bgColor={colors?.white}
        >
            <Grid
                templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}
                gap={6}
                pt={10}
            >
                {cardsData
                    ?.filter((item) => item.isPopular == true)
                    ?.slice(0, 3)
                    ?.map((card, i) => {
                        return (
                            <GridItem
                                key={i}
                            >
                                <Flex
                                    w="full"
                                    justifyContent={{ base: 'center', md: 'flex-start' }}
                                    alignItems={{ base: 'center', md: 'flex-start' }}
                                >
                                    <Box
                                        bg={'white'}
                                        minW={{ base: 'xs' }}
                                        rounded="lg"
                                        shadow="md"
                                        position="relative"
                                    >
                                        <Image
                                            src={card?.image != '' ? card?.image : 'https://picsum.photos/300'}
                                            alt={`Menu Photo`}
                                            roundedTop="lg"
                                            width={'100%'}
                                            height={'200px'}

                                        />

                                        <Box p="6">
                                            <Flex mt="1"
                                                alignItems={'center'}
                                                flexDirection={'column'}
                                            >
                                                <Box
                                                    fontSize="2xl"
                                                    fontWeight="semibold"
                                                    as="h4"
                                                    lineHeight="tight"
                                                    isTruncated
                                                    color={colors?.secondary}
                                                    _hover={{
                                                        color: colors?.primary

                                                    }}
                                                >
                                                    {card.name}
                                                </Box>
                                                <Box fontSize="1xl" color={'gray.800'}>
                                                    <Box as="span" color={'gray.600'} fontSize="lg">
                                                        $
                                                    </Box>
                                                    {card.price.toFixed(2)}
                                                </Box>
                                                <Box fontSize="1xl" color={'gray.800'}>

                                                    Marquee Name : {card.marquee.name}
                                                </Box>
                                            </Flex>
                                        </Box>
                                        <Flex justifyContent={{ base: 'flex-end' }}
                                            pe={{ base: '10' }}
                                            pb={{ base: '5' }}
                                        >
                                            <Stack
                                                direction={{ base: 'row' }}
                                                spacing={{ base: '3' }}
                                            >
                                                <Flex
                                                    className={styles?.icon_Box}
                                                    w={'40px'}
                                                    h={'40px'}
                                                    borderWidth={'1px'}
                                                    borderRadius={'md'}
                                                    bg={colors?.white}
                                                    color={colors?.primary}
                                                    _hover={{
                                                        bg: colors?.primary,
                                                        color: colors?.white
                                                    }}
                                                    onClick={() => router.push(`/menu/${card.id}`)}
                                                >
                                                    <Icon as={AiOutlineEye} boxSize={5} />
                                                </Flex>

                                            </Stack>
                                        </Flex>


                                    </Box>
                                </Flex>
                            </GridItem>
                        )
                    })}
            </Grid>
        </CarouselContainer>
    )
}
