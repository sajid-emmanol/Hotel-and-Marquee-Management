import React from 'react'
import {
    Image,
    useMediaQuery,
    Box
} from '@chakra-ui/react'
import { Card } from '@chakra-ui/react'
/// Wrappers
import { Carousel } from '@/common/Carousel'

/// Images
import sliderImage1 from '../../public/assets/images/download_slider_1.jpg'


export default function ImageSlider() {

    const [isSmallerScreen] = useMediaQuery('(min-width: 0em) and (max-width: 30em)');
    const [isMediumScreen] = useMediaQuery('(min-width: 30em) and (max-width: 52em)');
    const [isLargerScreen] = useMediaQuery('(min-width: 52em)');

    const ImagesCards = [
        {
            imgPath: sliderImage1.src,

        },
        {
            imgPath: sliderImage1.src,

        },
        {
            imgPath: sliderImage1.src,

        },
        {
            imgPath: sliderImage1.src,

        },

    ]

    return (
        <Box
            p={{ base: '5vw 5vw', md: '5vw 10vw' }}
        >
            <Carousel isSmallerScreen={isSmallerScreen} isMediumScreen={isMediumScreen} isLargerScreen={isLargerScreen}>
                {ImagesCards.map((image, index) => {
                    return (
                        <Card
                            overflow='hidden'
                            boxShadow={'none'}
                            rounded={'none'}
                            key={index}
                        >
                            <Image
                                objectFit='cover'
                                src={image.imgPath}
                                alt='Caffe Latte'
                            />
                        </Card>
                    )
                })}
            </Carousel>
        </Box>


    )
}
