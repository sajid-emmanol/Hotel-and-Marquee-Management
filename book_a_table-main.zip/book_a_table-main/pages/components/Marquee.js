import React, { useEffect, useState } from 'react'
import {
    Flex,
    Box,
    Image,
    Icon,
    Stack,
    Grid,
    GridItem,
} from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { AiOutlineEye } from 'react-icons/ai'
import styles from '../../styles/Home.module.css'
import CarouselContainer from '@/common/CarouselContainer'



export default function Marquee({ useColorModeValue, cardsData }) {

    const [cityName, setcityName] = useState({ cityName: '' });
    const [cities, setcities] = useState([]);
    const { colors } = useSelector(state => state.color);

    const router = useRouter();
    const dispatch = useDispatch();

    useEffect(() => {

        const uniqueCitiesSet = new Set(cardsData?.map(card => card.city));
        const uniqueCities = Array.from(uniqueCitiesSet);
        setcities(uniqueCities);

    }, [cardsData]);


    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        setcityName(s => ({ ...s, [name]: value }))
    };

    return (
        <CarouselContainer
            headingText={'Marquees'}
            subHeadingText={'Popular Marquees'}
            bgColor={colors?.white}
            isMarquee={true}
            handleCityFilter={handleChange}
            cities={cities}
        >
            <Grid
                templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}
                gap={6}
                pt={10}
            >
                {cardsData
                    ?.filter((card) => {
                        if (cityName.cityName == '') {
                            return card
                        } else {
                            return card.city == cityName.cityName
                        }
                    })?.
                    slice(0, 3)
                    ?.map((card, i) => {
                        return (
                            <GridItem
                                key={i}
                            >
                                <Flex
                                    w="full"
                                >
                                    <Box
                                        bg={'white'}
                                        minW={{ base: 'xs' }}
                                        rounded="lg"
                                        shadow="md"
                                        position="relative"
                                    >
                                        <Image
                                            src={card.image != '' ? card.image : `https://picsum.photos/300`}
                                            alt={`Marquee Photo`}
                                            roundedTop="lg"
                                            width={'100%'}
                                            height={'200px'}
                                        />

                                        <Box p="6">
                                            <Flex mt="1"
                                                alignItems={'center'}
                                                flexDirection={'column'}
                                            >
                                                <Box
                                                    fontSize="2xl"
                                                    fontWeight="semibold"
                                                    as="h4"
                                                    lineHeight="tight"
                                                    isTruncated
                                                    color={colors?.secondary}
                                                    _hover={{
                                                        color: colors?.primary

                                                    }}
                                                >
                                                    {card.name}
                                                </Box>
                                            </Flex>
                                        </Box>
                                        <Flex justifyContent={{ base: 'flex-end' }}
                                            pe={{ base: '10' }}
                                            pb={{ base: '5' }}
                                        >
                                            <Stack
                                                direction={{ base: 'row' }}
                                                spacing={{ base: '3' }}
                                            >
                                                <Flex
                                                    className={styles?.icon_Box}
                                                    w={'40px'}
                                                    h={'40px'}
                                                    borderWidth={'1px'}
                                                    borderRadius={'md'}
                                                    bg={colors?.white}
                                                    color={colors?.primary}
                                                    _hover={{
                                                        bg: colors?.primary,
                                                        color: colors?.white
                                                    }}
                                                    onClick={() => router.push(`/marquee/${card.id}`)}
                                                >
                                                    <Icon as={AiOutlineEye} boxSize={5} />
                                                </Flex>

                                            </Stack>
                                        </Flex>
                                    </Box>
                                </Flex>
                            </GridItem>
                        )
                    })}
            </Grid>
        </CarouselContainer>
    )
}
