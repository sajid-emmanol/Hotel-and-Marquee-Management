import React from 'react'
import {
  Flex,
  Box,
  Image,
  Icon,
  Stack,
  Grid,
  GridItem,
} from '@chakra-ui/react';
import { useSelector } from 'react-redux'
import styles from '../../styles/Home.module.css'

/// Wrappers
import CarouselContainer from '@/common/CarouselContainer'

/// Icons
import { AiOutlineEye } from 'react-icons/ai'
import { useRouter } from 'next/router';



export default function Offers({ cardsData }) {

  const { colors } = useSelector(state => state?.color);
  const router = useRouter();

  return (
    <>
      <CarouselContainer
        headingText={` Daily Offer `}
        subHeadingText={`Up To 75% Off For This Day`}
        bgColor={colors?.grey}
      >
        <Grid
          templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}
          gap={6}
          pt={10}
        >
          {cardsData
          ?.slice(0, 3)
            ?.map((card, i) => {
              return (
                <GridItem
                  key={i}
                >
                  <Flex
                    w="full"
                  >
                    <Box
                      bg={'white'}
                      minW={{ base: 'xs' }}
                      rounded="lg"
                      shadow="md"
                      position="relative"
                    >
                      <Image
                        src={card?.image != '' ? card?.image : 'https://picsum.photos/300'}
                        alt={`https://picsum.photos/300`}
                        roundedTop="lg"
                        width={'100%'}
                        height={'200px'}
                      />

                      <Box p="6">
                        <Flex mt="1"
                          alignItems={'center'}
                          flexDirection={'column'}
                        >
                          <Box
                            fontSize="2xl"
                            fontWeight="semibold"
                            as="h4"
                            lineHeight="tight"
                            isTruncated
                            color={colors?.secondary}
                            _hover={{
                              color: colors?.primary

                            }}
                          >
                            {card.name}
                          </Box>
                        </Flex>
                      </Box>
                      <Flex justifyContent={{ base: 'flex-end' }}
                        pe={{ base: '10' }}
                        pb={{ base: '5' }}
                      >
                        <Stack
                          direction={{ base: 'row' }}
                          spacing={{ base: '3' }}
                        >
                          <Flex
                            className={styles?.icon_Box}
                            w={'40px'}
                            h={'40px'}
                            borderWidth={'1px'}
                            borderRadius={'md'}
                            bg={colors?.white}
                            color={colors?.primary}
                            _hover={{
                              bg: colors?.primary,
                              color: colors?.white
                            }}
                            onClick={() => router.push(`/marquee/${card.marqueeId}`)}
                          >
                            <Icon as={AiOutlineEye} boxSize={5} />
                          </Flex>

                        </Stack>
                      </Flex>
                    </Box>
                  </Flex>
                </GridItem>
              )
            })}
        </Grid>


      </CarouselContainer>
    </>
  )
}
