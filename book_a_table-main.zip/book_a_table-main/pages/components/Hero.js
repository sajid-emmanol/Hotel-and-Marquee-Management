import React from 'react'
import { Box, Flex, Text, useColorModeValue } from '@chakra-ui/react'
import styles from '../../styles/Home.module.css'
import { useSelector } from 'react-redux';
import { Image } from '@chakra-ui/react'

/// Slider Image
import sliderImage from '../../public/assets/images/slider_img_1.jpeg';

export default function Hero() {

  const { colors } = useSelector(state => state?.color)

  return (
    <Flex className={` ${styles?.hero_bg}`}
      padding={{ base: '0vw 5vw', md: '0vw 10vw' }}
      bgColor={useColorModeValue(colors?.secondary, 'gray.700')}
      direction={{ base: 'column', lg: 'row' }} py={{ base: '60px', md: 2 }}
    >
      <Flex
        className={styles?.overlay_text}
        direction={'column'}
        px={{ base: '0px', lg: '20px' }}
      >
        <Text
          color={useColorModeValue(colors?.primary, 'gray.700')}
          fontSize={{ base: '2xl', md: '3xl' }} mt={'5'} fontWeight={'bold'}
        >
          Book An Event With Us
        </Text>
        <Text
          fontSize={{ base: '4xl', md: '5xl', lg: '6xl' }}
          color={useColorModeValue(colors?.white, 'gray.700')}
          mt={'1'} lineHeight={{ lg: '70px' }} fontWeight={'bold'}
        >

          Welcome to Our Marquee Hub
        </Text>
        <Text
          fontSize={{ base: '1xl', md: '21px' }}
          color={useColorModeValue(colors?.white, 'gray.700')}
          my={'4'}
        >
          Our platform offers seamless interaction among admin, privileged users, and visitors.
          From reserving exquisite marquees for your special occasions to selecting
          delectable food items and exclusive deals,
          we make event planning a breeze        </Text>
      </Flex>
      <Box
        className={`${styles?.overlay_text}`}
        px={'20px'} mt={{ base: '5', md: '5' }}
        mx={{ base: 'auto', lg: '0px', }}
      >
        <Image src={sliderImage.src}
          borderRadius='full'
          width={{ base: '300px', lg: '700px' }}
          alt='Image Slider'
        />
      </Box>
    </Flex>
  )
}
