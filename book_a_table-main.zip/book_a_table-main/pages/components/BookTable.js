import {  Button, Flex, useColorModeValue } from '@chakra-ui/react'
import React from 'react'
import { useSelector } from 'react-redux';
import styles from '../../styles/Home.module.css'

/// Background Image
import bgImage from '../../public/assets/images/download_img.png'
import { useRouter } from 'next/router';

export default function BookTable() {

    const { colors } = useSelector(state => state?.color);
    const router = useRouter();

    return (
        <Flex className={styles?.bg_img_container}
            _before={{
                backgroundImage: `url(${bgImage.src})`
            }}
            bg={useColorModeValue(colors?.secondary)}
            p={{ base: '15vh 5vw', md: '15vh 10vw' }}
        >
            <Flex
                className={styles?.overlay_text}
                width={'100%'}
                justifyContent={'center'}
            >
                <Button
                    color={useColorModeValue(colors?.white, 'gray.700')}
                    bg={useColorModeValue(colors?.primary, 'gray.700')}
                    _hover={{
                        opacity: 0.9,
                    }}
                    width={'50%'}
                    onClick={() => router.push('/bookTable')}
                >
                    Book A Table
                </Button>
            </Flex>
        </Flex>
    )
}
