import React from "react";
import {
  Center,
  Heading,
  Stack,
  Text,
  Box,
  useMediaQuery,
  Flex,
  Avatar,
} from "@chakra-ui/react";
import { useSelector } from "react-redux";
///  Images
import chefImage from "../../public/assets/images/chef_1.jpg";
import chefImage2 from "../../public/assets/images/chef_2.jpeg";
import chefImage3 from "../../public/assets/images/chef_3.jpeg";

/// Wrappers
import CarouselContainer from "@/common/CarouselContainer";
import { Carousel } from "@/common/Carousel";

/// Icons
import { FaFacebookF } from "react-icons/fa";
import { BsTwitter } from "react-icons/bs";
import { FaLinkedinIn } from "react-icons/fa";
import { BsInstagram } from "react-icons/bs";
import SocialIcons from "@/common/SocialIcons";

const cardsData = [
  {
    cardHeading: "Ali",
    cardText: `Senior Chef`,
    imagePath: chefImage.src,
  },
  {
    cardHeading: "Nazish",
    cardText: `Senior Chef`,
    imagePath: chefImage2.src,
  },
  {
    cardHeading: "Nazim",
    cardText: `Senior Chef`,
    imagePath: chefImage3.src,
  },
];

export default function Team() {
  const { colors } = useSelector((state) => state?.color);
  const [isSmallerScreen] = useMediaQuery(
    "(min-width: 0em) and (max-width: 30em)"
  );
  const [isMediumScreen] = useMediaQuery(
    "(min-width: 30em) and (max-width: 52em)"
  );
  const [isLargerScreen] = useMediaQuery("(min-width: 52em)");

  const socialIcons = [
    {
      name: FaFacebookF,
    },
    {
      name: BsTwitter,
    },
    {
      name: FaLinkedinIn,
    },
    {
      name: BsInstagram,
    },
  ];

  return (
    <>
      <CarouselContainer
        headingText={` Our Team `}
        subHeadingText={`Meet Our Expert Chefs`}
        bgColor={colors?.grey}
      >
        <Carousel
          isSmallerScreen={isSmallerScreen}
          isMediumScreen={isMediumScreen}
          isLargerScreen={isLargerScreen}
        >
          {cardsData.map((card, i) => {
            return (
              <Center
                pt={6}
                key={i}
                _hover={{
                  transform: "translateY(-5px)",
                }}
              >
                <Box
                  w={"full"}
                  bg={colors?.white}
                  boxShadow={"1xl"}
                  rounded={"md"}
                  overflow={"hidden"}
                >
                  <Flex justify={"center"} mt={10}>
                    <Avatar
                      size={"2xl"}
                      src={card.imagePath}
                      alt={"Author"}
                      css={{
                        border: `10px solid ${colors?.primary}`,
                      }}
                    />
                  </Flex>

                  <Box p={6}>
                    <Stack spacing={0} align={"center"} mb={5}>
                      <Heading
                        fontSize={"2xl"}
                        fontWeight={"bold"}
                        fontFamily={"body"}
                        _hover={{ color: colors?.primary }}
                      >
                        {card?.cardHeading}
                      </Heading>
                      <Text color={colors?.secondary}>{card?.cardText}</Text>
                    </Stack>
                    <Flex
                      h={{ base: "50", md: "none" }}
                      alignItems={{ base: "center", md: "center" }}
                      justifyContent={{ base: "center" }}
                    >
                      <SocialIcons
                        iconColor={colors?.primary}
                        iconBgColor={colors?.lightRed}
                        hoverBgColor={colors?.primary}
                        hoverIconColor={colors?.white}
                      />
                    </Flex>
                  </Box>
                </Box>
              </Center>
            );
          })}
        </Carousel>
      </CarouselContainer>
    </>
  );
}
