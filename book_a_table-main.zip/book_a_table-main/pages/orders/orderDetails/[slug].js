import HeroSection from '@/common/HeroSection';
import { Box, Flex, Image, Stack, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react'

/// Images
import orderCompleteImage from '../../../public/assets/images/order_fulfilled.jpg'
import orderInProgressImage from '../../../public/assets/images/order_inprogress.jpg'
import orderCancelledImage from '../../../public/assets/images/order_cancelled.jpg'
import GeneratePdf from '@/pages/generatePdf';
import useOrderDetails from '@/customHooks/useOrderDetails';
import { apitypes } from '@/helper/apitypes';
import Loader from '@/common/Loader';

export default function Order({orderId}) {

    const [order, setorder] = useState(null)
    const [loading, setloading] = useState(true)
    const [error, seterror] = useState('')
    
    let fetchOrderStatus;
    useEffect(() => {
        fetchOrderData()
        fetchOrderStatus =  setInterval(async() => {
           await fetchOrderData()

        }, 10000);
    }, [])
    
    const fetchOrderData = async () => {
        try {
            const response = await fetch("/api/operation", {
                method: 'POST',
                body: JSON.stringify({
                    type: apitypes?.GETORDER,
                    payload: {
                        id: orderId,
                    }
                })
            })
            const newItem = await response.json();
            setloading(false)
            setorder(newItem)
        } catch (error) {
            console.error("Error creating deal:", error);
            setloading(false)
            seterror(error?.message);

        }
    }
    const { colors } = useOrderDetails();
    if (loading) {
        return <Loader />
    }
    if (order?.status === "INPROGRESS") {
        return <>
            <HeroSection pageName={'Order Details'} />
            <Box bg={colors?.white}
                p={{ base: '5vw 5vw', md: '5vw 10vw' }}>
                <Flex alignItems={'center'} direction={'column'}>

                    <Image src={orderInProgressImage.src} alt='' width={400} height={400} />
                    <Stack direction={'row'} alignItems={'center'} mt={5}>

                        <Text fontSize={{ base: '2xl', md: '3xl' }} color={colors?.secondary} fontWeight={'bold'}>Status : </Text>
                        <Text fontSize={{ base: '2xl', md: '3xl' }}>
                            {order?.status}
                        </Text>
                    </Stack>
                </Flex>
            </Box>
        </>
    } else if (order?.status === "COMPLETED") {
        return <>
            <HeroSection pageName={'Order Details'} />
            <Box bg={colors?.white}
                p={{ base: '5vw 5vw', md: '5vw 10vw' }}>
                <Flex justifyContent={'center'}>
                    <Image src={orderCompleteImage.src} alt='' width={200} height={200} />
                </Flex>
                <GeneratePdf order={order} />
            </Box>
        </>
    } else if (order?.status === "CANCELED") {
        return <>
            <HeroSection pageName={"Order Details"} />
            <Box bg={colors?.white}
                p={{ base: '5vw 5vw', md: '5vw 10vw' }}>
                <Flex alignItems={'center'} direction={'column'}>

                    <Image src={orderCancelledImage.src} alt='' width={400} height={400} />
                    <Stack direction={'row'} alignItems={'center'} mt={5}>
                        <Text fontSize={{ base: '2xl', md: '3xl' }} color={colors?.secondary} fontWeight={'bold'}>Status : </Text>
                        <Text fontSize={{ base: '2xl', md: '3xl' }}>
                            {order?.status}
                        </Text>
                    </Stack>
                </Flex>
            </Box>
        </>
    }


}

export async function getServerSideProps(context) {

    const { slug } = context.params;
  
    return {
      props: { orderId:slug }, // Pass the order data to the component as props
    };
  }


