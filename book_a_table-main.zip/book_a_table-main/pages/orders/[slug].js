import { getOrdersById } from '@/prisma/order';
import HeroSection from '@/common/HeroSection'
import {
  Box,
  Grid,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Button,
} from '@chakra-ui/react'
import React from 'react'
import { useSelector } from 'react-redux'
import { useRouter } from 'next/router';



export default function Orders({ orders }) {

  const { colors } = useSelector(state => state.color);
  const router = useRouter();


  return (
    <>
      <HeroSection pageName={'Orders'} />
      <Box bg={colors?.white}
        p={{ base: '5vw 5vw', md: '5vw 10vw' }}
      >
        <Grid templateColumns={'repeat(1,1fr)'}>
          <TableContainer rounded={'md'}>
            <Table variant='simple' bg={colors?.grey}>
              <Thead bg={colors?.primary} >
                <Tr >
                  <Th color={colors?.white}>Sr#</Th>
                  <Th color={colors?.white}>User Name</Th>
                  <Th color={colors?.white} >Price</Th>
                  <Th color={colors?.white} >Items</Th>
                  <Th color={colors?.white} >Status</Th>
                  <Th color={colors?.white} >Action</Th>
                </Tr>
              </Thead>
              <Tbody>
                {orders.map((product, i) => {
                  return <Tr key={i}>
                    <Td>
                      {i + 1}
                    </Td>

                    <Td>{product?.user?.name}</Td>
                    <Td>${product.price}</Td>
                    <Td>{product?.items?.length}</Td>
                    <Td>{product?.status}</Td>
                    <Td>
                      <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} onClick={() => router.push(`/orders/orderDetails/${product?.id}`)}>
                        View
                      </Button>
                    </Td>
                  </Tr>
                })}
              </Tbody>
            </Table>
          </TableContainer>
        </Grid>
      </Box>
    </>
  )
}




export async function getServerSideProps(req, res) {
  const { slug } = req.query;

  try {
    const orders = await getOrdersById(slug);
    return {
      props: {
        orders,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        orders: [],
      },
    };
  }
}
