import React, { useState } from 'react'
import { Box, Grid, GridItem, Text, Button, HStack, Image, Icon, Stack } from '@chakra-ui/react'
import { useSelector } from 'react-redux';
import { getMarquee } from '@/prisma/marquee';
/// Icons
import { FaCity, } from 'react-icons/fa';
import { MdLocationOn } from 'react-icons/md';
/// Components
import HeroSection from '@/common/HeroSection'
/// Tabs
import ItemsTab from './components/ItemsTab';
import DealsTab from './components/DealsTab';



export default function MarqueeDetail({ marquee }) {

  const [currentTab, setcurrentTab] = useState(1);

  const { colors } = useSelector(state => state.color);
  return (
    <>
      <Box as='section'>
        <HeroSection pageName={'Menu Details'} />
      </Box>
      <Grid templateColumns='repeat(3, 1fr)' gap={6} p={{ base: '5vh 5vw', md: '5vh 10vw', lg: '10vh 10vw' }}>
        <GridItem minW={{ base: '2xs', sm: 'xs', md: 'sm', lg: 'lg' }} colSpan={{ base: 3, md: 1 }}>
          <Image
            src={marquee?.image != '' ? marquee?.image : 'https://picsum.photos/300'}
            alt={`Marquee Photo`}
            width={500} height={500} />
        </GridItem>
        <GridItem w='100%' colSpan={{ base: 3, md: 2 }}>
          <Text
            color={colors?.secondary}
            fontSize={{ base: '3xl', md: '4xl' }}
            fontWeight={{ base: 'bold' }}
          >
            {marquee.name}
          </Text>
          <Stack display={'flex'} flexDirection={'row'} alignItems={'center'}>
            <Icon as={MdLocationOn} color={colors?.primary} boxSize={6} />
            <Text
              fontSize={{ base: 'xl' }}
              fontWeight={{ base: 'bold' }}
              color={colors?.secondary}
              py={3}
            >
              {marquee.location}
            </Text>
          </Stack>
          <Stack display={'flex'} flexDirection={'row'} alignItems={'center'}>
            <Icon as={FaCity} color={colors?.primary} boxSize={6} />
            <Text
              fontSize={{ base: 'xl' }}
              fontWeight={{ base: 'bold' }}
              color={colors?.secondary}
              py={3}
            >
              {marquee.city}

            </Text>
          </Stack>
          <Text color={colors?.lightBrown} py={3} textAlign={'justify'}
          >
            {marquee.desc}
          </Text>
        </GridItem>
      </Grid>
      <Box p={{ base: '5vh 5vw', md: '5vh 10vw', lg: '10vh 10vw' }}>
        <HStack gap={0}
          borderBottom={`1px solid ${colors?.primary}`}
        >
          <Button
            borderRadius={'none'}
            onClick={() => setcurrentTab(1)}
            bg={currentTab == 1 && colors?.primary || currentTab == 2 && colors?.grey}
            color={currentTab == 1 && colors?.white}
            _hover={{
              background: currentTab == 1 && colors?.primary
            }}

            px={10}
            py={6}
          >
            <Text>
              Items
            </Text>
          </Button>
          <Button
            borderRadius={'none'}
            onClick={() => setcurrentTab(2)}
            bg={currentTab == 2 && colors?.primary || currentTab == 1 && colors?.grey}
            color={currentTab == 2 && colors?.white}
            _hover={{
              background: currentTab == 2 && colors?.primary
            }}
            px={10}
            py={6}
          >
            <Text>
              Deals
            </Text>
          </Button>
        </HStack>

        {currentTab == 1 ? <ItemsTab cardsData={marquee?.items} /> : <DealsTab cardsData={marquee?.deal} />}
      </Box>
    </>

  )
}


export async function getServerSideProps(req, res) {

  const { slug } = req.query;
  try {
    const marquee = await getMarquee(slug);
    return {
      props: {
        marquee,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        marquee: {},
      },
    };
  }
}


