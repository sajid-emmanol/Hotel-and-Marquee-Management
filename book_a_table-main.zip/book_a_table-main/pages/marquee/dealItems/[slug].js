import React from "react";
import {
  Box,
  Grid,
  GridItem,
  Text,
  Flex,
  Button,
  Image,
} from "@chakra-ui/react";
import { useDispatch, useSelector } from "react-redux";
import { useRouter } from "next/router";
import { addItemToCart } from "@/redux/features/cart/cartSlice";
import { getDeal } from "@/prisma/deal";

/// Components
import HeroSection from "@/common/HeroSection";

export default function DealDetails({ deal }) {
  const dealItems = deal?.dealItems?.map((dealItem) => {
    if (deal?.id == dealItem?.dealId) {
      return dealItem?.item;
    }
  });

  const { colors } = useSelector((state) => state.color);
  const { products } = useSelector((state) => state.cart);

  const dispatch = useDispatch();
  const router = useRouter();

  return (
    <>
      <Box as="section">
        <HeroSection pageName={"Deal Details"} />
      </Box>
      <Box bg={colors?.grey} p={{ base: "5vw 5vw", md: "5vw 10vw" }}>
        <Grid
          templateColumns={{
            base: "repeat(1, 1fr)",
            md: "repeat(2, 1fr)",
            lg: "repeat(3, 1fr)",
          }}
          gap={6}
        >
          {dealItems?.map((card, i) => {
            return (
              <GridItem key={i}>
                <Flex
                  w="full"
                  justifyContent={{ base: "center", md: "flex-start" }}
                  alignItems={{ base: "center", md: "flex-start" }}
                >
                  <Box
                    bg={"white"}
                    minW={{ base: "xs" }}
                    rounded="lg"
                    shadow="md"
                    position="relative"
                  >
                    <Image
                      src={
                        card?.image != ""
                          ? card?.image
                          : "https://picsum.photos/300"
                      }
                      alt={`Deal Photo`}
                      roundedTop="lg"
                      width={"100%"}
                      height={"200px"}
                    />
                    <Box p="6">
                      <Flex
                        mt="1"
                        alignItems={"center"}
                        flexDirection={"column"}
                      >
                        <Box
                          fontSize="2xl"
                          fontWeight="semibold"
                          as="h4"
                          lineHeight="tight"
                          isTruncated
                          color={colors?.secondary}
                          _hover={{
                            color: colors?.primary,
                          }}
                        >
                          {card.name}
                        </Box>
                        <Flex
                          justifyContent="space-between"
                          alignContent="center"
                        ></Flex>
                        <Box fontSize="xl" color={"gray.800"}>
                          <Box as="span" color={"gray.600"} fontSize="lg">
                            $
                          </Box>
                          {card.price.toFixed(2)}
                        </Box>
                      </Flex>
                    </Box>
                  </Box>
                </Flex>
              </GridItem>
            );
          })}
        </Grid>
        <Flex mt={7} justifyContent={"flex-end"}>
          <Button
            mr={5}
            colorScheme="red"
            borderRadius={"3xl"}
            py={6}
            px={10}
            color={colors?.white}
            bg={colors?.primary}
            _hover={{ bg: colors?.secondary }}
            onClick={() => {
              dispatch(addItemToCart({ ...deal, type: "deal" }));
            }}
          >
            <Text>Add To Cart</Text>
          </Button>

          {products?.length > 0 && (
            <Button
              colorScheme="red"
              borderRadius={"3xl"}
              py={6}
              px={10}
              color={colors?.white}
              bg={colors?.primary}
              _hover={{ bg: colors?.secondary }}
              onClick={() => {
                router.push("/cart");
              }}
            >
              <Text>Next</Text>
            </Button>
          )}
        </Flex>
      </Box>
    </>
  );
}

export async function getServerSideProps(req, res) {
  const { slug } = req.query;

  try {
    const deal = await getDeal(slug);

    return {
      props: {
        deal,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        deal: {},
      },
    };
  }
}
