import React from "react";
import {
  Stack,
  Box,
  Flex,
  Grid,
  GridItem,
  Icon,
  Image,
} from "@chakra-ui/react";
import { useSelector } from "react-redux";
import styles from "../../styles/Home.module.css";

/// Icons
import { AiOutlineEye } from "react-icons/ai";
import HeroSection from "@/common/HeroSection";
import { useRouter } from "next/router";
import { getAllMarquees } from "@/prisma/marquee";

export default function Marquee({ marquees }) {
  const { colors } = useSelector((state) => state?.color);
  const router = useRouter();

  return (
    <>
      <HeroSection pageName={"Marquees"} />
      <Box bg={colors?.grey} p={{ base: "5vw 5vw", md: "5vw 10vw" }}>
        <Grid
          templateColumns={{
            base: "repeat(1, 1fr)",
            md: "repeat(2, 1fr)",
            lg: "repeat(3, 1fr)",
          }}
          gap={6}
        >
          {marquees?.map((card, i) => {
            return (
              <GridItem key={i}>
                <Flex
                  w="full"
                  justifyContent={{ base: "center", md: "flex-start" }}
                  alignItems={{ base: "center", md: "flex-start" }}
                >
                  <Box
                    bg={"white"}
                    minW={{ base: "xs" }}
                    rounded="lg"
                    shadow="md"
                    position="relative"
                  >
                    <Image
                      src={
                        card.image != ""
                          ? card.image
                          : "https://picsum.photos/300"
                      }
                      alt={`Marquee Photo`}
                      roundedTop="lg"
                      width={"100%"}
                      height={"200px"}
                    />

                    <Box p="6">
                      <Flex
                        mt="1"
                        alignItems={"center"}
                        flexDirection={"column"}
                      >
                        <Box
                          fontSize="2xl"
                          fontWeight="semibold"
                          as="h4"
                          lineHeight="tight"
                          isTruncated
                          color={colors?.secondary}
                          _hover={{
                            color: colors?.primary,
                          }}
                        >
                          {card.name}
                        </Box>
                      </Flex>
                    </Box>
                    <Flex
                      justifyContent={{ base: "flex-end" }}
                      pe={{ base: "10" }}
                      pb={{ base: "5" }}
                    >
                      <Stack
                        direction={{ base: "row" }}
                        spacing={{ base: "3" }}
                      >
                        <Flex
                          className={styles?.icon_Box}
                          w={"40px"}
                          h={"40px"}
                          borderWidth={"1px"}
                          borderRadius={"md"}
                          bg={colors?.white}
                          color={colors?.primary}
                          _hover={{
                            bg: colors?.primary,
                            color: colors?.white,
                          }}
                          onClick={() => router.push(`/marquee/${card.id}`)}
                        >
                          <Icon as={AiOutlineEye} boxSize={5} />
                        </Flex>
                      </Stack>
                    </Flex>
                  </Box>
                </Flex>
              </GridItem>
            );
          })}
        </Grid>
      </Box>
    </>
  );
}

export async function getServerSideProps() {
  try {
    const marquees = await getAllMarquees();
    return {
      props: {
        marquees,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        marquees: [],
      },
    };
  }
}
