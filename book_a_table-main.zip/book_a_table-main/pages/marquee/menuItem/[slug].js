import React, { useEffect, useState } from 'react'
import { Box, Grid, Image, GridItem, Text, Radio, RadioGroup, Stack, Flex, Input, Icon, Button, useRadioGroup, HStack, Card } from '@chakra-ui/react'
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router'
import { getItem } from '@/prisma/item';
import { incrementCartQuantity, decrementCartQuantity, addItemToCart } from '@/redux/features/cart/cartSlice';
/// styles
import styles from '../../../styles/Menu.module.css';
/// Icons
import { BiMinus } from 'react-icons/bi';
import { IoMdAdd } from 'react-icons/io';
/// Components
import HeroSection from '@/common/HeroSection'

export default function MenuDetail({ item }) {

  const [size, setSize] = useState('LARGE');
  const [quantity, setquantity] = useState(1);



  const { colors } = useSelector(state => state.color);
  const { products } = useSelector(state => state.cart);

  const dispatch = useDispatch();
  const router = useRouter();

  const incrementCount = () => {

    const incrementedCount = quantity < item?.stock ? quantity + 1 : item?.stock;
    setquantity(incrementedCount);
  }
  const decrementCount = () => {

    const decrementedCount = quantity > 1 ? quantity - 1 : 1;
    setquantity(decrementedCount);
  }


  return (
    <>
      <Box as='section'>
        <HeroSection pageName={'Menu Details'} />
      </Box>
      <Grid templateColumns='repeat(3, 1fr)' gap={6} p={{ base: '15vh 5vw', md: '15vh 10vw' }}>
        <GridItem minW={{ base: '2xs', sm: 'xs', md: 'sm', lg: 'lg' }} colSpan={{ base: 3, md: 1 }}>
          <Image
            src={item?.image != '' ? item?.image : 'https://picsum.photos/300'}

            alt={`Menu Photo`} width={500} height={500} />
        </GridItem>
        <GridItem w='100%' colSpan={{ base: 3, md: 2 }}>
          <Text
            color={colors?.secondary}
            fontSize={{ base: '3xl', md: '4xl' }}
            fontWeight={{ base: 'bold' }}
          >
            {item.name}
          </Text>
          <Text
            fontSize={{ base: '2xl' }}
            fontWeight={{ base: 'bold' }}
            color={colors?.secondary}
            py={3}
          >
            ${item.price}
            <Box as='span'
              style={{ textDecoration: 'line-through', textDecorationColor: colors?.secondary }}
              ms={3}
              color={colors?.primary}
              fontSize={{ base: '19px' }}
              fontWeight={{ base: 'semibold' }}
            >
              ${item.price + 70}
            </Box>
          </Text>
          <Text color={colors?.lightBrown} py={3} textAlign={'justify'}
          >
            {item.desc}
          </Text>
       
          <Box>
            <Text
              fontSize={{ base: '17px' }}
              fontWeight={{ base: 'bold' }}
              color={colors?.secondary}
              pb={3}
            >
              Select Size
            </Text>
            <RadioGroup onChange={setSize} value={size} >
              <Stack direction='column'>
                <Radio color={colors?.lightGrey} colorScheme='orange' value='LARGE'>Large</Radio>
                <Radio color={colors?.lightGrey} colorScheme='orange' value='MEDIUM'>Medium</Radio>
                <Radio color={colors?.lightGrey} colorScheme='orange' value='SMALL'>Small</Radio>
              </Stack>
            </RadioGroup>
          </Box>
          
          <Box pt={3} pb={8}>
            <Text
              fontSize={{ base: '17px' }}
              fontWeight={{ base: 'bold' }}
              color={colors?.secondary}
              pb={3}
            >
              Select Quantity
            </Text>
            <Stack direction={'row'} gap={2}>
              <Box
                className={styles?.icon_circle}
                borderRadius={'full'}
                bg={colors?.primary}
                color={colors?.white}
                _hover={{
                  bg: colors?.secondary,
                }}
                onClick={() => {
                  dispatch(decrementCartQuantity({ ...item, size }))
                  decrementCount()
                }

                }
              >
                <Icon as={BiMinus} boxSize={5} />
              </Box>
              <Box width={'60px'}>
                <Input
                  type='number'
                  name='quantity'
                  width={'100%'}
                  borderRadius={'2xl'}
                  borderColor={colors?.lightGrey}
                  value={quantity}
                  readOnly
                />
              </Box>
              <Box
                className={styles?.icon_circle}
                borderRadius={'full'}
                bg={colors?.primary}
                color={colors?.white}
                _hover={{
                  bg: colors?.secondary,
                }}
                onClick={() => {
                  dispatch(incrementCartQuantity({ ...item, size }))
                  incrementCount()
                }}

              >
                <Icon as={IoMdAdd} boxSize={5} />
              </Box>
            </Stack>
          </Box>
          <Stack direction={'row'}>
            <Button colorScheme='red' borderRadius={'3xl'} py={6} px={10} color={colors?.white} bg={colors?.primary} _hover={{ bg: colors?.secondary }} onClick={() => {
              dispatch(addItemToCart({ ...item, size, quantity, type: 'menuItem' }))
            }
            }>
              <Text>
                Add To Cart
              </Text>
            </Button>
            {products?.length > 0 && <Button colorScheme='red' borderRadius={'3xl'} py={6} px={10} color={colors?.white} bg={colors?.primary} _hover={{ bg: colors?.secondary }} onClick={() => router.push('/cart')}>
              <Text>
                Next
              </Text>
            </Button>}

          </Stack>
        </GridItem>
      </Grid>
    </>

  )
}


export async function getServerSideProps(req, res) {

  const { slug } = req.query;

  try {
    const item = await getItem(slug);
    return {
      props: {
        item
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        item: {}
      },
    };
  }
}


