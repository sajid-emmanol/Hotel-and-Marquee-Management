import React, { useState } from 'react'
import {
  Flex,
  Box,
  Image,
  Icon,
  Stack,
  Grid,
  GridItem,
  useDisclosure,
  Button,
  Text,
  Input,
  RadioGroup,
  Radio,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
} from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';

/// styles
import styles from '../../../styles/Home.module.css'
import styles1 from '../../../styles/Menu.module.css'

/// Icons
import { AiOutlineEye } from 'react-icons/ai';
import { RiShoppingBasket2Fill } from 'react-icons/ri';
import { BiMinus } from 'react-icons/bi';
import { IoMdAdd } from 'react-icons/io';

/// Wrapper
import { useRouter } from 'next/router';
import { addItemToCart, decrementCartQuantity, incrementCartQuantity } from '@/redux/features/cart/cartSlice';


export default function ItemsTab({ cardsData }) {

  const [value, setValue] = useState('LARGE');
  const [quantity, setquantity] = useState(1);
  const [currentItem, setcurrentItem] = useState(null);
  
  const { colors } = useSelector(state => state.color);
  const { products } = useSelector(state => state.cart);

  const router = useRouter();
  const dispatch = useDispatch();

  const { isOpen, onOpen, onClose } = useDisclosure();
  const initialRef = React.useRef(null)
  const finalRef = React.useRef(null);


  const incrementCount = () => {
    const incrementedCount = quantity < currentItem?.stock ? quantity + 1 : currentItem?.stock;
    setquantity(incrementedCount);
  }
  const decrementCount = () => {
    const decrementedCount = quantity > 1 ? quantity - 1 : 1;
    setquantity(decrementedCount);
  }

  return (
    <>
      <Grid
        templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}
        gap={6}
        pt={10}
      >
        {cardsData
          ?.map((card, i) => {
            return (
              <GridItem
                key={i}
              >
                <Flex
                  w="full"
                  justifyContent={{ base: 'center', md: 'flex-start' }}
                  alignItems={{ base: 'center', md: 'flex-start' }}
                >
                  <Box
                    bg={'white'}
                    minW={{ base: 'xs' }}
                    rounded="lg"
                    shadow="md"
                    position="relative">

                    <Image
                      src={card?.image != '' ? card?.image : 'https://picsum.photos/300'}

                      alt={`Item Photo`}
                      roundedTop="lg"
                      width={'100%'}
                      height={'200px'}
                    />
                    <Box p="6">
                      <Flex mt="1"
                        alignItems={'center'}
                        flexDirection={'column'}
                      >
                        <Box
                          fontSize="2xl"
                          fontWeight="semibold"
                          as="h4"
                          lineHeight="tight"
                          isTruncated
                          color={colors?.secondary}
                          _hover={{
                            color: colors?.primary

                          }}
                        >
                          {card.name}
                        </Box>
                        <Flex
                          justifyContent="space-between"
                          alignContent="center"
                        >
                        </Flex>
                        <Box fontSize="xl" color={'gray.800'}>
                          <Box as="span" color={'gray.600'} fontSize="lg">
                            $
                          </Box>
                          {card.price.toFixed(2)}
                        </Box>
                      </Flex>
                    </Box>
                    <Flex justifyContent={{ base: 'flex-end' }}
                      pe={{ base: '10' }}
                      pb={{ base: '5' }}
                    >
                      <Stack
                        direction={{ base: 'row' }}
                        spacing={{ base: '3' }}
                      >
                        <Flex
                          className={styles?.icon_Box}
                          w={'40px'}
                          h={'40px'}
                          borderWidth={'1px'}
                          borderRadius={'md'}
                          bg={colors?.white}
                          color={colors?.primary}
                          _hover={{
                            bg: colors?.primary,
                            color: colors?.white
                          }}
                          onClick={() => router.push(`/marquee/menuItem/${card.id}`)}
                        >
                          <Icon as={AiOutlineEye} boxSize={5} />
                        </Flex>
                        <Flex

                          className={styles?.icon_Box}
                          w={'40px'}
                          h={'40px'}
                          borderWidth={'1px'}
                          borderRadius={'md'}
                          bg={colors?.white}
                          color={colors?.primary}
                          _hover={{
                            bg: colors?.primary,
                            color: colors?.white
                          }}
                          onClick={() => {
                            onOpen()
                            setcurrentItem(card)
                          }}
                        >
                          <Icon as={RiShoppingBasket2Fill} boxSize={5} />
                        </Flex>
                      </Stack>
                    </Flex>
                  </Box>
                </Flex>

              </GridItem>
            )
          })}
        <Modal
          initialFocusRef={initialRef}
          finalFocusRef={finalRef}
          isOpen={isOpen}
          onClose={onClose}

        >
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Add Item To Cart</ModalHeader>
            <ModalCloseButton onClick={() => setcurrentItem(null)} />
            <ModalBody pb={6}>
            <Box my={3}>
          <Text
              fontSize={{ base: '17px' }}
              color={colors?.secondary}
            fontWeight={{ base: 'bold' }}
            >
              Stock : {currentItem?.stock}
            </Text>
          </Box>
              <Box>
                <Text
                  fontSize={{ base: '17px' }}
                  fontWeight={{ base: 'bold' }}
                  color={colors?.secondary}
                  pb={3}
                >
                  Select Size
                </Text>
                <RadioGroup onChange={setValue} value={value} >
                  <Stack direction='column'>
                    <Radio color={colors?.lightGrey} colorScheme='orange' value='LARGE'>Large</Radio>
                    <Radio color={colors?.lightGrey} colorScheme='orange' value='MEDIUM'>Medium</Radio>
                    <Radio color={colors?.lightGrey} colorScheme='orange' value='SMALL'>Small</Radio>
                  </Stack>
                </RadioGroup>
              </Box>
              <Box pt={3} pb={8}>
                <Text
                  fontSize={{ base: '17px' }}
                  fontWeight={{ base: 'bold' }}
                  color={colors?.secondary}
                  pb={3}
                >
                  Select Quantity
                </Text>
                <Stack direction={'row'} gap={2}>
                  <Box
                    className={styles1?.icon_circle}
                    borderRadius={'full'}
                    bg={colors?.primary}
                    color={colors?.white}

                    _hover={{
                      bg: colors?.secondary,
                    }}
                    onClick={() => {
                      dispatch(decrementCartQuantity({ ...currentItem, value }))
                      decrementCount()
                    }}
                  >
                    <Icon as={BiMinus} boxSize={5} />
                  </Box>
                  <Box width={'60px'}>
                    <Input
                      type='number'
                      name='quantity'
                      width={'100%'}
                      borderRadius={'2xl'}
                      borderColor={colors?.lightGrey}
                      value={quantity}
                      readOnly
                    />
                  </Box>
                  <Box
                    className={styles1?.icon_circle}
                    borderRadius={'full'}
                    bg={colors?.primary}
                    color={colors?.white}
                    _hover={{
                      bg: colors?.secondary,
                    }}
                    onClick={() => {
                      dispatch(incrementCartQuantity({ ...currentItem, value }))
                      incrementCount()
                    }
                    }
                  >
                    <Icon as={IoMdAdd} boxSize={5} />
                  </Box>
                </Stack>
              </Box>
            </ModalBody>

            <ModalFooter>
              <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} mr={3} onClick={() => {
                dispatch(addItemToCart({ ...currentItem, value, quantity, type: 'menuItem' }))
                onClose();
              }}>
                Add To Cart
              </Button>
              <Button onClick={() => {
                onClose()
                setcurrentItem(null)
              }}>Cancel</Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Grid>
      {products?.length > 0 && <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} w={'100%'} mt={10} onClick={() => router.push('/cart')}>
        View Cart
      </Button>
      }
    </>
  )
}
