import { ChakraProvider } from "@chakra-ui/react";
import { Provider } from "react-redux";
import { useRouter } from "next/router";
import { Toaster } from "react-hot-toast";

import "@/styles/globals.css";
import { store, persistor } from "../redux/store";
import { PersistGate } from "redux-persist/integration/react";

/// Common Compoenents
import Navbar from "@/componets/Navbar";
import TopBar from "@/componets/TopBar";
import Footer from "@/componets/Footer";
import { useEffect } from "react";
import { useState } from "react";
import Loader from "@/common/Loader";

export default function App({ Component, pageProps }) {

  const router = useRouter();
  const [isLoading, setisLoading] = useState(true)
  useEffect(() => {
    setisLoading(false);
  }, [])

  return (
    <Provider store={store}>
      {!isLoading ? <ChakraProvider>
        {!router.pathname.startsWith("/admin") &&
          !router.pathname.startsWith("/auth") && <TopBar />}
        {!router.pathname.startsWith("/admin") &&
          !router.pathname.startsWith("/auth") && <Navbar />}
        <PersistGate loading={null} persistor={persistor}>
          <Component {...pageProps} />
        </PersistGate>
        {!router.pathname.startsWith("/admin") &&
          !router.pathname.startsWith("/auth") && <Footer />}
        <Toaster />
      </ChakraProvider> : <Loader />}
    </Provider>
  );
}
