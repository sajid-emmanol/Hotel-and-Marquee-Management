import React from "react";
import {
  Stack,
  Box,
  Flex,
  Grid,
  GridItem,
  Icon,
  Image,
} from "@chakra-ui/react";
import { useSelector } from "react-redux";
import { useRouter } from "next/router";
import { getAllItems } from "@/prisma/item";

import styles from "../../styles/Home.module.css";
/// Icons
import { AiOutlineEye } from "react-icons/ai";
import HeroSection from "@/common/HeroSection";

export default function Menu({ items }) {
  const { colors } = useSelector((state) => state?.color);
  const router = useRouter();

  return (
    <>
      <HeroSection pageName={"Food Menu"} />
      <Box bg={colors?.grey} p={{ base: "5vw 5vw", md: "5vw 10vw" }}>
        <Grid
          templateColumns={{
            base: "repeat(1, 1fr)",
            md: "repeat(2, 1fr)",
            lg: "repeat(3, 1fr)",
          }}
          gap={6}
        >
          {items?.map((card, i) => {
            return (
              <GridItem key={i}>
                <Flex
                  minW="full"
                  justifyContent={{ base: "center", md: "flex-start" }}
                  alignItems={{ base: "center", md: "flex-start" }}
                >
                  <Box
                    bg={"white"}
                    minW={{ base: "xs" }}
                    rounded="lg"
                    shadow="md"
                    position="relative"
                  >
                    <Image
                      src={
                        card?.image != ""
                          ? card?.image
                          : "https://picsum.photos/300"
                      }
                      alt={`Item Photo`}
                      roundedTop="lg"
                      width={"100%"}
                      height={"200px"}
                    />
                    <Box p="6">
                      <Flex
                        mt="1"
                        alignItems={"center"}
                        flexDirection={"column"}
                      >
                        <Box
                          fontSize="2xl"
                          fontWeight="semibold"
                          as="h4"
                          lineHeight="tight"
                          isTruncated
                          color={colors?.secondary}
                          _hover={{
                            color: colors?.primary,
                          }}
                        >
                          {card.name}
                        </Box>
                        <Box fontSize="md" color={"gray.800"}>
                          <Box as="span" color={"gray.600"} fontSize="lg">
                            $
                          </Box>
                          {card.price.toFixed(2)}
                        </Box>
                        <Box fontSize="md" color={"gray.800"}>
                          Marquee Name : {card.marquee.name}
                        </Box>
                      </Flex>
                    </Box>
                    <Flex
                      justifyContent={{ base: "flex-end" }}
                      pe={{ base: "10" }}
                      pb={{ base: "5" }}
                    >
                      <Stack
                        direction={{ base: "row" }}
                        spacing={{ base: "3" }}
                      >
                        <Flex
                          className={styles?.icon_Box}
                          w={"40px"}
                          h={"40px"}
                          borderWidth={"1px"}
                          borderRadius={"md"}
                          bg={colors?.white}
                          color={colors?.primary}
                          _hover={{
                            bg: colors?.primary,
                            color: colors?.white,
                          }}
                          onClick={() => router.push(`/menu/${card.id}`)}
                        >
                          <Icon as={AiOutlineEye} boxSize={5} />
                        </Flex>
                      </Stack>
                    </Flex>
                  </Box>
                </Flex>
              </GridItem>
            );
          })}
        </Grid>
      </Box>
    </>
  );
}

export async function getServerSideProps() {
  try {
    const items = await getAllItems();
    return {
      props: {
        items,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        items: [],
      },
    };
  }
}
