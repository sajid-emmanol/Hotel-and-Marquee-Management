import React from "react";
import { Box, Grid, GridItem, Text, Image } from "@chakra-ui/react";
import { useSelector } from "react-redux";
import { getItem } from "@/prisma/item";

/// Components
import HeroSection from "@/common/HeroSection";

export default function MenuDetail({ item }) {
  const { colors } = useSelector((state) => state.color);

  return (
    <>
      <Box as="section">
        <HeroSection pageName={"Menu Details"} />
      </Box>
      <Grid
        templateColumns="repeat(3, 1fr)"
        gap={6}
        p={{ base: "15vh 5vw", md: "15vh 10vw" }}
      >
        <GridItem
          minW={{ base: "2xs", sm: "xs", md: "sm", lg: "lg" }}
          colSpan={{ base: 3, md: 1 }}
        >
          <Image
            src={item?.image != "" ? item?.image : "https://picsum.photos/300"}
            alt={`Menu Photo`}
            width={500}
            height={500}
          />
        </GridItem>
        <GridItem w="100%" colSpan={{ base: 3, md: 2 }}>
          <Text
            color={colors?.secondary}
            fontSize={{ base: "3xl", md: "4xl" }}
            fontWeight={{ base: "bold" }}
          >
            {item.name}
          </Text>
          <Text
            fontSize={{ base: "2xl" }}
            fontWeight={{ base: "bold" }}
            color={colors?.secondary}
            py={3}
          >
            ${item.price}
            <Box
              as="span"
              style={{
                textDecoration: "line-through",
                textDecorationColor: colors?.secondary,
              }}
              ms={3}
              color={colors?.primary}
              fontSize={{ base: "19px" }}
              fontWeight={{ base: "semibold" }}
            >
              ${item.price + 70}
            </Box>
          </Text>
          <Text color={colors?.lightBrown} py={3} textAlign={"justify"}>
            {item.desc}
          </Text>
        </GridItem>
      </Grid>
    </>
  );
}

export async function getServerSideProps(req, res) {
  const { slug } = req.query;

  try {
    const item = await getItem(slug);
    console.log(item);
    return {
      props: {
        item,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        item: {},
      },
    };
  }
}
