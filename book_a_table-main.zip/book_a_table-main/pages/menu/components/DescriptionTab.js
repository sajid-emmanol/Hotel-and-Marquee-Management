import React from 'react'
import {
    Grid,
    GridItem,
    Text,
    List,
    ListItem,
    ListIcon,
} from '@chakra-ui/react'
import {BsCheck2Circle} from 'react-icons/bs'
import { useSelector } from 'react-redux';


export default function DescriptionTab() {

    const {colors} = useSelector(state => state?.color)

    return (
        <Grid templateRows={'repeat(1,1fr)'} mt={5}>
            <GridItem >
                <Text textAlign={'justify'}>
                    Ipsum dolor, sit amet consectetur adipisicing elit. Doloribus consectetur ullam in? Beatae, dolorum ad ea deleniti ratione voluptatum similique omnis voluptas tempora optio soluta vero veritatis reiciendis blanditiis architecto. Debitis nesciunt inventore voluptate tempora ea incidunt iste, corporis, quo cumque facere doloribus possimus nostrum sed magni quasi, assumenda autem! Repudiandae nihil magnam provident illo alias vero odit repellendus, ipsa nemo itaque. Aperiam fuga, magnam quia illum minima blanditiis tempore. vero veritatis reiciendis blanditiis architecto. Debitis nesciunt inventore voluptate tempora ea incidunt iste, corporis, quo cumque facere doloribus possimus nostrum sed magni quasi
                </Text>
            </GridItem>
            <Grid templateColumns={'repeat(2,1fr)'} mt={3} gap={3}>
                <GridItem  colSpan={{base : 2,md:1}}>
                    <List spacing={3}>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Assumenda, quia temporibus eveniet a libero incidunt suscipit
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Quidem, ipsam illum quis sed voluptatum quae eum fugit earum
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Quidem, ipsam illum quis sed voluptatum quae eum fugit earum
                        </ListItem>
                    </List>
                </GridItem>
                <GridItem  colSpan={{base : 2,md:1}}>
                <List spacing={3}>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Assumenda, quia temporibus eveniet a libero incidunt suscipit
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Quidem, ipsam illum quis sed voluptatum quae eum fugit earum
                        </ListItem>
                        <ListItem>
                            <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                            Quidem, ipsam illum quis sed voluptatum quae eum fugit earum
                        </ListItem>
                    </List>
                </GridItem>
            </Grid>
            
        </Grid>
    )
}
