import {
    Avatar, Grid, GridItem, Stack, Text,
    FormControl,

    Input,

    Button,

    Textarea,
    HStack,
} from '@chakra-ui/react'
import React from 'react'
import { useSelector } from 'react-redux';
import userImg from '../../../public/assets/images/chef_1.jpg'
import Ratings from '@/common/Ratings';


export default function ReviewTab() {

    const { colors } = useSelector(state => state?.color);

    const reviews = [
        {
            imageUrl: userImg.src,
            userName: 'Michal Holder',
            date: '29 Oct 2022',
            reviewText: `Sure there isn't anything embarrassing hiidden in the middles of text. All erators on the Internet tend to repeat predefined chunks.`,
            rating: {
                rating: 4,
                numOfReviews: 20,
            }
        },
        {
            imageUrl: userImg.src,
            userName: 'Joseph',
            date: '29 Oct 2022',
            reviewText: `Sure there isn't anything embarrassing hiidden in the middles of text. All erators on the Internet tend to repeat predefined chunks.`,
            rating: {
                rating: 3,
                numOfReviews: 30,
            }
        },
        {
            imageUrl: userImg.src,
            userName: 'John',
            date: '29 Oct 2022',
            reviewText: `Sure there isn't anything embarrassing hiidden in the middles of text. All erators on the Internet tend to repeat predefined chunks.`,
            rating: {
                rating: 5,
                numOfReviews: 20,
            }
        },
    ]

    return (
        <>
            <Grid templateColumns={'repeat(3,1fr)'} gap={3} mt={5}>
                <GridItem bg={colors?.grey} colSpan={{ base: 3, md: 2 }}>
                    {reviews.map((review, i) => {
                        return <Grid
                            key={i}
                            templateColumns={'repeat(5,1fr)'}
                            gap={5} py={7} mx={7}
                            _notLast={{
                                borderBottom: `1px solid ${colors?.primary}`
                            }}
                            _last={{
                                borderBottom: 'none'
                            }}
                        >
                            <GridItem colSpan={{ base: 5, md: 1 }} >
                                <Avatar size={'2xl'} src={review.imageUrl} border={`5px solid ${colors?.white}`} />
                            </GridItem>
                            <GridItem colSpan={{ base: 5, md: 4 }} pe={5}>
                                <Stack gap={1}>
                                    <Text
                                        fontSize={'2xl'}
                                        fontWeight={{ base: 'bold' }}
                                        color={colors?.secondary}
                                    >
                                        {review.userName}
                                    </Text>
                                    <Text
                                        color={colors?.primary}

                                    >
                                        {review.date}
                                    </Text>
                                    <Ratings rating={review.rating.rating} numReviews={review.rating.numOfReviews} />
                                    <Text
                                        color={colors?.lightBrown}
                                        fontSize={{ base: 'md' }}
                                    >
                                        {review.reviewText}
                                    </Text>
                                </Stack>
                            </GridItem>

                        </Grid>
                    })}
                </GridItem>
                <GridItem bg={colors?.grey} colSpan={{ base: 3, md: 1 }}>
                    <Stack my={10} mx={5} gap={5}>
                        <HStack>
                            <Text color={colors?.lightBrown} fontSize={'16px'}>
                                Select Your Rating :
                            </Text>
                        </HStack>

                        <FormControl id="name" >
                            <Input type="text" name='name' variant={'filled'} bg={colors?.white} placeholder='Name' />
                        </FormControl>
                        <FormControl id="email">
                            <Input type="email" name='email' variant={'filled'} bg={colors?.white} placeholder='Email' />
                        </FormControl>
                        <Textarea
                            variant={'filled'}
                            bg={colors?.white}
                            placeholder='Write Your Review'
                            size='sm'
                        />
                        <Stack spacing={10}>

                            <Button
                                bg={colors?.primary}
                                color={colors?.white}
                                _hover={{
                                    bg: colors?.secondary,
                                }}
                                rounded={'full'}
                                py={7}
                                width={'50%'}
                            >
                                Submit Review
                            </Button>
                        </Stack>
                    </Stack>
                </GridItem>
            </Grid>
        </>
    )
}
