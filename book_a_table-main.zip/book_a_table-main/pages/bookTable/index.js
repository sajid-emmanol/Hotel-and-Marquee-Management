import React from 'react'
import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Stack,
    Button,
    Heading,
    Select
} from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import useBookTable from '@/customHooks/useBookTable';
import { getAllMarquees } from '@/prisma/marquee';
export default function BookTable({ marquees }) {

    const { colors, handleChange, handleSubmit, isLoading } = useBookTable();

    return (
        <>
            <Flex
                align={'center'}
                justify={'center'}
                minH={'100vh'}
                bg={colors?.lightRed}
                bgGradient={`linear(to-bl,  ${colors?.secondary}, ${colors?.red})`}
            >
                <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>
                    <Box
                        rounded={'2xl'}
                        bg={colors?.white}
                        // color={colors?.white}
                        boxShadow={'lg'}
                        py={8}
                        px={10}
                    >
                        <Stack spacing={4} >
                            <Stack align={'center'}>
                                <Heading letterSpacing={2} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                    Book Table
                                </Heading>
                            </Stack>
                            <form onSubmit={e => handleSubmit(e)}>

                                <FormControl isRequired py={3}>
                                    <FormLabel>Marquee Name</FormLabel>
                                    <Select placeholder='--Select Marquee--' name='marqueeId' onChange={e => handleChange(e)}>
                                        {marquees.map((marquee, i) => {
                                            return <option key={i} value={marquee.id}>{marquee.name}</option>

                                        })}
                                    </Select>
                                </FormControl>
                                <FormControl isRequired pb={3}>
                                    <FormLabel>
                                        Sitting Plan
                                    </FormLabel>
                                    <Select placeholder='--Select Sitting Plan--' name='sittingPlan' onChange={e => handleChange(e)}>
                                        <option value='option1'>Family</option>
                                        <option value='option2'>Friends</option>
                                        <option value='option3'>Single Person</option>
                                    </Select>
                                </FormControl>
                                <Stack spacing={10} pt={2} >
                                    <Button
                                        loadingText="Submitting"
                                        size="lg"
                                        bg={colors?.primary}
                                        color={colors?.white}
                                        _hover={{
                                            bg: colors?.primary,
                                            opacity: .8
                                        }}
                                        onClick={e => {
                                            handleSubmit(e)

                                        }}
                                        isLoading={isLoading}
                                    >
                                        Continue
                                    </Button>
                                </Stack>
                            </form>

                        </Stack>
                    </Box>
                </Stack>
            </Flex>
        </>
    )
};

export async function getServerSideProps() {
    try {
        const marquees = await getAllMarquees();
        return {
            props: {
                marquees,
            },
        };
    } catch (error) {
        console.error("Error fetching Marquees:", error);
        return {
            props: {
                marquees: [],
            },
        };
    }
}

