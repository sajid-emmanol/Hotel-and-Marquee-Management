import HeroSection from '@/common/HeroSection'
import { decrementCartQuantity, incrementCartQuantity, removeSingleProduct } from '@/redux/features/cart/cartSlice';
import {
    Box,
    Grid,
    Table,
    Thead,
    Tbody,
    Tr,
    Th,
    Td,
    TableContainer,
    Icon,
    Image,
    Stack,
    Input,
    Text,
    Flex,
    Button
} from '@chakra-ui/react'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { DeleteIcon } from '@chakra-ui/icons';

import styles from '../../styles/Menu.module.css'

/// Icons
import { BiMinus } from 'react-icons/bi';
import { IoMdAdd } from 'react-icons/io';
import useCreateOrder from '@/customHooks/useCreateOrder';
import { useRouter } from 'next/router';



export default function Cart() {

    const dispatch = useDispatch();
    const router = useRouter();
    const { products } = useSelector(state => state.cart);
    const { colors } = useSelector(state => state.color);
    const { isLoggedIn,user } = useSelector(state => state.user);
    const { addOrder, isLoading } = useCreateOrder();

    const productsPrice = products.map((product) => {
        if (product.type == 'menuItem') {
            return product.quantity * product.price
        } else {
            return product.price
        }
    });
    const totalPrice = productsPrice.reduce(
        (acc, currentPrice) => acc + currentPrice,
        0
    );

    return (
        <>
            <HeroSection pageName={'Cart'} />
            <Box bg={colors?.white}
                p={{ base: '5vw 5vw', md: '5vw 10vw' }}
            >
                <Grid templateColumns={'repeat(1,1fr)'}>
                    <TableContainer rounded={'md'}>
                        <Table variant='simple' bg={colors?.grey}>
                            <Thead bg={colors?.primary} >
                                <Tr >
                                    <Th color={colors?.white}>Image</Th>
                                    <Th color={colors?.white}>Details</Th>
                                    <Th color={colors?.white} >Price</Th>
                                    <Th color={colors?.white} >Action</Th>
                                    <Th color={colors?.white} >Quantity</Th>
                                    <Th color={colors?.white} >Total</Th>
                                    <Th color={colors?.white} >Action</Th>
                                </Tr>
                            </Thead>
                            <Tbody>
                                {products.map((product, i) => {
                                    return <Tr key={i}>
                                        {product.type == 'menuItem' ? <Td>
                                            <Image src={product.image} width={'60px'} height={'60px'} alt={"Product Image"} />
                                        </Td> : <Td>
                                            <Image src={"https://picsum.photos/200"} width={'60px'} height={'60px'} alt={"Product Image"} />
                                        </Td>}

                                        <Td>{product.name}</Td>
                                        <Td>${product.price}</Td>
                                        {product.type == 'menuItem' ? <Td>
                                            <Stack direction={'row'} gap={2}>
                                                <Box
                                                    className={styles?.icon_circle}
                                                    borderRadius={'full'}
                                                    bg={colors?.primary}
                                                    color={colors?.white}
                                                    _hover={{
                                                        bg: colors?.secondary,
                                                    }}
                                                    onClick={() => dispatch(decrementCartQuantity({ ...product }))}
                                                >
                                                    <Icon as={BiMinus} boxSize={5} />
                                                </Box>
                                                <Box width={'60px'}>
                                                    <Input
                                                        type='number'
                                                        name='quantity'
                                                        width={'100%'}
                                                        borderRadius={'2xl'}
                                                        borderColor={colors?.lightGrey}
                                                        value={product.type == 'menuItem' && product.quantity}
                                                        readOnly
                                                    />
                                                </Box>
                                                <Box
                                                    className={styles?.icon_circle}
                                                    borderRadius={'full'}
                                                    bg={colors?.primary}
                                                    color={colors?.white}
                                                    _hover={{
                                                        bg: colors?.secondary,
                                                    }}
                                                    onClick={() => dispatch(incrementCartQuantity({ ...product }))}
                                                >
                                                    <Icon as={IoMdAdd} boxSize={5} />
                                                </Box>
                                            </Stack>
                                        </Td> : <Td></Td>}

                                        {product.type == 'menuItem' ? <Td>{product.quantity}</Td> : <Td></Td>}
                                        {product.type == 'menuItem' ? <Td>{product.price * product.quantity}</Td> : <Td>{product.price}</Td>}
                                        <Td><Icon color={colors?.primary} as={DeleteIcon} boxSize={5} onClick={() => dispatch(removeSingleProduct(product))} /></Td>
                                    </Tr>
                                })}


                            </Tbody>
                        </Table>
                    </TableContainer>
                </Grid>
                <Flex justifyContent={'flex-end'} mt={5}>
                    <Box width={'250px'} height={'50px'} bg={colors?.grey} display={'flex'} justifyContent={'center'} alignItems={'center'}>
                        <Text>
                            Total Price : ${totalPrice}
                        </Text>
                    </Box>
                </Flex>
                {products.length > 0 && <Flex justifyContent={'flex-end'} mt={5} >
                    <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} onClick={() => addOrder(totalPrice, products)} isLoading={isLoading} isDisabled={isLoggedIn ? false : true}>
                        Place Order
                    </Button>
                </Flex>}


            </Box>
        </>
    )
}
