import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    InputGroup,
    InputRightElement,
    Stack,
    Button,
    Heading,
    Text,
    Link,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import Loader from '@/common/Loader';
import useAuthForgotPassword from '@/customHooks/useAuthForgotPassword';

export default function Login() {

    const [isPageLoading, setisPageLoading] = useState(false);
    const { colors, handleChange, handleSubmit, isLoading } = useAuthForgotPassword();
    const router = useRouter()



    return (
        <>
            {isPageLoading ? <Loader /> : <Flex
                align={'center'}
                justify={'center'}
                minH={'100vh'}
                bg={colors?.grey}
                bgGradient={`linear(to-bl, ${colors?.primary}, ${colors?.secondary}, ${colors?.red})`}
            >
                <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>
                    <Box
                        rounded={'2xl'}
                        bg={colors?.white}
                        boxShadow={'lg'}
                        py={8}
                        px={10}
                    >
                        <Stack spacing={4} >
                            <Stack align={'center'}>
                                <Heading letterSpacing={2} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                    Email
                                </Heading>
                            </Stack>
                            <form onSubmit={e => handleSubmit(e)}>

                                <FormControl id="email" isRequired py={3}>
                                    <FormLabel>Email address</FormLabel>
                                    <Input type="email" name='email' onChange={e => handleChange(e)} />
                                </FormControl>
                                <Stack spacing={10} pt={2} >
                                    <Button
                                        loadingText="Submitting"
                                        size="lg"
                                        bg={colors?.primary}
                                        color={colors?.white}
                                        _hover={{
                                            bg: colors?.primary,
                                            opacity: .8
                                        }}
                                        onClick={e => handleSubmit(e)}
                                        isLoading={isLoading}
                                    >
                                        Send OTP
                                    </Button>
                                </Stack>
                            </form>
                        </Stack>
                    </Box>
                </Stack>
            </Flex>}


        </>
    );
}


