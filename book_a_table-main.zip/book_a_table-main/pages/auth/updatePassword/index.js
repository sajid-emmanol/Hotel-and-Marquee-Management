import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    InputGroup,
    InputRightElement,
    Stack,
    Button,
    Heading,
} from '@chakra-ui/react';
import { useState } from 'react';
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import Loader from '@/common/Loader';
import useAuthUpdate from '@/customHooks/useAuthUpdate';

export default function UpdatePassword({userId}) {

    const [isPageLoading, setisPageLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [viewId, setViewId] = useState(null);
    const { colors, handleChange, handleSubmit, isLoading } = useAuthUpdate(userId);


    return (
        <>
            {isPageLoading ? <Loader /> : <Flex
                align={'center'}
                justify={'center'}
                minH={'100vh'}
                bg={colors?.grey}
                bgGradient={`linear(to-bl, ${colors?.primary}, ${colors?.secondary}, ${colors?.red})`}
            >
                <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>
                    <Box
                        rounded={'2xl'}
                        bg={colors?.white}
                        boxShadow={'lg'}
                        py={8}
                        px={10}
                    >
                        <Stack spacing={4} >
                            <Stack align={'center'}>
                                <Heading letterSpacing={2} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                    UPDATE
                                </Heading>
                            </Stack>
                            <form onSubmit={e => handleSubmit(e)}>


                                <FormControl id="password" isRequired pb={3}>
                                    <FormLabel>New Password</FormLabel>
                                    <InputGroup>
                                        <Input type={showPassword && viewId === 1 ? 'text' : 'password'} name='password1' placeholder='Type Password' onChange={e => handleChange(e)} />
                                        <InputRightElement h={'full'}>
                                            <Button
                                                variant={'unstyled'}
                                                onClick={() => {

                                                    setShowPassword((showPassword) => !showPassword)
                                                    setViewId(1)
                                                }
                                                }>
                                                {showPassword && viewId === 1 ? <ViewIcon /> : <ViewOffIcon />}
                                            </Button>
                                        </InputRightElement>
                                    </InputGroup>
                                </FormControl>
                                <FormControl id="password" isRequired pb={3}>
                                    <FormLabel>Confirm Password</FormLabel>
                                    <InputGroup>
                                        <Input type={showPassword && viewId === 2 ? 'text' : 'password'} name='password2' placeholder='Re-type Password' onChange={e => handleChange(e)} />
                                        <InputRightElement h={'full'}>
                                            <Button
                                                variant={'unstyled'}
                                                onClick={() => {

                                                    setShowPassword((showPassword) => !showPassword)
                                                    setViewId(2)
                                                }
                                                }>
                                                {showPassword && viewId === 2 ? <ViewIcon /> : <ViewOffIcon />}
                                            </Button>
                                        </InputRightElement>
                                    </InputGroup>
                                </FormControl>
                                <Stack spacing={10} pt={2} >
                                    <Button
                                        loadingText="Submitting"
                                        size="lg"
                                        bg={colors?.primary}
                                        color={colors?.white}
                                        _hover={{
                                            bg: colors?.primary,
                                            opacity: .8
                                        }}
                                        onClick={e => handleSubmit(e)}
                                        isLoading={isLoading}
                                    >
                                        Update
                                    </Button>
                                </Stack>
                            </form>
                        </Stack>
                    </Box>
                </Stack>
            </Flex>}


        </>
    );
}


export async function getServerSideProps(context) {

    const {userId} = context?.query;
    
    

    try {
      return {
        props: {
            userId : userId,
        },
      };
    } catch (error) {
      return {
        props: {
        },
      };
    }
  }
  