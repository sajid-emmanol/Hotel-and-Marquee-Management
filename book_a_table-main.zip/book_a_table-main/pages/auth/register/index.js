import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    InputGroup,
    HStack,
    InputRightElement,
    Stack,
    Button,
    Heading,
    Text,
    Link,
} from '@chakra-ui/react';
import { useState } from 'react';
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import { useRouter } from 'next/router';
import useAuthRegister from '@/customHooks/useAuthRegister';

export default function Register() {

    const [showPassword, setShowPassword] = useState(false);
    const { colors, handleChange, handleSubmit, isLoading } = useAuthRegister();

    const router = useRouter()

    return (
        <>
            <Flex
                align={'center'}
                justify={'center'}
                minH={'100vh'}
                bg={colors?.grey}
                bgGradient={`linear(to-bl, ${colors?.primary}, ${colors?.secondary}, ${colors?.red})`}
            >
                <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>

                    <Box
                        rounded={'2xl'}
                        bg={colors?.white}
                        boxShadow={'lg'}
                        p={8}
                    >
                        <Stack spacing={4} >
                            <Stack align={'center'}>
                                <Heading letterSpacing={2} pb={3} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                    REGISTER
                                </Heading>
                            </Stack>
                            <form onSubmit={e => handleSubmit(e)}>
                                <HStack>
                                    <Box>
                                        <FormControl id="firstName" isRequired>
                                            <FormLabel>First Name</FormLabel>
                                            <Input type="text" name='fName' onChange={e => handleChange(e)} />
                                        </FormControl>
                                    </Box>
                                    <Box>
                                        <FormControl id="lastName">
                                            <FormLabel>Last Name</FormLabel>
                                            <Input type="text" name='lName' onChange={e => handleChange(e)} />
                                        </FormControl>
                                    </Box>
                                </HStack>
                                <FormControl id="email" isRequired py={3}>
                                    <FormLabel>Email address</FormLabel>
                                    <Input type="email" name='email' onChange={e => handleChange(e)} />
                                </FormControl>
                                <FormControl id="password" isRequired pb={3}>
                                    <FormLabel>Password</FormLabel>
                                    <InputGroup>
                                        <Input type={showPassword ? 'text' : 'password'} name='password' onChange={e => handleChange(e)} />
                                        <InputRightElement h={'full'}>
                                            <Button
                                                variant={'unstyled'}
                                                onClick={() =>
                                                    setShowPassword((showPassword) => !showPassword)
                                                }>
                                                {showPassword ? <ViewIcon /> : <ViewOffIcon />}
                                            </Button>
                                        </InputRightElement>
                                    </InputGroup>
                                </FormControl>
                                <Stack spacing={10} pt={2}>
                                    <Button
                                        loadingText="Submitting"
                                        size="lg"
                                        bg={colors?.primary}
                                        color={colors?.white}
                                        _hover={{
                                            bg: colors?.primary,
                                            opacity: .8
                                        }}
                                        onClick={e => handleSubmit(e)}
                                        isLoading={isLoading}
                                    >
                                        Register
                                    </Button>
                                </Stack>
                            </form>
                            <Stack pt={2}>
                                <Text align={'center'}>
                                    Already have an account? <Link onClick={() => router.push('/auth/login')} color={'blue.400'}>Login</Link>
                                </Text>
                            </Stack>
                        </Stack>
                    </Box>
                </Stack>
            </Flex>

        </>
    );
}
