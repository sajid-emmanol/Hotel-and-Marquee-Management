import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    InputGroup,
    InputRightElement,
    Stack,
    Button,
    Heading,
    Text,
    Link,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import { useRouter } from 'next/router';
import useAuthLogIn from '@/customHooks/useAuthLogIn';
import { useSelector } from 'react-redux';
import Loader from '@/common/Loader';

export default function Login() {

    const [isPageLoading, setisPageLoading] = useState(true);
    const [showPassword, setShowPassword] = useState(false);
    const { colors, handleChange, handleSubmit, isLoading } = useAuthLogIn();
    const { isLoggedIn, user } = useSelector(state => state.user);

    const router = useRouter();

    const keys = Object.keys(user);

    useEffect(() => {
        if (keys.length === 0) {

        } else if (user.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
            router.push('/admin');
        } else if (user.userType === 'User') {
            router.push('/');
        }
        setisPageLoading(false);
    }, [isLoggedIn, router, keys.length, user.userType]);

    return (
        <>
            {isPageLoading ? <Loader /> : <Flex
                align={'center'}
                justify={'center'}
                minH={'100vh'}
                bg={colors?.grey}
                bgGradient={`linear(to-bl, ${colors?.primary}, ${colors?.secondary}, ${colors?.red})`}
            >
                <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>
                    <Box
                        rounded={'2xl'}
                        bg={colors?.white}
                        boxShadow={'lg'}
                        py={8}
                        px={10}
                    >
                        <Stack spacing={4} >
                            <Stack align={'center'}>
                                <Heading letterSpacing={2} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                    LOGIN
                                </Heading>
                            </Stack>
                            <form onSubmit={e => handleSubmit(e)}>

                                <FormControl id="email" isRequired py={3}>
                                    <FormLabel>Email address</FormLabel>
                                    <Input type="email" name='email' onChange={e => handleChange(e)} />
                                </FormControl>
                                <FormControl id="password" isRequired pb={3}>
                                    <FormLabel>Password</FormLabel>
                                    <InputGroup>
                                        <Input type={showPassword ? 'text' : 'password'} name='password' onChange={e => handleChange(e)} />
                                        <InputRightElement h={'full'}>
                                            <Button
                                                variant={'unstyled'}
                                                onClick={() =>
                                                    setShowPassword((showPassword) => !showPassword)
                                                }>
                                                {showPassword ? <ViewIcon /> : <ViewOffIcon />}
                                            </Button>
                                        </InputRightElement>
                                    </InputGroup>
                                </FormControl>
                                <Stack spacing={10} pt={2} >
                                    <Button
                                        loadingText="Submitting"
                                        size="lg"
                                        bg={colors?.primary}
                                        color={colors?.white}
                                        _hover={{
                                            bg: colors?.primary,
                                            opacity: .8
                                        }}
                                        onClick={e => handleSubmit(e)}
                                        isLoading={isLoading}
                                    >
                                        LogIn
                                    </Button>
                                </Stack>
                            </form>
                            <Stack pt={2}>
                                <Text align={'center'}>
                                    {`Don't have an account yet?`} <Link onClick={() => router.push('/auth/register')} color={'blue.400'}>Register</Link>
                                </Text>
                            </Stack>
                            <Stack>
                                <Text align={'center'}>
                                    {`Forgot Password?`} <Link onClick={() => router.push({
                                        pathname : '/auth/forgotPassword',
                                    })} color={'blue.400'}>Forgot Password</Link>
                                </Text>
                            </Stack>
                        </Stack>
                    </Box>
                </Stack>
            </Flex>}


        </>
    );
}

