import React, { useState } from 'react';
import OtpInput from 'react-otp-input';
import {
    Flex,
    Box,
    Stack,
    Heading,
    Button,
} from '@chakra-ui/react';
import useAuthOtp from '@/customHooks/useAuthOtp';

export default function OTP({isForgotPassword,userId}) {

    const [otp, setOtp] = useState('');
    const { colors,handleSubmit,isLoading} = useAuthOtp(isForgotPassword,userId)

    return (

        <Flex
            align={'center'}
            justify={'center'}
            minH={'100vh'}
            bg={colors?.grey}
            bgGradient={`linear(to-bl, ${colors?.primary}, ${colors?.secondary}, ${colors?.red})`}
        >
            <Stack spacing={8} mx={'auto'} minW={{ base: 'xs', md: 'sm', lg: 'xl' }} py={10} px={6}>
                <Box
                    rounded={'2xl'}
                    bg={colors?.white}
                    boxShadow={'lg'}
                    py={8}
                    px={10}
                >
                    <Stack spacing={4} >
                        <Stack align={'center'} >
                            <Heading letterSpacing={2} fontSize={'4xl'} textAlign={'center'} color={colors?.secondary}>
                                OTP
                            </Heading>
                        </Stack>
                        <Flex justifyContent={'center'} my={5}>

                            <OtpInput
                                value={otp}
                                onChange={setOtp}
                                numInputs={6}
                                renderSeparator={<span>-</span>}
                                renderInput={(props) => <input {...props}
                                />
                                }
                                inputType='number'

                                inputStyle={{
                                    border: `1px solid ${colors?.lightGrey}`,
                                    width: '2.2rem',
                                    height: '2.5rem',
                                    margin: '0 .1rem',
                                    borderRadius: '4px'
                                }}
                                shouldAutoFocus={true}
                            />
                        </Flex>
                        <Flex justifyContent={'center'}>

                            <Button width={'50%'} bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.priamry, opacity: .8 }} onClick={()=>handleSubmit(otp)} isLoading={isLoading}>
                                Verify
                            </Button>
                        </Flex>
                    </Stack>
                </Box>
            </Stack>
        </Flex>
    );
}


export async function getServerSideProps(context) {

    const {isForgotPassword,userId} = context?.query;
    


    try {
      return {
        props: {
            isForgotPassword: isForgotPassword,
            userId : userId,
        },
      };
    } catch (error) {
      return {
        props: {
        },
      };
    }
  }
  