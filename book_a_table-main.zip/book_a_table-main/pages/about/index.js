import React from "react";
import {
  Grid,
  GridItem,
  Text,
  List,
  ListItem,
  ListIcon,
  Image,
  Box,
  Flex,
  Stack,
} from "@chakra-ui/react";
import { BsCheck2Circle } from "react-icons/bs";
import { useSelector } from "react-redux";
import HeroSection from "@/common/HeroSection";

/// Image
import aboutImage from "../../public/assets/images/about_chef.jpg";
import aboutCheck from "../../public/assets/images/about_check.png";
import spoonImage from "../../public/assets/images/heading_shapes_1.png";

export default function DescriptionTab() {
  const { colors } = useSelector((state) => state?.color);

  return (
    <>
      <HeroSection pageName={"About Us"} />
      <Grid
        templateColumns="repeat(3, 1fr)"
        gap={6}
        p={{ base: "5vh 5vw 0vh 5vw", md: "5vh 10vw 0vh 10vw" }}
      >
        <GridItem
          minW={{ base: "2xs", sm: "xs", md: "lg", lg: "lg" }}
          colSpan={{ base: 3, md: 1 }}
        >
          <Box
            border={"10px solid white"}
            shadow={"lg"}
            borderTopRightRadius={100}
            borderBottomRightRadius={100}
          >
            <Image
              src={aboutImage.src}
              alt={`Menu Photo`}
              width={500}
              height={500}
              borderTopRightRadius={100}
              borderBottomRightRadius={100}
            />
          </Box>
        </GridItem>
        <GridItem w="100%" colSpan={{ base: 3, md: 3, lg: 2 }}>
          <Flex alignItems={"center"}>
            <Text
              fontSize={"2xl"}
              fontWeight={"bold"}
              color={colors?.primary}
              ms={{ lg: 5 }}
              me={3}
            >
              About Company
            </Text>
            <Image src={spoonImage.src} width={"50px"} height={"20px"} alt="" />
          </Flex>
          <Text
            fontSize={"4xl"}
            fontWeight={"bold"}
            color={colors?.secondary}
            ms={{ lg: 5 }}
          >
            Healthy Food Provider
          </Text>
          <Box maxW={"lg"} ms={{ lg: 5 }} mt={5}>
            <Text fontSize={"md"} color={colors?.lightBrown}>
              At Marquee Hub, we are passionate about promoting a healthier lifestyle through our carefully crafted menu of nutritious and delectable dishes.
            </Text>
          </Box>
          <Box ms={{ lg: 10 }} mt={5}>
            <Flex>
              <Image
                src={aboutCheck.src}
                width={"50px"}
                height={"50px"}
                alt=""
              />
              <Stack ms={4}>
                <Text
                  fontSize={"xl"}
                  fontWeight={"bold"}
                  color={colors?.secondary}
                >
                  Trusted Partner
                </Text>
                <Text fontSize={"md"}>
                  At Marquee Hub, we take pride in being your reliable and dedicated partner on your journey to wellness.
                </Text>
              </Stack>
            </Flex>
          </Box>
          <Box ms={{ lg: 10 }} mt={5}>
            <Flex>
              <Image
                src={aboutCheck.src}
                width={"50px"}
                height={"50px"}
                alt=""
              />
              <Stack ms={4}>
                <Text
                  fontSize={"xl"}
                  fontWeight={"bold"}
                  color={colors?.secondary}
                >
                  First Delivery
                </Text>
                <Text fontSize={"md"}>
                  Our commitment to punctuality and precision ensures that your very first experience with us will be a seamless and delightful one.
                </Text>
              </Stack>
            </Flex>
          </Box>
          <Box ms={{ lg: 10 }} mt={5}>
            <Flex>
              <Image
                src={aboutCheck.src}
                width={"50px"}
                height={"50px"}
                alt=""
              />
              <Stack ms={4}>
                <Text
                  fontSize={"xl"}
                  fontWeight={"bold"}
                  color={colors?.secondary}
                >
                  Secure payment
                </Text>
                <Text fontSize={"md"}>
                Our secure payment options ensure that your transactions are protected, allowing you to focus on savoring your delectable meal choices without worry.
                </Text>
              </Stack>
            </Flex>
          </Box>
        </GridItem>
      </Grid>
      <Grid
        templateRows={"repeat(1,1fr)"}
        mt={5}
        p={{ base: "0vh 5vw 10vh 5vw", md: "3vh 10vw 10vh 10vw" }}
      >
        <GridItem>
          <Text textAlign={"justify"}>
            At Marquee Hub, we breathe life into dreams, and every event we host
            becomes a masterpiece. Our story is one of passion, artistry, and a
            commitment to crafting unforgettable moments beneath the canvas of
            our exquisite marquees.Founded on the belief that celebrations are
            the fabric of life, Marquee Hub is more than just a venue  it is a
            haven where aspirations come alive. Nestled amidst nature embrace,
            our marquee stands as a testament to grandeur and grace, a place
            where the ordinary is transformed into the extraordinary.Step inside
            and be greeted by an ambiance that whispers stories of celebrations
            past, and invites you to script your own tales of joy. Our team of
            artisans, designers, and event experts work harmoniously to ensure
            every event is a symphony of seamless execution and heartfelt
            experiences.{" "}
          </Text>
        </GridItem>
        <Grid templateColumns={"repeat(2,1fr)"} mt={3} gap={3}>
          <GridItem colSpan={{ base: 2, md: 1 }}>
            <List spacing={3} lineHeight={7}>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                We boasts an exquisite blend of classic and contemporary design{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Our marquee showcases stunning craftsmanship{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Our marquee offers a harmonious fusion of outdoor beauty{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Our marquee offers versatile spaces that adapt seamlessly{" "}
              </ListItem>
            </List>
          </GridItem>
          <GridItem colSpan={{ base: 2, md: 1 }}>
            <List spacing={3} lineHeight={7}>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Our team works closely with you to tailor every aspect{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Enjoy panoramic vistas that create a picturesque backdrop{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Our dedicated team is committed to providing exceptional service{" "}
              </ListItem>
              <ListItem>
                <ListIcon as={BsCheck2Circle} color={colors?.primary} />
                Elevate your dining experience with exquisite culinary creations{" "}
              </ListItem>
            </List>
          </GridItem>
        </Grid>
      </Grid>
    </>
  );
}
