import React, { useEffect } from 'react'
import DataTable from 'react-data-table-component';

import SidebarWithHeader from '../index'
import useOrdersList from '@/customHooks/useOrdersList';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';


export default function DealsList( ) {

  const { columns, isLoading,orders } = useOrdersList();
  const {user} = useSelector(state => state?.user);
  const router = useRouter()

  useEffect(() => {
    if (user && user?.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
    } else {
      router.push('/');
    }
  }, [])

  return (
    <SidebarWithHeader>
      {isLoading ? <div>Loading</div> : <DataTable
        columns={columns}
        data={orders}
        pagination
      />}
    </SidebarWithHeader>
  )
}




