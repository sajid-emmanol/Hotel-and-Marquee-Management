import React, { useState } from 'react'
import SidebarWithHeader from '../index'
import { Box, Button, Flex, FormControl, Grid, GridItem, Icon, Image, Input, InputGroup, InputLeftAddon, NumberDecrementStepper, NumberIncrementStepper, NumberInput, NumberInputField, NumberInputStepper, Select, Stack, Text } from '@chakra-ui/react'
import { useDispatch, useSelector } from 'react-redux'
import DataTable from 'react-data-table-component'
import { addProductsPrice, selectProduct, } from '@/redux/features/deals/dealsSlice'
import useCreateDeal from '@/customHooks/useCreateDeal'
import { getAllMarquees } from '@/prisma/marquee'
import { BiCamera } from 'react-icons/bi'

export default function Deals({ marquees }) {

  const [dealName, setdealName] = useState("");
  const [toggleSelection, settoggleSelection] = useState(false);

  const { selectedProducts, totalPrice, discountPrice, subTotalPrice, } = useSelector(state => state?.deal);
  const { colors, columns, isLoading, handleChange, allMarquees, createDeal, state, inputRef, handleFile, handleSubmit } = useCreateDeal(marquees);
  const { user } = useSelector(state => state?.user);
  const dispatch = useDispatch();


  return (
    <SidebarWithHeader>
      {user?.userType === "MARQUEE" ? <Select mb={6} placeholder='--Select Marquee--' variant={'filled'} bg={colors?.white} name='marqueeId' onChange={e => {
        handleChange(e)
        dispatch(selectProduct([]));
        settoggleSelection(!toggleSelection)
      }
      }>
        <option value={user?.marquee?.id}>{user?.marquee?.name}</option>

      </Select> : <Select mb={6} placeholder='--Select Marquee--' variant={'filled'} bg={colors?.white} name='marqueeId' onChange={e => {
        handleChange(e)
        dispatch(selectProduct([]));
        settoggleSelection(!toggleSelection)
      }
      }>
        {marquees.map((marquee, i) => {
          return <option key={i} value={marquee.id}>{marquee.name}</option>
        })}
      </Select>}

      <Box>
        {allMarquees[0]?.items?.length > 0 && <Box bg={colors?.white} borderRadius={'2xl'} p={{ base: '5vw 5vw', md: '2vw 4vw' }}>
          <Grid
            templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}
            gap={6}
          >
            {selectedProducts?.map((card, i) => {
              return (
                <GridItem
                  key={i}
                >
                  <Flex
                    justifyContent={{ base: 'center', md: 'flex-start' }}
                    alignItems={{ base: 'center', md: 'flex-start' }}
                  >
                    <Box
                      bg={'white'}
                      rounded="lg"
                      shadow="md"
                      position="relative"
                    >
                      <Image
                        src={card.image}
                        alt={`Picture of ${card.name}`}
                        roundedTop="lg"
                        width={'400px'}
                        height={'200px'}
                      />

                      <Box p="6">
                        <Flex mt="1"
                          alignItems={'center'}
                          flexDirection={'column'}
                        >
                          <Box
                            fontSize="2xl"
                            fontWeight="semibold"
                            as="h4"
                            lineHeight="tight"
                            isTruncated
                            color={colors?.secondary}
                            _hover={{
                              color: colors?.primary

                            }}
                          >
                            {card.name}
                          </Box>
                        </Flex>
                      </Box>

                    </Box>
                  </Flex>
                </GridItem>
              )
            })}
          </Grid>
        </Box>}

        <Box bg={colors?.white} borderRadius={'2xl'} mt={6} py={6}>
          {isLoading ? <Text>Loading...</Text> : <DataTable
            columns={columns}
            data={allMarquees[0]?.items}
            selectableRows
            selectableRowsNoSelectAll
            onSelectedRowsChange={selected => {
              dispatch(selectProduct(selected.selectedRows))
              dispatch(addProductsPrice(selected.selectedRows))
            }}
            clearSelectedRows={toggleSelection}
          />}
        </Box>
        {allMarquees[0]?.items?.length > 0 && <>
          <Grid templateColumns={'repeat(2,1fr)'} gap={3} mt={6}>
            <GridItem colSpan={{ base: 2, md: 1 }} >
              <Box bg={colors?.white} borderRadius={'2xl'} px={10} py={6}>
                <form onSubmit={e => handleSubmit(e)}>
                  <FormControl>
                    <NumberInput variant={'filled'} >
                      <NumberInputField placeholder='Enter Discount' name='discount' onChange={e => handleChange(e)} />
                      <NumberInputStepper>
                        <NumberIncrementStepper />
                        <NumberDecrementStepper />
                      </NumberInputStepper>
                    </NumberInput>
                  </FormControl>
                  <FormControl my={3}>
                    <Input type='text' placeholder='Enter Deal Name ' name='dealName' variant={'filled'} onChange={(e) => handleChange(e)} />
                  </FormControl>
                  <FormControl>
                    <Input type='file' name='image' onChange={e => handleFile(e)} placeholder='Enter Product Description' variant='filled' ref={inputRef} display={'none'} multiple accept='image/*' />
                    <InputGroup>
                      <InputLeftAddon border={'none'} bg={colors?.primary} onClick={() => inputRef.current.click()}>
                        <Icon as={BiCamera} color={colors?.white} boxSize={5} />
                      </InputLeftAddon>
                      <Input type="text" placeholder='Select an image' name='image' value={state?.image?.name} onClick={() => inputRef.current.click()} variant={'filled'} readOnly _focusVisible={false} />
                    </InputGroup>
                  </FormControl>

                  <Flex justifyContent={'flex-end'}>
                    <Button
                      onClick={(e) => handleSubmit(e)}
                      bg={colors?.primary} color={colors?.white}
                      _hover={{ bg: colors?.primary, opacity: .8 }}
                      mt={3}
                      alignSelf={'flex-end'}
                    >
                      Add
                    </Button>
                  </Flex>
                </form>
              </Box>

            </GridItem>
            <GridItem colSpan={{ base: 2, md: 1 }} >
              <Box bg={colors?.white} borderRadius={'2xl'} px={10} py={6}>
                {isLoading ? <></> : <Stack gap={2}>

                  <Text display={'flex'} justifyContent={'space-between'}>
                    Total Price : {isLoading ? <></> : <>{totalPrice}</>}
                  </Text>
                  <Text display={'flex'} justifyContent={'space-between'}>
                    Discount Price : {isLoading ? <></> : <>{discountPrice}</>}
                  </Text>
                  <Text display={'flex'} justifyContent={'space-between'}>
                    SubTotal Price : {isLoading ? <></> : <>{subTotalPrice}</>}
                  </Text>
                </Stack>}
              </Box>
            </GridItem>
          </Grid>
          <Flex justifyContent={'flex-end'} mt={6} >
            <Button isLoading={isLoading} bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }}
              onClick={() => createDeal(selectedProducts, totalPrice, discountPrice, subTotalPrice, dealName)}
              disabled ={true}
            >
              Create Deal
            </Button>
          </Flex>
        </>}

      </Box>



    </SidebarWithHeader>
  )
}


export async function getServerSideProps() {
  try {
    const marquees = await getAllMarquees();
    return {
      props: {
        marquees,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        marquees: [],
      },
    };
  }
}

