import React, { useState } from 'react'
import SidebarWithHeader from '../index'
import {
    Box,
    Button,
    Flex,
    FormControl,
    FormLabel,
    Grid,
    GridItem,
    Input,
    InputRightElement,
    Stack,
    Text,
    InputGroup,
} from '@chakra-ui/react'
import { useSelector } from 'react-redux'
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons'
import useUpdateUser from '@/customHooks/useUpdateUser'


export default function UpdateUserProfile() {

    const [showPassword, setShowPassword] = useState(false);
    const { handleChange, handleSubmit,  colors,  isLoading, state } = useUpdateUser();

    return (
        <SidebarWithHeader>
            <Box bg={colors?.white} borderRadius={'xl'} mt={2} >
                <Text textAlign={'center'} pt={5} fontSize={'2xl'} fontWeight={'bold'} textTransform='uppercase'>
                    User Details
                </Text>
                <Stack px={10} pt={3} pb={5}>
                    <form onSubmit={e => handleSubmit(e)}>
                        <FormControl isRequired mt={6}>
                            <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                                    <FormLabel>
                                        Name
                                    </FormLabel>
                                </GridItem>
                                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                                    <Input type='text' name='name' value={state?.name} onChange={e => handleChange(e)} placeholder='Enter Your Name' variant='filled' />
                                </GridItem>
                            </Grid>

                        </FormControl>
                        <FormControl isRequired my={6}>
                            <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                                    <FormLabel>
                                        Email
                                    </FormLabel>
                                </GridItem>
                                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                                    <Input type='email' name='email' value={state?.email} onChange={e => handleChange(e)} placeholder='Enter Your Email' variant='filled' />
                                </GridItem>
                            </Grid>
                        </FormControl>
                        <FormControl isRequired my={6}>
                            <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                                    <FormLabel>
                                        Password
                                    </FormLabel>
                                </GridItem>
                                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                                    <InputGroup variant={'filled'}>
                                        <Input type={showPassword ? 'text' : 'password'} name='password' onChange={e => handleChange(e)} value={state?.password} placeholder='Enter Your Password'/>
                                        <InputRightElement h={'full'}>
                                            <Button
                                                variant={'unstyled'}
                                                onClick={() =>
                                                    setShowPassword((showPassword) => !showPassword)
                                                }>
                                                {showPassword ? <ViewIcon /> : <ViewOffIcon />}
                                            </Button>
                                        </InputRightElement>
                                    </InputGroup>
                                </GridItem>
                            </Grid>
                        </FormControl>
                        <Flex justify={'flex-end'}>

                            <Button variant={'solid'} bg={colors?.primary} color={colors?.white} _hover={{
                                bg: colors?.primary,
                                opacity: .8
                            }}
                                isLoading={isLoading}
                                mt={6}
                                onClick={e => handleSubmit(e)}
                            >
                                Update
                            </Button>
                        </Flex>
                    </form>
                </Stack>
            </Box>
        </SidebarWithHeader>
    )
}
