import React, { useEffect } from 'react'
import SidebarWithHeader from '..'
import { Box, Button, Flex, Grid, GridItem, Text } from '@chakra-ui/react'
import { useSelector } from 'react-redux'
import { useRouter } from 'next/router';

export default function UserProfile() {

    const { colors } = useSelector(state => state.color);
    const router = useRouter()
    
    const {user} = useSelector(state => state?.user)
    useEffect(() => {
      if (user && user?.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
      } else {
        router.push('/');
      }
    }, [])
    return (
        <SidebarWithHeader>
            <Box bg={colors?.white} borderRadius={'md'} p={{ base: '5vw 5vw', md: '2vw 4vw' }}>
                <Grid
                    templateColumns={{ base: 'repeat(1, 1fr)' }}
                    gap={6}
                >
                    <GridItem
                    >
                        <Flex alignItems={'center'} borderBottom={`1px solid ${colors?.lightGrey}`} py={5}>
                            <Text fontSize={'lg'} fontWeight={'bold'} color={colors?.lightBrown} me={20}>
                                Name:
                            </Text>

                            <Text>
                                {user.name}
                            </Text>
                        </Flex>

                        <Flex alignItems={'center'}  py={5}>
                            <Text fontSize={'lg'} fontWeight={'bold'} color={colors?.lightBrown} me={20}>
                                Email:
                            </Text>
                            <Text>
                                {user.email}
                            </Text>
                        </Flex>
                    </GridItem>
                </Grid>                
            </Box>
            <Flex justifyContent={'flex-end'} mt={5}>
            <Button bg={colors?.primary} color={colors?.white} _hover={{bg : colors?.primary ,opacity : .8}} onClick={()=>router.push('/admin/userProfile/update')}>
                Update
            </Button>
            </Flex>
        </SidebarWithHeader>
    )
}
