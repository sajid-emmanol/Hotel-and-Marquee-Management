import React, { useEffect } from 'react'
import { Box, Button } from '@chakra-ui/react';
import DataTable from 'react-data-table-component';

import SidebarWithHeader from '../index'
import useMenuList from '../../../customHooks/useMenuList';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';


export default function MenuList() {

  const { columns, isLoading, menuItems, colors } = useMenuList();
  const router = useRouter();
  const {user} = useSelector(state => state?.user)

  useEffect(() => {
    if (user && user?.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
    } else {
      router.push('/');
    }
  }, [])

  return (
    <SidebarWithHeader>
      {isLoading ? <div>Loading</div> : <DataTable
        columns={columns}
        data={menuItems}
        noDataComponent={
          (
            <Box py={6}>
              <Button bg={colors?.primary} color={colors?.white} _hover={{ bg: colors?.primary, opacity: .8 }} onClick={() => router.push('/admin/menu/create')}>
                Add Menu
              </Button>
            </Box>
          )
        }
        pagination
      />}
    </SidebarWithHeader>
  )
}




