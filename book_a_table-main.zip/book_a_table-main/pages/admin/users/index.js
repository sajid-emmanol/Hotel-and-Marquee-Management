import React, { useEffect } from 'react'
import DataTable from 'react-data-table-component';

import SidebarWithHeader from '../index'
import { getAllUsers } from '@/prisma/user';
import useUsersList from '@/customHooks/useUsersList';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';


export default function UsersList({ users }) {

  const { columns, isLoading,allUsers } = useUsersList(users);
  const {user} = useSelector(state => state?.user);
  const router = useRouter();

  useEffect(() => {
    if (user && user?.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
    } else {
      router.push('/');
    }
  }, [])

  return (
    <SidebarWithHeader>
      {isLoading ? <div>Loading</div> : <DataTable
        columns={columns}
        data={allUsers}
        pagination
      />}
    </SidebarWithHeader>
  )
}

export async function getServerSideProps() {
  try {
    const users = await getAllUsers();
    return {
      props: {
        users,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        users: [],
      },
    };
  }
}



