import React from 'react'
import SidebarWithHeader from '../index'
import {
  Box,
  Button,
  Flex,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  Icon, Input,
  InputGroup,
  InputLeftAddon,
  Select,
  Stack,
  Text
} from '@chakra-ui/react'
import useCreateMarquee from '@/customHooks/useCreateMarquee'

/// Icons
import { BiCamera } from 'react-icons/bi'
import { getAllUsers } from '@/prisma/user'

export default function CreateMarquee({users}) {

  const { handleChange, handleFile, handleSubmit, fileName, colors, inputRef, isLoading,state } = useCreateMarquee()

  return (
    <SidebarWithHeader>
      <Box bg={colors?.white} borderRadius={'xl'} mt={2} >
        <Text textAlign={'center'} pt={5} fontSize={'2xl'} fontWeight={'bold'} textTransform='uppercase'>
          Marquee Details
        </Text>
        <Stack px={10} pt={3} pb={5}>
          <form onSubmit={e => handleSubmit(e)}>
            <FormControl isRequired mt={6}>
              <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                  <FormLabel>
                    Name
                  </FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Input type='text' name='name' value={state?.name} onChange={e => handleChange(e)} placeholder='Enter Marquee Name' variant='filled' />
                </GridItem>
              </Grid>

            </FormControl>
            <FormControl isRequired my={6}>
              <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                  <FormLabel>
                    Location
                  </FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Input type='text' name='location' value ={state?.location} onChange={e => handleChange(e)} placeholder='Enter Marquee Location' variant='filled' />
                </GridItem>
              </Grid>
            </FormControl>
            <FormControl isRequired my={6}>
              <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                  <FormLabel>
                    City
                  </FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Input type='text' name='city' value={state?.city} onChange={e => handleChange(e)} placeholder='Enter Marquee City' variant='filled' />
                </GridItem>
              </Grid>
            </FormControl>
            <FormControl isRequired my={6}>
              <Grid templateColumns={'repeat(14,1fr)'} gap={0}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                  <FormLabel>
                    Description
                  </FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Input type='text' name='desc' value={state?.desc} onChange={e => handleChange(e)} placeholder='Enter Marquee Description' variant='filled' />
                </GridItem>
              </Grid>
            </FormControl>
            <FormControl isRequired my={6}>
              <Grid templateColumns={'repeat(14,1fr)'}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>
                  <FormLabel>Owner</FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Select variant={'filled'} placeholder='--Select Owner--' value={state?.ownerId} name='ownerId' onChange={e => handleChange(e)}>
                    {users?.filter(user => {
                      return user.userType !== "ADMIN" && user.userType !== "MARQUEE" 
                    })?.map((owner, i) => {
                      return <option key={i} value={owner?.id}>{owner?.name}</option>
                    })}
                  </Select>
                </GridItem>
              </Grid>
            </FormControl>
            <FormControl isRequired mt={6}>
              <Grid templateColumns={'repeat(14,1fr)'}>
                <GridItem colSpan={{ base: 14, md: 4, lg: 2 }}>

                  <FormLabel>
                    Image
                  </FormLabel>
                </GridItem>
                <GridItem colSpan={{ base: 14, md: 10, lg: 12 }}  >
                  <Input type='file' name='image' onChange={e => handleFile(e)} placeholder='Enter Product Description' variant='filled' ref={inputRef} display={'none'} multiple accept='image/*' />
                  <InputGroup>
                    <InputLeftAddon border={'none'} bg={colors?.primary} onClick={() => inputRef.current.click()}>
                      <Icon as={BiCamera} color={colors?.white} boxSize={5} />
                    </InputLeftAddon>
                    <Input type="text" placeholder='Select an image' name='image' value={fileName} onClick={() => inputRef.current.click()} variant={'filled'} readOnly _focusVisible={false} />
                  </InputGroup>

                </GridItem>
              </Grid>
            </FormControl>
            <Flex justify={'flex-end'}>

              <Button variant={'solid'} bg={colors?.primary} color={colors?.white} _hover={{
                bg: colors?.primary,
                opacity: .8
              }}
                isLoading={isLoading}
                mt={6}
                onClick={e => handleSubmit(e)}
              >
                Create
              </Button>
            </Flex>
          </form>
        </Stack>
      </Box>
    </SidebarWithHeader>
  )
};

export async function getServerSideProps() {
  try {
    const users = await getAllUsers();
    return {
      props: {
        users,
      },
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      props: {
        users: [],
      },
    };
  }
}




