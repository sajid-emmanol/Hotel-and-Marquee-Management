import React, { useEffect, useState } from 'react';
import {
  IconButton,
  Avatar,
  Box,
  CloseButton,
  Flex,
  HStack,
  VStack,
  Icon,
  Drawer,
  DrawerContent,
  Text,
  useDisclosure,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
} from '@chakra-ui/react';
import {
  FiHome,
  FiTrendingUp,
  FiCompass,
  FiMenu,
  FiChevronDown,
} from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { setIsLoggedIn, setUser } from '@/redux/features/user/userSlice';
import userImage from '../../public/assets/images/user.png'
import Loader from '@/common/Loader';
import { setProducts } from '@/redux/features/cart/cartSlice';


const LinkItems = [
  {
    name: 'Marquee',
    icon: FiHome,
    routePath: '/admin/marquee',
    visibleTo: 'ADMIN', // Visible only to 'admin' users
  },
  {
    name: 'Items',
    icon: FiHome,
    routePath: '/admin/menu',
    visibleTo: ['ADMIN', 'MARQUEE'], // Visible to both 'admin' and 'MARQUEE' users
  },
  {
    name: 'Orders',
    icon: FiTrendingUp,
    routePath: '/admin/orders',
    visibleTo: ['ADMIN', 'MARQUEE'], // Visible to both 'admin' and 'MARQUEE' users
  },
  {
    name: 'Deals',
    icon: FiCompass,
    routePath: '/admin/deals',
    visibleTo: ['ADMIN', 'MARQUEE'], // Visible to both 'admin' and 'MARQUEE' users
  },
  {
    name: 'Users',
    icon: FiCompass,
    routePath: '/admin/users',
    visibleTo: 'ADMIN', // Visible only to 'admin' users
  },
];


function SidebarWithHeader({
  children,
}) {
  const [isLoading, setisLoading] = useState(true);

  const { isOpen, onOpen, onClose } = useDisclosure();
  const { colors } = useSelector(state => state?.color);
  const { user } = useSelector(state => state?.user);
  const router = useRouter();


  useEffect(() => {
    if (user && user?.userType === 'ADMIN' || user?.userType === 'MARQUEE') {
      setisLoading(false)
    } else {
      router.push('/');
      setisLoading(false);
    }
  }, [])

  if (isLoading) {
    return <Loader />
  } else {
    return (

      <Box minH="100vh" bg={colors?.grey}>
        <SidebarContent
          onClose={() => onClose}
          display={{ base: 'none', md: 'block' }}
          colors={colors}
          userRole={user?.userType === "ADMIN" ? "ADMIN" : "MARQUEE"}
        />
        <Drawer
          autoFocus={false}
          isOpen={isOpen}
          placement="left"
          onClose={onClose}
          returnFocusOnClose={false}
          onOverlayClick={onClose}
          size="full">
          <DrawerContent>
            <SidebarContent onClose={onClose} colors={colors} userRole={user?.userType === "ADMIN" ? "ADMIN" : "MARQUEE"} />
          </DrawerContent>
        </Drawer>
        {/* mobilenav */}
        <MobileNav onOpen={onOpen} colors={colors} />
        <Box ml={{ base: 0, md: 60 }} p="4" >
          {children}
        </Box>
      </Box>)

  }
}


const SidebarContent = ({ onClose, colors, userRole, ...rest }) => {

  const { user } = useSelector(state => state?.user)

  return (
    <Box
      transition="3s ease"
      bg={colors?.secondary}
      borderRight="1px"
      // borderRightColor={colors?.primary}
      w={{ base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      {...rest}>
      <Flex h="20" alignItems="center" mx="8" justifyContent="space-between">
        <Text fontSize="2xl" fontFamily="monospace" fontWeight="bold" color={colors?.white}>
          Logo
        </Text>
        <CloseButton display={{ base: 'flex', md: 'none' }} onClick={onClose} color={colors?.white} />
      </Flex>

      {LinkItems.map((item, index) => {
        if (item.visibleTo === userRole || (Array.isArray(item.visibleTo) && item.visibleTo.includes(userRole))) {
          return (
            <NavItem key={index} icon={item.icon} colors={colors} route={item.routePath}>
              {item?.name}
            </NavItem>
          );
        }
        return null; // Hide the link if it's not visible to the user
      })}
    </Box>
  );
};

const NavItem = ({ icon, children, colors, route, ...rest }) => {
  const router = useRouter();

  const isActive = router.pathname.startsWith(route);

  const handleItemClick = () => {
    if (route) {
      router.push(route);
    }
  };

  return (
    <Box>
      <Flex
        align="center"
        justify="space-between"
        p="4"
        mx="4"
        borderRadius="lg"
        role="group"
        cursor="pointer"
        color={isActive ? colors?.white : colors?.grey}
        bg={isActive ? colors?.primary : 'transparent'}
        _hover={{
          bg: colors?.primary,
          color: colors?.white,
        }}
        onClick={handleItemClick}
        {...rest}
      >
        <Flex olor={isActive ? colors?.white : colors?.grey} align="center" >
          {icon && (
            <Icon
              mr="4"
              fontSize="16"
              _groupHover={{
                color: colors?.white,
              }}
              as={icon}
            />
          )}
          <Text>{children}</Text>
        </Flex>
      </Flex>
    </Box>
  );
};


const MobileNav = ({ onOpen, colors, ...rest }) => {

  const dispatch = useDispatch();
  const router = useRouter();

  const { user } = useSelector(state => state.user);

  const logOut = () => {
    dispatch(setIsLoggedIn(false));
    dispatch(setUser({}))
    router.push('/')
  }

  return (
    <Flex
      ml={{ base: 0, md: 60 }}
      px={{ base: 4, md: 4 }}
      height="20"
      alignItems="center"
      bg={colors?.white}
      borderBottomWidth="1px"
      borderBottomColor={'gray.200'}
      justifyContent={{ base: 'space-between', md: 'flex-end' }}
      {...rest}>
      <IconButton
        display={{ base: 'flex', md: 'none' }}
        onClick={onOpen}
        variant="outline"
        aria-label="open menu"
        icon={<FiMenu />}
      />

      <Text
        display={{ base: 'flex', md: 'none' }}
        fontSize="2xl"
        fontFamily="monospace"
        fontWeight="bold">
        Logo
      </Text>
      <HStack spacing={{ base: '0', md: '6' }}>
        <Flex alignItems={'center'}>
          <Menu>
            <MenuButton
              py={2}
              transition="all 0.3s"
              _focus={{ boxShadow: 'none' }}>
              <HStack>
                <Avatar
                  size={'xs'}
                  src={
                    userImage.src
                  }
                />
                <VStack
                  display={{ base: 'none', md: 'flex' }}
                  alignItems="flex-start"
                  spacing="1px"
                  ml="2">
                  <Text fontSize="sm">{user.name}</Text>
                  {user?.userType === "ADMIN" ? <Text marginLeft={'auto'} marginRight={'auto'} fontSize="xs" color="gray.600">
                    Admin
                  </Text> : <Text marginLeft={'auto'} marginRight={'auto'} fontSize="xs" color="gray.600">
                    Marquee Owner
                  </Text>

                  }
                </VStack>
                <Box display={{ base: 'none', md: 'flex' }}>
                  <FiChevronDown />
                </Box>
              </HStack>
            </MenuButton>
            <MenuList
              bg={colors?.white}
              borderColor={'gray.200'}
            >
              <MenuItem onClick={() => router.push('/admin/userProfile')}>Profile</MenuItem>
              <MenuItem onClick={logOut}>Sign out</MenuItem>
            </MenuList>
          </Menu>
        </Flex>
      </HStack>
    </Flex>
  );
};




export default SidebarWithHeader

