import React from 'react'
import { useSelector } from 'react-redux';
import {
    Box,
    Text,
    Grid,
    GridItem,
} from '@chakra-ui/react'


export default function BillTemplate({order}) {

    const { colors } = useSelector(state => state?.color)

    return (
        <>
            <Grid templateColumns={'repeat(2,1fr)'}   p={{ base: '5vh 5vw', md: '5vh 10vw' }} >
                <GridItem  >
                    <Box flex={1} textAlign={'center'} bg={colors?.primary} color={colors?.white} py={2}>
                        <Text>
                            Fields
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} borderLeft={'1px solid black'} py={2}>
                        <Text>
                            Order Id
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} borderLeft={'1px solid black'} py={2}>
                        <Text>
                            Marquee Name
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} borderLeft={'1px solid black'} py={2}>
                        <Text>
                            User Name
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} borderLeft={'1px solid black'} py={2}>
                        <Text>
                            Items
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderRight={'1px solid black'} borderBottom={'1px solid black'} borderLeft={'1px solid black'} py={2}>
                        <Text>
                            Price
                        </Text>
                    </Box>
                </GridItem>
                {/* <Divider orientation='vertical'/> */}
                <GridItem colSpan={1}>
                    <Box flex={1} textAlign={'center'} bg={colors?.primary} color={colors?.white} py={2}>
                        <Text>
                            Description
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} py={2}>
                        <Text>
                            {order?.id}
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} py={2}>
                        <Text>
                            {order?.marquee?.name}
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} py={2}>
                        <Text>
                            {order?.user?.name}
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderBottom={'1px solid black'} borderRight={'1px solid black'} py={2}>
                        <Text>
                            {order?.items?.length}
                        </Text>
                    </Box>
                    <Box flex={1} textAlign={'center'} borderRight={'1px solid black'} borderBottom={'1px solid black'} py={2}>
                        <Text>
                            ${order?.price}
                        </Text>
                    </Box>
                </GridItem>
            </Grid>
        </>
    );
}
