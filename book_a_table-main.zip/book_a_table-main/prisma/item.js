import prisma from "./prisma"

// READ
export const getAllItems = async (id) => {

  if (id) {
    const items = await prisma.item.findMany({
      where : {
        marqueeId : id,
      },
      include: {
        marquee: true, // Include the related marquee details
      },
    });
    return items;
  } else {
    const items = await prisma.item.findMany({
      include: {
        marquee: true, // Include the related marquee details
      },
    });
    return items;
  }

};

export const getItem = async (id) => {
  const item = await prisma.item.findUnique({
    where: { id },
  })
  return item
}

// CREATE
export const createItem = async (name, price, stock, isPopular, image, marqueeId, desc, size, publicId) => {
  const item = await prisma.item.create({
    data: {
      name,
      price,
      stock,
      isPopular,
      image,
      marqueeId,
      desc,
      size,
      publicId
    },
  })
  return item
}

// UPDATE
export const updateItem = async (id, updateData) => {
  const item = await prisma.item.update({
    where: {
      id,
    },
    data: {
      ...updateData,
    },
  })
  return item
}

// DELETE
export const deleteItem = async (itemId) => {
  const item = await prisma.item.findUnique({
    where: { id: itemId },
    include: {
      DealItems: true,
      OrderItem: true,
    },
  });

  // Delete the related DealItems
  for (const dealItem of item.DealItems) {
    await prisma.dealItems.delete({ where: { id: dealItem.id } });
  }

  // Delete the related OrderItems
  for (const orderItem of item.OrderItem) {
    await prisma.orderItem.delete({ where: { id: orderItem.id } });
  }

  // Delete the item itself
  const res = await prisma.item.delete({ where: { id: itemId } });

  return res
}