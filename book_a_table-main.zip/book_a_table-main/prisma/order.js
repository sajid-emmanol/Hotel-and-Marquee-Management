import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

/// Get All Orders
export const getAllOrders = async (id) => {
  if (id) {
    const orders = await prisma.order.findMany({
      where: {
        marqueeId: id
      },
      include: {
        user: true,
      }
    });
    return orders;
  } else {
    const orders = await prisma.order.findMany({
      include: {
        user: true,
      }
    });
    return orders;
  }

};
/// Get All Orders Of particular user
export const getOrdersById = async (id) => {
  if (!id) {
    return null; // or any other appropriate handling for an undefined id
  }
  const orders = await prisma.order.findMany({
    where: {
      userId: id,
    },
    include: {
      items: true, // Include the associated OrderItem details
      marquee: true, // Include the associated Marquee details
      user: true, // Include the associated User details
    },
  });
  return orders;
};

/// Get Order Details
export const getOrder = async (id) => {
  const orders = await prisma.order.findUnique({
    where: {
      id,
    },
    include: {
      items: true, // Include the associated OrderItem details
      marquee: true, // Include the associated Marquee details
      user: true, // Include the associated User details
    },
  });
  return orders;
};

// CREATE Order

export const createOrder = async (
  price,
  isPaymentSuccess,
  status,
  items,
  marqueeId,
  userId
) => {
  const order = await prisma.order.create({
    data: {
      price,
      isPaymentSuccess,
      status,
      marquee: {
        connect: {
          id: marqueeId,
        },
      },
      user: {
        connect: {
          id: userId,
        },
      },
      items: {
        create: items.map((item) => ({
          item: { connect: { id: item.id } },
          isDeal: item?.type === 'menuItem' ? false : true,
          quantity: item?.quantity
        })),
      },
    },
    include: {
      items: true,
    },
  });

  return order;
};

/// Update Order Status
export const updateOrderStatus = async (orderId, newStatus) => {
  try {
    const updatedOrder = await prisma.order.update({
      where: {
        id: orderId,
      },
      data: {
        status: newStatus.status,
      },
    });

    return updatedOrder;
  } catch (error) {
    console.error("Error updating order status:", error);
    throw error;
  }
};

// CREATE OrderItem
export const createOrderItem = async (isDeal, itemId, orderId) => {
  const orderItem = await prisma.orderItem.create({
    data: {
      isDeal,
      itemId,
      orderId,
    },
  });
  return orderItem;
};




// UPDATE OrderItem
export const updateOrderItem = async (id, updateData) => {
  const orderItem = await prisma.orderItem.update({
    where: {
      id,
    },
    data: {
      ...updateData,
    },
  });
  return orderItem;
};
