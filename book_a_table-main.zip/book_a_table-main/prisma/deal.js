import prisma from "./prisma";
// READ
export const getAllDeals = async (id) => {
  if (id) {
    const deals = await prisma.deal.findMany({
      where: {
        marqueeId: id,
      },
      include: {
        dealItems: {
          include: {
            item: true,
          },
        },
      },
    });
    return deals;
  }else{
    const deals = await prisma.deal.findMany({
      include: {
        dealItems: {
          include: {
            item: true,
          },
        },
      },
    });
    return deals;
  }
};

export const getDeal = async (id) => {
  const deal = await prisma.deal.findUnique({
    where: { id },
    include: {
      dealItems: {
        include: {
          item: true,
        },
      },
    },
  });
  return deal;
};

// CREATE
export const createDeal = async (
  price,
  actualPrice,
  discount,
  name,
  marqueeId,
  dealItems,
  image,
  publicId,
) => {
  const deal = await prisma.deal.create({
    data: {
      price,
      actualPrice,
      discount,
      name,
      image,
      publicId,
      marqueeId,
      dealItems: {
        create: dealItems,
      },
    },
    include: {
      dealItems: {
        include: {
          item: true,
        },
      },
    },
  });

  return deal;
};
// [
//   {
//     itemId: "item1Id",
//     dealId: "dealId1"
//   },
//   {
//     itemId: "item2Id",
//     dealId: "dealId1"
//   },
//   // Additional deal items...
// ]
// UPDATE
export const updateDeal = async (id, updateData) => {
  const deal = await prisma.deal.update({
    where: {
      id,
    },
    data: {
      ...updateData,
    },
  });
  return deal;
};

// DELETE
export const deleteDeal = async (id) => {
  const deal = await prisma.deal.delete({
    where: {
      id,
    },
  });
  return deal;
};

// DealItems model CRUD operations

// READ
export const getAllDealItems = async () => {
  const dealItems = await prisma.dealItems.findMany({});
  return dealItems;
};

export const getDealItem = async (id) => {
  const dealItem = await prisma.dealItems.findUnique({
    where: { id },
  });
  return dealItem;
};

// CREATE
export const createDealItems = async (itemId, dealId) => {
  const dealItem = await prisma.dealItems.createMany({
    data: {
      itemId,
      dealId,
    },
  });
  return dealItem;
};

// UPDATE
export const updateDealItem = async (id, updateData) => {
  const dealItem = await prisma.dealItems.update({
    where: {
      id,
    },
    data: {
      ...updateData,
    },
  });
  return dealItem;
};

// DELETE
export const deleteDealItem = async (id) => {
  const dealItem = await prisma.dealItems.delete({
    where: {
      id,
    },
  });
  return dealItem;
};
