import prisma from "./prisma"

// READ
export const getAllUsers = async () => {
  const users = await prisma.user.findMany({})
  return users
}

/// Get Single User
export const getUser = async (id) => {
  const user = await prisma.user.findUnique({
    where: { id },
  })
  return user
};
/// Login Single User
export const logIn = async (email, password) => {
  const user = await prisma.user.findUnique({
    where: { email: email },
    include: {
      marquee: true
    }
  })
  if (user.password === password) {
    return user
  } else {
    return null;
  }
};



// CREATE
export const createUser = async (name, email, password) => {

  const existingUser = await prisma.user.findUnique({
    where: { email: email },

  })
  if (existingUser) {
    return {message : 'User already exists'};
  } else {
    const user = await prisma.user.create({
      data: {
        name,
        email,
        password,
      },
    })
    return user
  }
}

// UPDATE
export const updateUser = async (id, name, email, password) => {
  const user = await prisma.user.update({
    where: {
      id,
    },
    data: {
      name,
      email,
      password,
    },
  })
  return user
}
// UPDATE Password
export const updatePassword = async (id,  password) => {
  const user = await prisma.user.update({
    where: {
      id,
    },
    data: {
      password,
    },
  })
  return user
}

// DELETE
export const deleteUser = async (id) => {
  const user = await prisma.user.delete({
    where: {
      id,
    },
  })
  return user
}
