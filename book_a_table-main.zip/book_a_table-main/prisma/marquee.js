import prisma from "./prisma";

// READ
export const getAllMarquees = async () => {
  const marquees = await prisma.marquee.findMany({
    include: {
      items: true,
    },
  });
  return marquees;
};

export const getMarquee = async (id) => {
  const marquee = await prisma.marquee.findUnique({
    where: { id },
    include: {
      items: true, // Include the associated items
      deal: true, // Include the associated deals,
    },
  });
  return marquee;
};

// CREATE
export const createMarquee = async (
  name,
  location,
  city,
  desc,
  image,
  publicId,
  ownerId
) => {
  const marquee = await prisma.marquee.create({
    data: {
      name,
      location,
      city,
      desc,
      image,
      publicId,
      owner: {
        connect: {
          id: ownerId,
        },
      },
    },
  });
  return marquee;
};

// UPDATE
export const updateMarquee = async (id, updateData) => {
  const marquee = await prisma.marquee.update({
    where: {
      id,
    },
    data: {
      ...updateData,
    },
  });
  return marquee;
};

// DELETE
export const deleteMarquee = async (id) => {
  const marquee = await prisma.marquee.delete({
    where: {
      id,
    },
  });
  return marquee;
};
