import { createSlice } from "@reduxjs/toolkit";
import {colors} from "../../../common/colors"

const initialState = {
    colors: colors
}

const colorSlice = createSlice({
    name : 'color',
    initialState,
    reducers : {
        addColor : (state,action) => {
            state.colors = action.payload
        }
    }
})

export const {addColor} = colorSlice.actions;
export default colorSlice.reducer;