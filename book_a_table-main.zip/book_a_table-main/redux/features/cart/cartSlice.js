import { createSlice, current } from "@reduxjs/toolkit";
import { toast } from "react-hot-toast";

const initialState = {
  products: [],
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addItemToCart: (state, action) => {
      const checkExisting = state.products.find((i) => i.id === action.payload.id);

      if (checkExisting) {
        state.products = state.products.map((item) => {
          if (item.id === action.payload.id) {
            return {
              ...item,
              quantity: item.quantity + 1,
              size: action.payload.size,
            };
          }
          return item;
        });
      } else {
        const filteredProducts = state?.products?.filter(
          (product) => product.marqueeId == action.payload.marqueeId
        );
        state.products = filteredProducts;
        state.products.push(action.payload);
      }
      toast.success("Product added to cart");
    },
    incrementCartQuantity: (state, action) => {
      state.products = state.products.map((item) => {
        if (item.id === action.payload.id) {
          return {
            ...item,
            quantity: item.quantity + 1,
          };
        }
        return item;
      });
    },
    decrementCartQuantity: (state, action) => {
      state.products = state.products.map((item) => {
        if (item.id === action.payload.id) {
          return {
            ...item,
            quantity: item.quantity > 1 ? item.quantity - 1 : item.quantity,
          };
        }
        return item;
      });
    },
    setProducts : (state,action) => {
      state.products = action.payload;
    },
    removeSingleProduct: (state, action) => {
      state.products = state.products.filter((product) => {
        return product.id !== action.payload.id;
      });
    },
  },
});

export const {
  addItemToCart,
  incrementCartQuantity,
  decrementCartQuantity,
  removeSingleProduct,
  setProducts
} = cartSlice.actions;
export default cartSlice.reducer;
