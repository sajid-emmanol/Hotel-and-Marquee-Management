import { createSlice } from "@reduxjs/toolkit";
import dummyData from '../../../common/dummyData.json';

const initialState = {
    products: dummyData.products,
    selectedProducts: [],
    totalPrice: null,
    discountPrice: null,
    subTotalPrice: null,
    deal: [],
}

const dealsSlice = createSlice({
    name: 'deals',
    initialState,
    reducers: {
        selectProduct: (state, action) => {
            state.selectedProducts = action.payload;
            if (state.selectedProducts.length == 0) {
                state.totalPrice = null;
                state.subTotalPrice = null;
                state.discountPrice = null;
            }

        },
        addProductsPrice: (state, action) => {
            if (state.selectedProducts.length >= 0) {
                const productPrices = state.selectedProducts.map(product => Number(product.price));
                /// In case of first iteration the value of accumulator will be initial value i.e 0 and then in next iteration its value will be the accumulated result.
                const totalPrice = productPrices.reduce((accumulator, price) => accumulator + price, 0);
                state.totalPrice = totalPrice;
            }
        },

        setDiscountPrice: (state, action) => {

            state.discountPrice = action.payload
        },
        addDiscount: (state, action) => {
            if (state.discountPrice <= state.totalPrice) {
                state.subTotalPrice = state.totalPrice - state.discountPrice;
            }
        },
        createDeal: (state, action) => {
            const dealData = [...state.selectedProducts];
            dealData.push({ dealPrice: action.payload });
            state.deal = dealData;
            state.discountPrice = null
        }

    }
})

export const { selectProduct, addProductsPrice, setDiscountPrice, addDiscount, createDeal } = dealsSlice.actions;
export default dealsSlice.reducer;