import { configureStore } from "@reduxjs/toolkit";
import colorReducer from '../redux/features/color/colorSlice'
import dealsReducer from '../redux/features/deals/dealsSlice'
import cartReducer from '../redux/features/cart/cartSlice'
import userReducer from '../redux/features/user/userSlice'

/// Redux Persistor
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import thunk from 'redux-thunk';


const persistConfig = {
    key: 'root',
    storage,
};

const persistedUserReducer = persistReducer(persistConfig, userReducer);
const persistedCartReducer = persistReducer(persistConfig, cartReducer);

export const store = configureStore({
    reducer: {
        color: colorReducer,
        deal: dealsReducer,
        cart: persistedCartReducer,
        user: persistedUserReducer,
    },
    middleware: [thunk]

})

export const persistor = persistStore(store)