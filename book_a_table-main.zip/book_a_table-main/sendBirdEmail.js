const sgMail = require("@sendgrid/mail");
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

export const sendBirdEmail = async ({ email, code, userName }) => {
  try {
    const msg = {
      to: email, // Change to your recipient
      from: "hassanch3388@gmail.com", // Change to your verified sender
      subject: 'Verification Code',
      text: `Dear ${userName} 
      
      your verifiraction code is ${code}`,
    };
    const response = await sgMail.send(msg);
    console.log("response", response);
  } catch (error) {
    console.log("response", error);
  }
};
