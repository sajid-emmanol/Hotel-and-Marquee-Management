import { Carousel } from '@/common/Carousel'
import { Box, Flex, Icon, Image, Select, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import React from 'react'
import styles from '../styles/Home.module.css'
import { useSelector } from 'react-redux'
///Icons
import { AiOutlineArrowLeft, AiOutlineArrowRight } from 'react-icons/ai'
/// Spoon Image
import spoonImage from '../public/assets/images/heading_shapes_1.png'
import Link from 'next/link'


export default function CarouselContainer({ children, headingText, subHeadingText, bgColor, isMarquee, handleCityFilter, cities }) {

    const { colors } = useSelector(state => state?.color)

    return (
        <Box
            p={{ base: '5vw 5vw', md: '5vw 10vw' }}
            bg={bgColor}
        >
            <Flex
                align={{ base: 'center' }}
            >
                <Text
                    color={useColorModeValue(colors?.primary)}
                    fontWeight={'bold'}
                    fontSize={{ base: '20px', md: '2xl' }}
                    me={3}
                >
                    {headingText}
                </Text>
                <Image src={spoonImage.src} >

                </Image>
            </Flex>
            <Flex
                align={{ base: 'center' }}
                justifyContent={{ base: 'space-between' }}
                mt={{ base: 2 }}
            >
                <Text
                    fontSize={{ base: '2xl', md: '4xl' }}
                    fontWeight={{ base: 'bold' }}
                >
                    {subHeadingText}
                </Text>
                {/* <Stack
                    direction={{ base: 'row' }}
                    spacing={'2.5'}
                    display={{ base: 'none', md: 'flex' }}
                >
                    <Box
                        className={styles?.icon_Box}
                        bg={useColorModeValue(colors?.primary, 'gray.700')}
                        color={useColorModeValue(colors?.white, 'gray.700')}
                        _hover={{
                            bg: useColorModeValue(colors?.secondary, 'gray.700'),
                        }}
                    >
                        <Icon as={AiOutlineArrowLeft} boxSize={5} />
                    </Box>
                    <Box
                        className={styles?.icon_Box}
                        bg={useColorModeValue(colors?.secondary, 'gray.700')}
                        color={useColorModeValue(colors?.white, 'gray.700')}

                    >
                        <Icon as={AiOutlineArrowRight} boxSize={5} />
                    </Box>

                </Stack> */}
                {isMarquee && <>
                    <Select maxW={'2xs'} variant={'outline'} name='cityName' placeholder='--Select City--' onChange={handleCityFilter}>
                        {cities?.map((city, i) => {
                            return <option key={i} value={city}>{city}</option>

                        })}
                    </Select>
                    {/* <Link href={''}>
                    See All
                    </Link> */}
                </>

                }
            </Flex>
            {children}
        </Box>


    )
}
