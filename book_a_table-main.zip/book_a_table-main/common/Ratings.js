import { Box, Flex } from "@chakra-ui/react";
import { BsStar, BsStarFill, BsStarHalf } from "react-icons/bs";
import { useSelector } from "react-redux";

export default function Ratings({ rating, numReviews }) {
  const { colors } = useSelector((state) => state?.color);

  return (
    <Flex d="flex" alignItems="center" flexDirection={"row"}>
      {Array(5)
        .fill("")
        .map((_, i) => {
          const roundedRating = Math.round(rating * 2) / 2;
          if (roundedRating - i >= 1) {
            return (
              <BsStarFill
                key={i}
                style={{ marginLeft: "1" }}
                color={i < rating && colors?.primary}
              />
            );
          }
          if (roundedRating - i === 0.5) {
            return <BsStarHalf key={i} style={{ marginLeft: "1" }} />;
          }
          return (
            <BsStar
              color={colors?.primary}
              key={i}
              style={{ marginLeft: "1" }}
            />
          );
        })}
      <Box as="span" ml="2" color="gray.600" fontSize="lg" fontWeight={"500"}>
        ({numReviews})
      </Box>
    </Flex>
  );
}
