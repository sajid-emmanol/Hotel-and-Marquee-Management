import { useState } from "react";
import { useSelector } from "react-redux";
import CircleLoader from "react-spinners/CircleLoader";
import {Flex} from '@chakra-ui/react'

// const override = {
//     display: "block",
//     margin: "0 auto",
//     borderColor: "red",
// };

function Loader() {
    let [loading, setLoading] = useState(true);
    const { colors } = useSelector(state => state.color);

    return (
        <Flex justifyContent={'center'} alignItems={'center'} minH={'100vh'}>
            <CircleLoader
                color={colors?.primary}
                loading={loading}
                // cssOverride={override}
                size={150}
                aria-label="Loading Spinner"
                data-testid="loader"
            />
        </Flex>
    );
}

export default Loader;