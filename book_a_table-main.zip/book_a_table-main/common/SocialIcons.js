import React from 'react'
import { FaFacebookF } from 'react-icons/fa'
import { BsTwitter } from 'react-icons/bs'
import { FaLinkedinIn } from 'react-icons/fa'
import { BsInstagram } from 'react-icons/bs'
import { Box, Icon } from '@chakra-ui/react'

/// Styles
import styles from '../styles/Home.module.css'


export default function SocialIcons({iconColor,iconBgColor,hoverBgColor , hoverIconColor}) {

    const socialIcons = [
        {
            name: FaFacebookF
        },
        {
            name: BsTwitter,
        },
        {
            name: FaLinkedinIn,
        },
        {
            name: BsInstagram,
        },
    ]

    return (
        <>
            {socialIcons?.map((socialIcon, i) => {
                return (
                    <Box key={i} color={iconColor} className={styles?.socialIconBox} mx={'1.5'} bg={iconBgColor} _hover={{
                        bg: hoverBgColor,
                        color: hoverIconColor,
                    }}>
                        <Icon as={socialIcon.name} boxSize={'3.5'} />
                    </Box>
                )
            })}
        </>
    )
}
