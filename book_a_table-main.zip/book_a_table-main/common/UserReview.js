// import React, { useState } from 'react'
// import { useSelector } from 'react-redux';
// import StarRatingComponent from 'react-star-rating-component';
// import {BsFillStarFill} from 'react-icons/bs'
// import { Icon } from '@chakra-ui/react';

// export default function UserReview() {

//     const [currentValue, setcurrentValue] = useState(3);
//     const { colors } = useSelector(state => state?.color);

//     return (
//         <StarRatingComponent
//             name={'rate1'}
//             value={currentValue}
//             starCount={5}
//             onStarClick={(nextValue) => {
//                 setcurrentValue(nextValue);
//             }}
//             renderStarIcon={()=><Icon as={BsFillStarFill} boxSize={4}/>}
//             starColor={colors?.primary}
//             emptyStarColor={colors?.lightGrey}
//             editing={true}
//         />
//     )
// }
