export const colors = {
    primary : '#ff7c08',
    secondary : '#231f40',
    white : '#ffffff',
    grey : '#eef6eb',
    red : '#eb0029',
    lightRed : '#ffebda',
    lightGrey : '#dfdddd',    
    lightBrown : '#484747'
}