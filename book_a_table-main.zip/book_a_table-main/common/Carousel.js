// Import Swiper React components
import { Swiper, SwiperSlide, } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';

export const Carousel = ({ children, isSmallerScreen,isMediumScreen,isLargerScreen }) => {

    return (
        <>
            <Swiper
                spaceBetween={50}
                slidesPerView={
                    isSmallerScreen && 1 || isMediumScreen && 2 || isLargerScreen && 3 || isLargerScreen == null && 2 
                }
            // onSlideChange={() => console.log('slide change')}
            // onSwiper={(swiper) => console.log(swiper.slideNext())}
            >
                {children.map((card, i) => {
                    return (
                        <SwiperSlide key={i}>
                            {card}
                        </SwiperSlide>
                    )
                })}
            </Swiper>
        </>
    );
};
