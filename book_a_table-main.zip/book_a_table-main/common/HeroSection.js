import React from 'react'
import { Box, Flex, Text, useColorMode, useColorModeValue } from '@chakra-ui/react'
import styles from '../styles/Home.module.css'

/// Background Image
import bgImage from '../public/assets/images/counter_bg.jpg'
import { useSelector } from 'react-redux'


export default function HeroSection({ pageName }) {

    const { colors } = useSelector(state => state?.color);

    return (
        <>
            <Flex className={styles?.bg_img_container}
                _before={{
                    backgroundImage: `url(${bgImage.src})`,
                }}
                bg={useColorModeValue(colors?.secondary)}
                p={{ base: '15vh 5vw', md: '15vh 10vw' }}
            >
                <Text className={styles?.overlay_text} color={colors?.white}
                    fontSize={{ base: '3xl', lg: '4xl' }}
                    fontWeight={'bold'}
                >
                    {pageName}
                </Text>
            </Flex>
        </>
    )
}
