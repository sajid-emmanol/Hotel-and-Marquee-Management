import {
  Avatar,
  Box,
  chakra,
  Flex,
  Text,
  Wrap,
  WrapItem,
} from "@chakra-ui/react";
import { useSelector } from "react-redux";

export default function TestimonialCard(props) {
  const { role, content, avatar,name } = props;
  const { colors } = useSelector((state) => state?.color);
  return (
    <Flex
      boxShadow={"md"}
      direction={{ base: "column" }}
      rounded={"md"}
      px={5}
      bg={colors?.secondary}
      mt={7}
    >
      <Flex direction={{ base: "column" }} mt={10}>
        <Avatar
          src={avatar}
          size={"2xl"}
          alignSelf={"center"}
          css={{ border: `5px solid ${colors?.white}` }}
          boxShadow={"2xl"}
        />
        <Flex direction={"column"}>
          <Box
            display={{ base: "flex" }}
            flexDirection={{ base: "column" }}
            alignItems={{ base: "center" }}
            pt={5}
          >
            <Text
              fontSize={{ base: "2xl" }}
              fontWeight={{ base: "bold" }}
              color={colors?.white}
            >
              {name}
            </Text>
            <chakra.span
              fontWeight={"medium"}
              color={colors?.grey}
              fontSize={{ base: "15px" }}
            >
              {" "}
              - {role}
            </chakra.span>
            <Wrap mt={7}>
              <WrapItem height={"150px"}>
                <chakra.p
                  fontWeight={"medium"}
                  fontSize={"15px"}
                  textAlign={{ base: "center" }}
                  color={colors?.white}
                >
                  {content}
                </chakra.p>
              </WrapItem>
            </Wrap>
          </Box>
        </Flex>
      </Flex>
    </Flex>
  );
}
